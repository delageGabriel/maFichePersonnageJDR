﻿
namespace maFichePersonnageJDR.Formulaires
{
    partial class FormulaireTalentsEtObjets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDgtsEpee = new System.Windows.Forms.Label();
            this.lblTpeEpee = new System.Windows.Forms.Label();
            this.lblNbEpee = new System.Windows.Forms.Label();
            this.lblPdsEpee = new System.Windows.Forms.Label();
            this.lblPrtEpee = new System.Windows.Forms.Label();
            this.lblNomEpee = new System.Windows.Forms.Label();
            this.btnSauvegarder = new System.Windows.Forms.Button();
            this.tcInventaires = new System.Windows.Forms.TabControl();
            this.tpArmes = new System.Windows.Forms.TabPage();
            this.tcArmes = new System.Windows.Forms.TabControl();
            this.tpEpee = new System.Windows.Forms.TabPage();
            this.lblPrpieteEpBtrde = new System.Windows.Forms.Label();
            this.lblDescEpees = new System.Windows.Forms.Label();
            this.lblVleurEpBtrde = new System.Windows.Forms.Label();
            this.nudEpBtrde = new System.Windows.Forms.NumericUpDown();
            this.chkEpBtrde = new System.Windows.Forms.CheckBox();
            this.lblNomEpBtrde = new System.Windows.Forms.Label();
            this.lblPdsEpBtrde = new System.Windows.Forms.Label();
            this.lblPrteEpBtrde = new System.Windows.Forms.Label();
            this.lblTpeEpBtrde = new System.Windows.Forms.Label();
            this.lblDgtsEpBtrde = new System.Windows.Forms.Label();
            this.lblPrpieteEpBois = new System.Windows.Forms.Label();
            this.lblVleurEpBois = new System.Windows.Forms.Label();
            this.nudEpBois = new System.Windows.Forms.NumericUpDown();
            this.chkEpBois = new System.Windows.Forms.CheckBox();
            this.lblNomEpBois = new System.Windows.Forms.Label();
            this.lblPdsEpBois = new System.Windows.Forms.Label();
            this.lblPrteEpBois = new System.Windows.Forms.Label();
            this.lblTpeEpBois = new System.Windows.Forms.Label();
            this.lblDgtsEpBois = new System.Windows.Forms.Label();
            this.lblPrpieteSbreCrbe = new System.Windows.Forms.Label();
            this.lblPrpieteLte = new System.Windows.Forms.Label();
            this.lblPrpieteGlve = new System.Windows.Forms.Label();
            this.lblPrpieteEpLge = new System.Windows.Forms.Label();
            this.lblPrpieteEpCrte = new System.Windows.Forms.Label();
            this.lblPrpieteScrmx = new System.Windows.Forms.Label();
            this.lblVleurSbreCrbe = new System.Windows.Forms.Label();
            this.lblVleurLte = new System.Windows.Forms.Label();
            this.lblVleurGlve = new System.Windows.Forms.Label();
            this.lblVleurEpLge = new System.Windows.Forms.Label();
            this.lblVleurEpCrte = new System.Windows.Forms.Label();
            this.lblVleurScrmx = new System.Windows.Forms.Label();
            this.lblPrpieteEpees = new System.Windows.Forms.Label();
            this.lblVleurEpee = new System.Windows.Forms.Label();
            this.nudSbreCrbe = new System.Windows.Forms.NumericUpDown();
            this.nudLte = new System.Windows.Forms.NumericUpDown();
            this.chkSbreCrbe = new System.Windows.Forms.CheckBox();
            this.chkLte = new System.Windows.Forms.CheckBox();
            this.chkGlve = new System.Windows.Forms.CheckBox();
            this.chkEpLge = new System.Windows.Forms.CheckBox();
            this.chkEpCrte = new System.Windows.Forms.CheckBox();
            this.chkScrmx = new System.Windows.Forms.CheckBox();
            this.lblNomSbreCrbe = new System.Windows.Forms.Label();
            this.lblPdsSbreCrbe = new System.Windows.Forms.Label();
            this.lblPrteSbreCrbe = new System.Windows.Forms.Label();
            this.lblTpeSbreCrbe = new System.Windows.Forms.Label();
            this.lblDgtsSbreCrbe = new System.Windows.Forms.Label();
            this.lblNomLte = new System.Windows.Forms.Label();
            this.lblPdsLte = new System.Windows.Forms.Label();
            this.lblPrteLte = new System.Windows.Forms.Label();
            this.lblTpeLte = new System.Windows.Forms.Label();
            this.lblDgtsLte = new System.Windows.Forms.Label();
            this.lblNomGlve = new System.Windows.Forms.Label();
            this.lblPdsGlve = new System.Windows.Forms.Label();
            this.lblPrteGlve = new System.Windows.Forms.Label();
            this.nudGlve = new System.Windows.Forms.NumericUpDown();
            this.lblTpeGlve = new System.Windows.Forms.Label();
            this.lblDgtsGlve = new System.Windows.Forms.Label();
            this.lblNomEpLge = new System.Windows.Forms.Label();
            this.lblPdsEpLge = new System.Windows.Forms.Label();
            this.lblPrteEpLge = new System.Windows.Forms.Label();
            this.nudEpLge = new System.Windows.Forms.NumericUpDown();
            this.lblTpeEpLge = new System.Windows.Forms.Label();
            this.lblDgtsEpLge = new System.Windows.Forms.Label();
            this.lblNomEpCrte = new System.Windows.Forms.Label();
            this.lblPdsEpCrte = new System.Windows.Forms.Label();
            this.lblPrteEpCrte = new System.Windows.Forms.Label();
            this.nudEpCrte = new System.Windows.Forms.NumericUpDown();
            this.lblTpeEpCrte = new System.Windows.Forms.Label();
            this.lblDgtsEpCrte = new System.Windows.Forms.Label();
            this.lblNomScrmx = new System.Windows.Forms.Label();
            this.lblPdsScrmx = new System.Windows.Forms.Label();
            this.lblPrteScrmx = new System.Windows.Forms.Label();
            this.nudScrmx = new System.Windows.Forms.NumericUpDown();
            this.lblTpeScrmx = new System.Windows.Forms.Label();
            this.lblDgtsScrmx = new System.Windows.Forms.Label();
            this.tpLances = new System.Windows.Forms.TabPage();
            this.lblPprieteTrdnt = new System.Windows.Forms.Label();
            this.lblPprieteSrse = new System.Windows.Forms.Label();
            this.lblPprieteFrche = new System.Windows.Forms.Label();
            this.lblPprieteJvlot = new System.Windows.Forms.Label();
            this.lblPprieteCntus = new System.Windows.Forms.Label();
            this.lblPprieteLances = new System.Windows.Forms.Label();
            this.lblDescLances = new System.Windows.Forms.Label();
            this.lblVleurTrdnt = new System.Windows.Forms.Label();
            this.lblVleurSrse = new System.Windows.Forms.Label();
            this.lblVleurFrche = new System.Windows.Forms.Label();
            this.lblVleurJvlot = new System.Windows.Forms.Label();
            this.lblVleurCntus = new System.Windows.Forms.Label();
            this.lblVleurLance = new System.Windows.Forms.Label();
            this.chkTrdnt = new System.Windows.Forms.CheckBox();
            this.lblNomTrdnt = new System.Windows.Forms.Label();
            this.lblPdsTrdnt = new System.Windows.Forms.Label();
            this.lblPrteTrdnt = new System.Windows.Forms.Label();
            this.nudTrdnt = new System.Windows.Forms.NumericUpDown();
            this.lblTpeTrdnt = new System.Windows.Forms.Label();
            this.lblDgtsTrdnt = new System.Windows.Forms.Label();
            this.chkSrse = new System.Windows.Forms.CheckBox();
            this.chkFrche = new System.Windows.Forms.CheckBox();
            this.chkJvlot = new System.Windows.Forms.CheckBox();
            this.chkCntus = new System.Windows.Forms.CheckBox();
            this.lblNomSrse = new System.Windows.Forms.Label();
            this.lblPdsSrse = new System.Windows.Forms.Label();
            this.lblPrteSrse = new System.Windows.Forms.Label();
            this.nudSrse = new System.Windows.Forms.NumericUpDown();
            this.lblTpeSrse = new System.Windows.Forms.Label();
            this.lblDgtsSrse = new System.Windows.Forms.Label();
            this.lblNomFrche = new System.Windows.Forms.Label();
            this.lblPdsFrche = new System.Windows.Forms.Label();
            this.lblPrteFrche = new System.Windows.Forms.Label();
            this.nudFrche = new System.Windows.Forms.NumericUpDown();
            this.lblTpeFrche = new System.Windows.Forms.Label();
            this.lblDgtsFrche = new System.Windows.Forms.Label();
            this.lblNomJvlot = new System.Windows.Forms.Label();
            this.lblPdsJvlot = new System.Windows.Forms.Label();
            this.lblPrteJvlot = new System.Windows.Forms.Label();
            this.nudJvlot = new System.Windows.Forms.NumericUpDown();
            this.lblTpeJvlot = new System.Windows.Forms.Label();
            this.lblDgtsJvlot = new System.Windows.Forms.Label();
            this.lblNomCntus = new System.Windows.Forms.Label();
            this.lblPdsCntus = new System.Windows.Forms.Label();
            this.lblPrteCntus = new System.Windows.Forms.Label();
            this.nudCntus = new System.Windows.Forms.NumericUpDown();
            this.lblTpeCntus = new System.Windows.Forms.Label();
            this.lblDgtsCntus = new System.Windows.Forms.Label();
            this.lblNomLances = new System.Windows.Forms.Label();
            this.lblPrtLances = new System.Windows.Forms.Label();
            this.lblPdsLances = new System.Windows.Forms.Label();
            this.lblNbLances = new System.Windows.Forms.Label();
            this.lblTpeLances = new System.Windows.Forms.Label();
            this.lblDgtsLances = new System.Windows.Forms.Label();
            this.tpPoignards = new System.Windows.Forms.TabPage();
            this.lblDescPoignards = new System.Windows.Forms.Label();
            this.lblPrpieteDgeAssin = new System.Windows.Forms.Label();
            this.lblPrpieteFclGure = new System.Windows.Forms.Label();
            this.lblPrpieteDge = new System.Windows.Forms.Label();
            this.lblPrpieteCtau = new System.Windows.Forms.Label();
            this.lblPprieteDagues = new System.Windows.Forms.Label();
            this.lblVleurDgeAssin = new System.Windows.Forms.Label();
            this.chkDgeAssin = new System.Windows.Forms.CheckBox();
            this.lblNomDgeAssin = new System.Windows.Forms.Label();
            this.lblPdsDgeAssin = new System.Windows.Forms.Label();
            this.lblPrteDgeAssin = new System.Windows.Forms.Label();
            this.nudDgeAssin = new System.Windows.Forms.NumericUpDown();
            this.lblTpeDgeAssin = new System.Windows.Forms.Label();
            this.lblDgtsDgeAssin = new System.Windows.Forms.Label();
            this.lblVleurFclGure = new System.Windows.Forms.Label();
            this.lblVleurDge = new System.Windows.Forms.Label();
            this.lblVleurCtau = new System.Windows.Forms.Label();
            this.lblVleurDagues = new System.Windows.Forms.Label();
            this.chkFclGure = new System.Windows.Forms.CheckBox();
            this.chkDge = new System.Windows.Forms.CheckBox();
            this.chkCtau = new System.Windows.Forms.CheckBox();
            this.lblNomFclGure = new System.Windows.Forms.Label();
            this.lblPdsFclGure = new System.Windows.Forms.Label();
            this.lblPrteFclGure = new System.Windows.Forms.Label();
            this.nudFclGure = new System.Windows.Forms.NumericUpDown();
            this.lblTpeFclGure = new System.Windows.Forms.Label();
            this.lblDgtsFclGure = new System.Windows.Forms.Label();
            this.lblNomDge = new System.Windows.Forms.Label();
            this.lblPdsDge = new System.Windows.Forms.Label();
            this.lblPrteDge = new System.Windows.Forms.Label();
            this.nudDge = new System.Windows.Forms.NumericUpDown();
            this.lblTpeDge = new System.Windows.Forms.Label();
            this.lblDgtsDge = new System.Windows.Forms.Label();
            this.lblNomCtau = new System.Windows.Forms.Label();
            this.lblPdsCtau = new System.Windows.Forms.Label();
            this.lblPrteCtau = new System.Windows.Forms.Label();
            this.nudCtau = new System.Windows.Forms.NumericUpDown();
            this.lblTpeCtau = new System.Windows.Forms.Label();
            this.lblDgtsCtau = new System.Windows.Forms.Label();
            this.lblNomDagues = new System.Windows.Forms.Label();
            this.lblPrteDagues = new System.Windows.Forms.Label();
            this.lblPdsDagues = new System.Windows.Forms.Label();
            this.lblNbDagues = new System.Windows.Forms.Label();
            this.lblTypeDagues = new System.Windows.Forms.Label();
            this.lblDgtsDagues = new System.Windows.Forms.Label();
            this.tpHaches = new System.Windows.Forms.TabPage();
            this.lblPrpieteHcheBhron = new System.Windows.Forms.Label();
            this.lblVleurHcheBhron = new System.Windows.Forms.Label();
            this.chkHcheBhron = new System.Windows.Forms.CheckBox();
            this.lblNomHcheBhron = new System.Windows.Forms.Label();
            this.lblPdsHcheBhron = new System.Windows.Forms.Label();
            this.lblPrteHcheBhron = new System.Windows.Forms.Label();
            this.nudHcheBhron = new System.Windows.Forms.NumericUpDown();
            this.lblTpeHcheBhron = new System.Windows.Forms.Label();
            this.lblDgtsHcheBhron = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblPrpieteFrncsque = new System.Windows.Forms.Label();
            this.lblPrpieteHaches = new System.Windows.Forms.Label();
            this.lblVleurFrncsque = new System.Windows.Forms.Label();
            this.lblVleurHache = new System.Windows.Forms.Label();
            this.chkFrncsque = new System.Windows.Forms.CheckBox();
            this.lblNomFrncsque = new System.Windows.Forms.Label();
            this.lblPdsFrncsque = new System.Windows.Forms.Label();
            this.lblPrteFrncsque = new System.Windows.Forms.Label();
            this.nudFrncsque = new System.Windows.Forms.NumericUpDown();
            this.lblTpeFrncsque = new System.Windows.Forms.Label();
            this.lblDgtsFrncsque = new System.Windows.Forms.Label();
            this.lblNomHache = new System.Windows.Forms.Label();
            this.lblPrteHache = new System.Windows.Forms.Label();
            this.lblPdsHache = new System.Windows.Forms.Label();
            this.lblNbHache = new System.Windows.Forms.Label();
            this.lblTpeHache = new System.Windows.Forms.Label();
            this.lblDgtsHache = new System.Windows.Forms.Label();
            this.tpMasse = new System.Windows.Forms.TabPage();
            this.lblPrpieteMrteauFgron = new System.Windows.Forms.Label();
            this.lblVleurMrteauFgron = new System.Windows.Forms.Label();
            this.chkMrteauFgron = new System.Windows.Forms.CheckBox();
            this.lblNomMrteauFgron = new System.Windows.Forms.Label();
            this.lblPdsMrteauFgron = new System.Windows.Forms.Label();
            this.lblPrteMrteauFgron = new System.Windows.Forms.Label();
            this.nudMrteauFgron = new System.Windows.Forms.NumericUpDown();
            this.lblTpeMrteauFgron = new System.Windows.Forms.Label();
            this.lblDgtsMrteauFgron = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPrpieteMsueChne = new System.Windows.Forms.Label();
            this.lblVleurMsueChne = new System.Windows.Forms.Label();
            this.chkMsueChne = new System.Windows.Forms.CheckBox();
            this.lblNomMsueChne = new System.Windows.Forms.Label();
            this.lblPdsMsueChne = new System.Windows.Forms.Label();
            this.lblPrteMsueChne = new System.Windows.Forms.Label();
            this.nudMsueChne = new System.Windows.Forms.NumericUpDown();
            this.lblTpeMsueChne = new System.Windows.Forms.Label();
            this.lblDgtsMsueChne = new System.Windows.Forms.Label();
            this.lblPrpieteMassues = new System.Windows.Forms.Label();
            this.lblVleurMassues = new System.Windows.Forms.Label();
            this.lblNomMassues = new System.Windows.Forms.Label();
            this.lblPrteMassues = new System.Windows.Forms.Label();
            this.lblPdsMassues = new System.Windows.Forms.Label();
            this.lblNbMassues = new System.Windows.Forms.Label();
            this.lblTpeMassues = new System.Windows.Forms.Label();
            this.lblDgtsMassues = new System.Windows.Forms.Label();
            this.tpArc = new System.Windows.Forms.TabPage();
            this.lblPrpieteFnde = new System.Windows.Forms.Label();
            this.lblPrpieteAblte = new System.Windows.Forms.Label();
            this.lblDescArcs = new System.Windows.Forms.Label();
            this.lblPrpieteArc = new System.Windows.Forms.Label();
            this.lblPrpieteArcs = new System.Windows.Forms.Label();
            this.lblVleurFnde = new System.Windows.Forms.Label();
            this.lblVleurAblte = new System.Windows.Forms.Label();
            this.lblVleurArc = new System.Windows.Forms.Label();
            this.lblVleurArcs = new System.Windows.Forms.Label();
            this.lblPdsFnde = new System.Windows.Forms.Label();
            this.chkFnde = new System.Windows.Forms.CheckBox();
            this.chkAblte = new System.Windows.Forms.CheckBox();
            this.chkArc = new System.Windows.Forms.CheckBox();
            this.lblNomFnde = new System.Windows.Forms.Label();
            this.lblPrteFnde = new System.Windows.Forms.Label();
            this.nudFnde = new System.Windows.Forms.NumericUpDown();
            this.lblTpeFnde = new System.Windows.Forms.Label();
            this.lblDgtsFnde = new System.Windows.Forms.Label();
            this.lblNomAblte = new System.Windows.Forms.Label();
            this.lblPdsAblte = new System.Windows.Forms.Label();
            this.lblPrteAblte = new System.Windows.Forms.Label();
            this.nudAblte = new System.Windows.Forms.NumericUpDown();
            this.lblTpeAblte = new System.Windows.Forms.Label();
            this.lblDgtsAblte = new System.Windows.Forms.Label();
            this.lblNomArc = new System.Windows.Forms.Label();
            this.lblPdsArc = new System.Windows.Forms.Label();
            this.lblPrteArc = new System.Windows.Forms.Label();
            this.nudArc = new System.Windows.Forms.NumericUpDown();
            this.lblTpeArc = new System.Windows.Forms.Label();
            this.lblDgtsArc = new System.Windows.Forms.Label();
            this.lblNomArcs = new System.Windows.Forms.Label();
            this.lblPrteArcs = new System.Windows.Forms.Label();
            this.lblPdsArcs = new System.Windows.Forms.Label();
            this.lblNbArcs = new System.Windows.Forms.Label();
            this.lblTpeArcs = new System.Windows.Forms.Label();
            this.lblDgtsArcs = new System.Windows.Forms.Label();
            this.tpChaînes = new System.Windows.Forms.TabPage();
            this.lblPrpieteFaC = new System.Windows.Forms.Label();
            this.lblPrpieteFouet = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblVleurFaC = new System.Windows.Forms.Label();
            this.lblVleurFouet = new System.Windows.Forms.Label();
            this.lblVleurChaines = new System.Windows.Forms.Label();
            this.lblPdsFouet = new System.Windows.Forms.Label();
            this.chkFaC = new System.Windows.Forms.CheckBox();
            this.chkFouet = new System.Windows.Forms.CheckBox();
            this.lblNomFaC = new System.Windows.Forms.Label();
            this.lblPdsFaC = new System.Windows.Forms.Label();
            this.lblPrteFaC = new System.Windows.Forms.Label();
            this.nudFaC = new System.Windows.Forms.NumericUpDown();
            this.lblTpeFaC = new System.Windows.Forms.Label();
            this.lblDgtsFaC = new System.Windows.Forms.Label();
            this.lblNomFouet = new System.Windows.Forms.Label();
            this.lblPrteFouet = new System.Windows.Forms.Label();
            this.nudFouet = new System.Windows.Forms.NumericUpDown();
            this.lblTpeFouet = new System.Windows.Forms.Label();
            this.lblDgtsFouet = new System.Windows.Forms.Label();
            this.lblNomChaines = new System.Windows.Forms.Label();
            this.lblPrteChaines = new System.Windows.Forms.Label();
            this.lblPdsChaines = new System.Windows.Forms.Label();
            this.lblNbChaines = new System.Windows.Forms.Label();
            this.lblTpeChaines = new System.Windows.Forms.Label();
            this.lblDgtsChaines = new System.Windows.Forms.Label();
            this.tpBatons = new System.Windows.Forms.TabPage();
            this.lblDescBatons = new System.Windows.Forms.Label();
            this.lblPrpieteSptreNeutre = new System.Windows.Forms.Label();
            this.lblVleurSptreNeutre = new System.Windows.Forms.Label();
            this.chkSptreNeutre = new System.Windows.Forms.CheckBox();
            this.lblPrteSptreNeutre = new System.Windows.Forms.Label();
            this.lblEftsSptreNeutre = new System.Windows.Forms.Label();
            this.lblNomSptreNeutre = new System.Windows.Forms.Label();
            this.lblPdsSptreNeutre = new System.Windows.Forms.Label();
            this.nudSptreNeutre = new System.Windows.Forms.NumericUpDown();
            this.lblTpeSptreNeutre = new System.Windows.Forms.Label();
            this.lblDgtsSptreNeutre = new System.Windows.Forms.Label();
            this.lblPrpieteBgteInfernale = new System.Windows.Forms.Label();
            this.lblVleurBgteInfernale = new System.Windows.Forms.Label();
            this.chkBgteInfernale = new System.Windows.Forms.CheckBox();
            this.lblPrteBgteInfernale = new System.Windows.Forms.Label();
            this.lblEftsBgteInfernale = new System.Windows.Forms.Label();
            this.lblNomBgteInfernale = new System.Windows.Forms.Label();
            this.lblPdsBgteInfernale = new System.Windows.Forms.Label();
            this.nudBgteInfernale = new System.Windows.Forms.NumericUpDown();
            this.lblTpeBgteInfernale = new System.Windows.Forms.Label();
            this.lblDgtsBgteInfernale = new System.Windows.Forms.Label();
            this.lblPrpieteCneLmiere = new System.Windows.Forms.Label();
            this.lblVleurCneLmiere = new System.Windows.Forms.Label();
            this.chkCneLmiere = new System.Windows.Forms.CheckBox();
            this.lblPrteCneLmiere = new System.Windows.Forms.Label();
            this.lblEftsCneLmiere = new System.Windows.Forms.Label();
            this.lblNomCneLmiere = new System.Windows.Forms.Label();
            this.lblPdsCneLmiere = new System.Windows.Forms.Label();
            this.nudCneLmiere = new System.Windows.Forms.NumericUpDown();
            this.lblTpeCneLmiere = new System.Windows.Forms.Label();
            this.lblDgtsCneLmiere = new System.Windows.Forms.Label();
            this.lblPrpieteBtonNture = new System.Windows.Forms.Label();
            this.lblVleurBtonNture = new System.Windows.Forms.Label();
            this.chkBtonNture = new System.Windows.Forms.CheckBox();
            this.lblPrteBtonNture = new System.Windows.Forms.Label();
            this.lblEftsBtonNture = new System.Windows.Forms.Label();
            this.lblNomBtonNture = new System.Windows.Forms.Label();
            this.lblPdsBtonNture = new System.Windows.Forms.Label();
            this.nudBtonNture = new System.Windows.Forms.NumericUpDown();
            this.lblTpeBtonNture = new System.Windows.Forms.Label();
            this.lblDgtsBtonNture = new System.Windows.Forms.Label();
            this.lblPrpieteScptreTerre = new System.Windows.Forms.Label();
            this.lblVleurScptreTerre = new System.Windows.Forms.Label();
            this.chkScptreTerre = new System.Windows.Forms.CheckBox();
            this.lblPrteScptreTerre = new System.Windows.Forms.Label();
            this.lblEftsScptreTerre = new System.Windows.Forms.Label();
            this.lblNomScptreTerre = new System.Windows.Forms.Label();
            this.lblPdsScptreTerre = new System.Windows.Forms.Label();
            this.nudScptreTerre = new System.Windows.Forms.NumericUpDown();
            this.lblTpeScptreTerre = new System.Windows.Forms.Label();
            this.lblDgtsScptreTerre = new System.Windows.Forms.Label();
            this.lblPrpieteBtonCelste = new System.Windows.Forms.Label();
            this.lblVleurBtonCelste = new System.Windows.Forms.Label();
            this.chkBtonCelste = new System.Windows.Forms.CheckBox();
            this.lblPrteBtonCelste = new System.Windows.Forms.Label();
            this.lblEftsBtonCelste = new System.Windows.Forms.Label();
            this.lblNomBtonCelste = new System.Windows.Forms.Label();
            this.lblPdsBtonCelste = new System.Windows.Forms.Label();
            this.nudBtonCelste = new System.Windows.Forms.NumericUpDown();
            this.lblTpeBtonCelste = new System.Windows.Forms.Label();
            this.lblDgtsBtonCelste = new System.Windows.Forms.Label();
            this.lblPrpieteBgteFeu = new System.Windows.Forms.Label();
            this.lblVleurBgteFeu = new System.Windows.Forms.Label();
            this.chkBgteFeu = new System.Windows.Forms.CheckBox();
            this.lblPrteBgteFeu = new System.Windows.Forms.Label();
            this.lblEftsBgteFeu = new System.Windows.Forms.Label();
            this.lblNomBgteFeu = new System.Windows.Forms.Label();
            this.lblPdsBgteFeu = new System.Windows.Forms.Label();
            this.nudBgteFeu = new System.Windows.Forms.NumericUpDown();
            this.lblTpeBgteFeu = new System.Windows.Forms.Label();
            this.lblDgtsBgteFeu = new System.Windows.Forms.Label();
            this.lblPrpieteCneAqua = new System.Windows.Forms.Label();
            this.lblVleurCneAqua = new System.Windows.Forms.Label();
            this.chkCneAqua = new System.Windows.Forms.CheckBox();
            this.lblPrteCneAqua = new System.Windows.Forms.Label();
            this.lblEftsCneAqua = new System.Windows.Forms.Label();
            this.lblNomCneAqua = new System.Windows.Forms.Label();
            this.lblPdsCneAqua = new System.Windows.Forms.Label();
            this.nudCneAqua = new System.Windows.Forms.NumericUpDown();
            this.lblTpeCneAqua = new System.Windows.Forms.Label();
            this.lblDgtsCneAqua = new System.Windows.Forms.Label();
            this.lblPrpieteSctre = new System.Windows.Forms.Label();
            this.lblPrpieteBtonChne = new System.Windows.Forms.Label();
            this.lblPrpieteBatons = new System.Windows.Forms.Label();
            this.lblVleurSctre = new System.Windows.Forms.Label();
            this.lblVleurBtonChne = new System.Windows.Forms.Label();
            this.lblVleurBatons = new System.Windows.Forms.Label();
            this.chkSctre = new System.Windows.Forms.CheckBox();
            this.lblPrteSctre = new System.Windows.Forms.Label();
            this.lblPrteBtonChne = new System.Windows.Forms.Label();
            this.lblPrteBton = new System.Windows.Forms.Label();
            this.chkBtonChne = new System.Windows.Forms.CheckBox();
            this.lblEftsSctre = new System.Windows.Forms.Label();
            this.lblNomSctre = new System.Windows.Forms.Label();
            this.lblPdsSctre = new System.Windows.Forms.Label();
            this.nudSctre = new System.Windows.Forms.NumericUpDown();
            this.lblTpeSctre = new System.Windows.Forms.Label();
            this.lblDgtsSctre = new System.Windows.Forms.Label();
            this.lblEftsBtonChne = new System.Windows.Forms.Label();
            this.lblEftsBton = new System.Windows.Forms.Label();
            this.lblNomBtonChne = new System.Windows.Forms.Label();
            this.lblPdsBtonChne = new System.Windows.Forms.Label();
            this.nudBtonChne = new System.Windows.Forms.NumericUpDown();
            this.lblTpeBtonChne = new System.Windows.Forms.Label();
            this.lblDgtsBtonChne = new System.Windows.Forms.Label();
            this.lblNomBton = new System.Windows.Forms.Label();
            this.lblPdsBton = new System.Windows.Forms.Label();
            this.lblNbBton = new System.Windows.Forms.Label();
            this.lblTpeBton = new System.Windows.Forms.Label();
            this.lblDgtsBton = new System.Windows.Forms.Label();
            this.tpArmures = new System.Windows.Forms.TabPage();
            this.tcArmure = new System.Windows.Forms.TabControl();
            this.tbCasque = new System.Windows.Forms.TabPage();
            this.lblPrpieteCsqueBrbre = new System.Windows.Forms.Label();
            this.lblPrpieteChplFr = new System.Windows.Forms.Label();
            this.lblPrpieteCrvlre = new System.Windows.Forms.Label();
            this.lblPrpieteMrn = new System.Windows.Forms.Label();
            this.lblPrpieteCfeMle = new System.Windows.Forms.Label();
            this.lblPrpieteSpghlm = new System.Windows.Forms.Label();
            this.lblPrpieteCasques = new System.Windows.Forms.Label();
            this.lblDescDeuxCasques = new System.Windows.Forms.Label();
            this.lblDescCasques = new System.Windows.Forms.Label();
            this.lblVleurCsqueBrbre = new System.Windows.Forms.Label();
            this.lblVleurChplFr = new System.Windows.Forms.Label();
            this.lblVleurMrn = new System.Windows.Forms.Label();
            this.lblVleurCrvlre = new System.Windows.Forms.Label();
            this.lblVleurCfeMle = new System.Windows.Forms.Label();
            this.lblVleurSpghlm = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.chkCsqueBrbre = new System.Windows.Forms.CheckBox();
            this.chkChplFr = new System.Windows.Forms.CheckBox();
            this.chkCrvlre = new System.Windows.Forms.CheckBox();
            this.chkMrn = new System.Windows.Forms.CheckBox();
            this.chkCfeMle = new System.Windows.Forms.CheckBox();
            this.chkSpghlm = new System.Windows.Forms.CheckBox();
            this.lblNomCsqueBrbre = new System.Windows.Forms.Label();
            this.lblPdsCsqueBrbre = new System.Windows.Forms.Label();
            this.nudCsqueBrbre = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCsqueBrbre = new System.Windows.Forms.Label();
            this.lblNomChplFr = new System.Windows.Forms.Label();
            this.lblPdsChplFr = new System.Windows.Forms.Label();
            this.nudChplFr = new System.Windows.Forms.NumericUpDown();
            this.lblEftsChplFr = new System.Windows.Forms.Label();
            this.lblNomCrvlre = new System.Windows.Forms.Label();
            this.lblPdsCrvlre = new System.Windows.Forms.Label();
            this.nudCrvlre = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCrvlre = new System.Windows.Forms.Label();
            this.lblNomMrn = new System.Windows.Forms.Label();
            this.lblPdsMrn = new System.Windows.Forms.Label();
            this.nudMrn = new System.Windows.Forms.NumericUpDown();
            this.lblEftsMrn = new System.Windows.Forms.Label();
            this.lblNomCfeMle = new System.Windows.Forms.Label();
            this.lblPdsCfeMle = new System.Windows.Forms.Label();
            this.nudCfeMle = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCfeMle = new System.Windows.Forms.Label();
            this.lblNomSpghlm = new System.Windows.Forms.Label();
            this.lblPdsSpghlm = new System.Windows.Forms.Label();
            this.nudSpghlm = new System.Windows.Forms.NumericUpDown();
            this.lblEftsSpghlm = new System.Windows.Forms.Label();
            this.lblNomCasques = new System.Windows.Forms.Label();
            this.lblPdsCasques = new System.Windows.Forms.Label();
            this.lblNbCasques = new System.Windows.Forms.Label();
            this.lblEftCasques = new System.Windows.Forms.Label();
            this.tpBuste = new System.Windows.Forms.TabPage();
            this.lblPrpieteCrsBze = new System.Windows.Forms.Label();
            this.lblPrpieteRbeCuir = new System.Windows.Forms.Label();
            this.lblPrpieteCrsFr = new System.Windows.Forms.Label();
            this.lblPrpieteCtphrcte = new System.Windows.Forms.Label();
            this.lblPrpieteBrgne = new System.Windows.Forms.Label();
            this.lblPrpieteVtments = new System.Windows.Forms.Label();
            this.lblPrpieteBuste = new System.Windows.Forms.Label();
            this.lblVleurCrsBze = new System.Windows.Forms.Label();
            this.lblVleurRbeCuir = new System.Windows.Forms.Label();
            this.lblDescDeuxBuste = new System.Windows.Forms.Label();
            this.lblDescBuste = new System.Windows.Forms.Label();
            this.lblVleurCrsFr = new System.Windows.Forms.Label();
            this.lblVleurCtphrcte = new System.Windows.Forms.Label();
            this.lblVleurBrgne = new System.Windows.Forms.Label();
            this.lblVleurVtments = new System.Windows.Forms.Label();
            this.lblVleurBuste = new System.Windows.Forms.Label();
            this.chkCrsBze = new System.Windows.Forms.CheckBox();
            this.chkRbeCuir = new System.Windows.Forms.CheckBox();
            this.chkCrsFr = new System.Windows.Forms.CheckBox();
            this.chkCtphrcte = new System.Windows.Forms.CheckBox();
            this.chkBrgne = new System.Windows.Forms.CheckBox();
            this.chkVtments = new System.Windows.Forms.CheckBox();
            this.lblNomCrsBze = new System.Windows.Forms.Label();
            this.lblPdsCrsBze = new System.Windows.Forms.Label();
            this.nudCrsBze = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCrsBze = new System.Windows.Forms.Label();
            this.lblNomRbeCuir = new System.Windows.Forms.Label();
            this.lblPdsRbeCuir = new System.Windows.Forms.Label();
            this.nudRbeCuir = new System.Windows.Forms.NumericUpDown();
            this.lblEftsRbeCuir = new System.Windows.Forms.Label();
            this.lblNomCrsFr = new System.Windows.Forms.Label();
            this.lblPdsCrsFr = new System.Windows.Forms.Label();
            this.nudCrsFr = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCrsFr = new System.Windows.Forms.Label();
            this.lblNomCtphrcte = new System.Windows.Forms.Label();
            this.lblPdsCtphrcte = new System.Windows.Forms.Label();
            this.nudCtphrcte = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCtphrcte = new System.Windows.Forms.Label();
            this.lblNomBrgne = new System.Windows.Forms.Label();
            this.lblPdsBrgne = new System.Windows.Forms.Label();
            this.nudBrgne = new System.Windows.Forms.NumericUpDown();
            this.lblEftsBrgne = new System.Windows.Forms.Label();
            this.lblNomVtments = new System.Windows.Forms.Label();
            this.lblPdsVtments = new System.Windows.Forms.Label();
            this.nudVtments = new System.Windows.Forms.NumericUpDown();
            this.lblEftsVtments = new System.Windows.Forms.Label();
            this.lblNomBuste = new System.Windows.Forms.Label();
            this.lblPdsBuste = new System.Windows.Forms.Label();
            this.lblNbBuste = new System.Windows.Forms.Label();
            this.lblEftBuste = new System.Windows.Forms.Label();
            this.tpGants = new System.Windows.Forms.TabPage();
            this.lblPrpieteMton = new System.Windows.Forms.Label();
            this.lblPrpieteMitne = new System.Windows.Forms.Label();
            this.lblPrpieteGntlet = new System.Windows.Forms.Label();
            this.lblPrpieteGntMles = new System.Windows.Forms.Label();
            this.lblPrpieteGants = new System.Windows.Forms.Label();
            this.lblVleurMton = new System.Windows.Forms.Label();
            this.lblVleurMitne = new System.Windows.Forms.Label();
            this.lblVleurGntlet = new System.Windows.Forms.Label();
            this.lblVleurGntMles = new System.Windows.Forms.Label();
            this.lblVleurGants = new System.Windows.Forms.Label();
            this.lblVleurlblDescDeuxGants = new System.Windows.Forms.Label();
            this.lblVleurlblDescGants = new System.Windows.Forms.Label();
            this.chkMton = new System.Windows.Forms.CheckBox();
            this.chkMitne = new System.Windows.Forms.CheckBox();
            this.chkGntlet = new System.Windows.Forms.CheckBox();
            this.chkGntMles = new System.Windows.Forms.CheckBox();
            this.lblNomMton = new System.Windows.Forms.Label();
            this.lblPdsMton = new System.Windows.Forms.Label();
            this.nudMton = new System.Windows.Forms.NumericUpDown();
            this.lblEftsMton = new System.Windows.Forms.Label();
            this.lblNomMitne = new System.Windows.Forms.Label();
            this.lblPdsMitne = new System.Windows.Forms.Label();
            this.nudMitne = new System.Windows.Forms.NumericUpDown();
            this.lblEftsMitne = new System.Windows.Forms.Label();
            this.lblNomGntlet = new System.Windows.Forms.Label();
            this.lblPdsGntlet = new System.Windows.Forms.Label();
            this.nudGntlet = new System.Windows.Forms.NumericUpDown();
            this.lblEftsGntlet = new System.Windows.Forms.Label();
            this.lblNomGntMles = new System.Windows.Forms.Label();
            this.lblPdsGntMles = new System.Windows.Forms.Label();
            this.nudGntMles = new System.Windows.Forms.NumericUpDown();
            this.lblEftsGntMles = new System.Windows.Forms.Label();
            this.lblNomGants = new System.Windows.Forms.Label();
            this.lblPdsGants = new System.Windows.Forms.Label();
            this.lblNbGants = new System.Windows.Forms.Label();
            this.lblEftGants = new System.Windows.Forms.Label();
            this.tpGenouillere = new System.Windows.Forms.TabPage();
            this.lblPrpieteCmide = new System.Windows.Forms.Label();
            this.lblPrpietePntlonTle = new System.Windows.Forms.Label();
            this.lblPrpieteCuissrd = new System.Windows.Forms.Label();
            this.lblPrpieteGenouilleres = new System.Windows.Forms.Label();
            this.lblVleurCmide = new System.Windows.Forms.Label();
            this.lblVleurPntlonTle = new System.Windows.Forms.Label();
            this.lblVleurCuissrd = new System.Windows.Forms.Label();
            this.lblVleurGenouilleres = new System.Windows.Forms.Label();
            this.lblDescDeuxGenouilleres = new System.Windows.Forms.Label();
            this.lblDescGenouilleres = new System.Windows.Forms.Label();
            this.chkCmide = new System.Windows.Forms.CheckBox();
            this.chkPntlonTle = new System.Windows.Forms.CheckBox();
            this.chkCuissrd = new System.Windows.Forms.CheckBox();
            this.lblNomCmide = new System.Windows.Forms.Label();
            this.lblPdsCmide = new System.Windows.Forms.Label();
            this.nudCmide = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCmide = new System.Windows.Forms.Label();
            this.lblNomPntlonTle = new System.Windows.Forms.Label();
            this.lblPdsPntlonTle = new System.Windows.Forms.Label();
            this.nudPntlonTle = new System.Windows.Forms.NumericUpDown();
            this.lblEftsPntlonTle = new System.Windows.Forms.Label();
            this.lblNomCuissrd = new System.Windows.Forms.Label();
            this.lblPdsCuissrd = new System.Windows.Forms.Label();
            this.nudCuissrd = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCuissrd = new System.Windows.Forms.Label();
            this.lblNomGenouilleres = new System.Windows.Forms.Label();
            this.lblPdsGenouilleres = new System.Windows.Forms.Label();
            this.lblNbGenouilleres = new System.Windows.Forms.Label();
            this.lblEftGenouilleres = new System.Windows.Forms.Label();
            this.tpChaussures = new System.Windows.Forms.TabPage();
            this.lblPrpieteSbton = new System.Windows.Forms.Label();
            this.lblVleurSbton = new System.Windows.Forms.Label();
            this.chkSbton = new System.Windows.Forms.CheckBox();
            this.lblNomSbton = new System.Windows.Forms.Label();
            this.lblPdsSbton = new System.Windows.Forms.Label();
            this.nudSbton = new System.Windows.Forms.NumericUpDown();
            this.lblEftsSbton = new System.Windows.Forms.Label();
            this.lblPrpieteChssuresCuir = new System.Windows.Forms.Label();
            this.lblPrpieteSndles = new System.Windows.Forms.Label();
            this.lblPrpieteChaussures = new System.Windows.Forms.Label();
            this.lblDescDeuxChaussures = new System.Windows.Forms.Label();
            this.lblDescChaussures = new System.Windows.Forms.Label();
            this.lblVleurChssuresCuir = new System.Windows.Forms.Label();
            this.lblVleurSndles = new System.Windows.Forms.Label();
            this.lblVleurChaussures = new System.Windows.Forms.Label();
            this.chkChssuresCuir = new System.Windows.Forms.CheckBox();
            this.chkSndles = new System.Windows.Forms.CheckBox();
            this.lblNomChssuresCuir = new System.Windows.Forms.Label();
            this.lblPdsChssuresCuir = new System.Windows.Forms.Label();
            this.nudChssuresCuir = new System.Windows.Forms.NumericUpDown();
            this.lblEftsChssuresCuir = new System.Windows.Forms.Label();
            this.lblNomSndles = new System.Windows.Forms.Label();
            this.lblPdsSndles = new System.Windows.Forms.Label();
            this.nudSndles = new System.Windows.Forms.NumericUpDown();
            this.lblEftsSndles = new System.Windows.Forms.Label();
            this.lblNomChssures = new System.Windows.Forms.Label();
            this.lblPdsChssures = new System.Windows.Forms.Label();
            this.lblNbChssures = new System.Windows.Forms.Label();
            this.lblEftsChssures = new System.Windows.Forms.Label();
            this.tpBouclier = new System.Windows.Forms.TabPage();
            this.lblPrpieteCpeElfique = new System.Windows.Forms.Label();
            this.lblVleurCpeElfique = new System.Windows.Forms.Label();
            this.chkCpeElfique = new System.Windows.Forms.CheckBox();
            this.lblNomCpeElfique = new System.Windows.Forms.Label();
            this.lblPdsCpeElfique = new System.Windows.Forms.Label();
            this.nudCpeElfique = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCpeElfique = new System.Windows.Forms.Label();
            this.lblPrpietePlta = new System.Windows.Forms.Label();
            this.lblPrpieteBclrBze = new System.Windows.Forms.Label();
            this.lblPrpieteBclrAmde = new System.Windows.Forms.Label();
            this.lblPrpietePvois = new System.Windows.Forms.Label();
            this.lblPrpieteEcu = new System.Windows.Forms.Label();
            this.lblPrpieteBoucliers = new System.Windows.Forms.Label();
            this.lblVleurPlta = new System.Windows.Forms.Label();
            this.lblVleurBclrBze = new System.Windows.Forms.Label();
            this.lblVleurBclrAmde = new System.Windows.Forms.Label();
            this.lblVleurPvois = new System.Windows.Forms.Label();
            this.lblVleurEcu = new System.Windows.Forms.Label();
            this.lblVleurBouclier = new System.Windows.Forms.Label();
            this.lblDescDeuxBoucliers = new System.Windows.Forms.Label();
            this.chkPlta = new System.Windows.Forms.CheckBox();
            this.chkBclrBze = new System.Windows.Forms.CheckBox();
            this.chkBclrAmde = new System.Windows.Forms.CheckBox();
            this.chkPvois = new System.Windows.Forms.CheckBox();
            this.chkEcu = new System.Windows.Forms.CheckBox();
            this.lblNomPlta = new System.Windows.Forms.Label();
            this.lblPdsPlta = new System.Windows.Forms.Label();
            this.nudPlta = new System.Windows.Forms.NumericUpDown();
            this.lblEftsPlta = new System.Windows.Forms.Label();
            this.lblNomBclrBze = new System.Windows.Forms.Label();
            this.lblPdsBclrBze = new System.Windows.Forms.Label();
            this.nudBclrBze = new System.Windows.Forms.NumericUpDown();
            this.lblEftsBclrBze = new System.Windows.Forms.Label();
            this.lblNomBclrAmde = new System.Windows.Forms.Label();
            this.lblPdsBclrAmde = new System.Windows.Forms.Label();
            this.nudBclrAmde = new System.Windows.Forms.NumericUpDown();
            this.lblEftsBclrAmde = new System.Windows.Forms.Label();
            this.lblNomPvois = new System.Windows.Forms.Label();
            this.lblPdsPvois = new System.Windows.Forms.Label();
            this.nudPvois = new System.Windows.Forms.NumericUpDown();
            this.lblEftsPvois = new System.Windows.Forms.Label();
            this.lblNomEcu = new System.Windows.Forms.Label();
            this.lblPdsEcu = new System.Windows.Forms.Label();
            this.nudEcu = new System.Windows.Forms.NumericUpDown();
            this.lblEftsEcu = new System.Windows.Forms.Label();
            this.lblNomBoucliers = new System.Windows.Forms.Label();
            this.lblPdsBoucliers = new System.Windows.Forms.Label();
            this.lblNbBoucliers = new System.Windows.Forms.Label();
            this.lblEftsBoucliers = new System.Windows.Forms.Label();
            this.tpObjets = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.chkPrre = new System.Windows.Forms.CheckBox();
            this.lblTllePrre = new System.Windows.Forms.Label();
            this.lblNomPrre = new System.Windows.Forms.Label();
            this.lblPdsPrre = new System.Windows.Forms.Label();
            this.nudPrre = new System.Windows.Forms.NumericUpDown();
            this.lblEftsPrre = new System.Windows.Forms.Label();
            this.lblVleurCrauFr = new System.Windows.Forms.Label();
            this.chkCrauFr = new System.Windows.Forms.CheckBox();
            this.lblTlleCrauFr = new System.Windows.Forms.Label();
            this.lblNomCrauFr = new System.Windows.Forms.Label();
            this.lblPdsCrauFr = new System.Windows.Forms.Label();
            this.nudCrauFr = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCrauFr = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chkCrauBois = new System.Windows.Forms.CheckBox();
            this.lblTlleCrauBois = new System.Windows.Forms.Label();
            this.lblNomCrauBois = new System.Windows.Forms.Label();
            this.lblPdsCrauBois = new System.Windows.Forms.Label();
            this.nudCrauBois = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCrauBois = new System.Windows.Forms.Label();
            this.lblVleurFlcheArgent = new System.Windows.Forms.Label();
            this.chkFlcheArgent = new System.Windows.Forms.CheckBox();
            this.lblTlleFlcheArgent = new System.Windows.Forms.Label();
            this.lblnomFlcheArgent = new System.Windows.Forms.Label();
            this.lblPdsFlcheArgent = new System.Windows.Forms.Label();
            this.nudFlcheArgent = new System.Windows.Forms.NumericUpDown();
            this.lblEftsFlcheArgent = new System.Windows.Forms.Label();
            this.lblVleurFlcheFr = new System.Windows.Forms.Label();
            this.chkFlcheFr = new System.Windows.Forms.CheckBox();
            this.lblTlleFlcheFr = new System.Windows.Forms.Label();
            this.lblNomFlcheFr = new System.Windows.Forms.Label();
            this.lblPdsFlcheFr = new System.Windows.Forms.Label();
            this.nudFlcheFr = new System.Windows.Forms.NumericUpDown();
            this.lblDgtsFlcheFr = new System.Windows.Forms.Label();
            this.lblVleurFlcheBois = new System.Windows.Forms.Label();
            this.chkFlcheBois = new System.Windows.Forms.CheckBox();
            this.lblTlleFlcheBois = new System.Windows.Forms.Label();
            this.lblNomFlcheBois = new System.Windows.Forms.Label();
            this.lblPdsFlcheBois = new System.Windows.Forms.Label();
            this.nudFlcheBois = new System.Windows.Forms.NumericUpDown();
            this.lblEftsFlcheBois = new System.Windows.Forms.Label();
            this.lblVleurCntrePson = new System.Windows.Forms.Label();
            this.chkCntrePson = new System.Windows.Forms.CheckBox();
            this.lblTlleCntrePson = new System.Windows.Forms.Label();
            this.lblNomCntrePson = new System.Windows.Forms.Label();
            this.lblPdsCntrePson = new System.Windows.Forms.Label();
            this.nudCntrePson = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCntrePson = new System.Windows.Forms.Label();
            this.lblVleurPlnteMcnale = new System.Windows.Forms.Label();
            this.chkPlnteMcnale = new System.Windows.Forms.CheckBox();
            this.lblTllePlnteMcnale = new System.Windows.Forms.Label();
            this.lblNomPlnteMcnale = new System.Windows.Forms.Label();
            this.lblPdsPlnteMcnale = new System.Windows.Forms.Label();
            this.nudPlnteMcnale = new System.Windows.Forms.NumericUpDown();
            this.lblEftsPlnteMcnale = new System.Windows.Forms.Label();
            this.lblVleurCvture = new System.Windows.Forms.Label();
            this.chkCvture = new System.Windows.Forms.CheckBox();
            this.lblTlleCvture = new System.Windows.Forms.Label();
            this.lblNomCvture = new System.Windows.Forms.Label();
            this.lblPdsCvture = new System.Windows.Forms.Label();
            this.nudCvture = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCvture = new System.Windows.Forms.Label();
            this.lblVleurMhoir = new System.Windows.Forms.Label();
            this.chkMhoir = new System.Windows.Forms.CheckBox();
            this.lblTlleMhoir = new System.Windows.Forms.Label();
            this.lblNomMhoir = new System.Windows.Forms.Label();
            this.lblPdsMhoir = new System.Windows.Forms.Label();
            this.nudMhoir = new System.Windows.Forms.NumericUpDown();
            this.lblEftsMhoir = new System.Windows.Forms.Label();
            this.lblVleurTnte = new System.Windows.Forms.Label();
            this.lblVleurSc = new System.Windows.Forms.Label();
            this.lblVleurOte = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblVleurTrche = new System.Windows.Forms.Label();
            this.lblVleurObjets = new System.Windows.Forms.Label();
            this.chkTnte = new System.Windows.Forms.CheckBox();
            this.chkSc = new System.Windows.Forms.CheckBox();
            this.chkOte = new System.Windows.Forms.CheckBox();
            this.chkCrde = new System.Windows.Forms.CheckBox();
            this.chkTrche = new System.Windows.Forms.CheckBox();
            this.lblTlleTnte = new System.Windows.Forms.Label();
            this.lblNomTnte = new System.Windows.Forms.Label();
            this.lblPdsTnte = new System.Windows.Forms.Label();
            this.nudTnte = new System.Windows.Forms.NumericUpDown();
            this.lblEftsTnte = new System.Windows.Forms.Label();
            this.lblTlleSc = new System.Windows.Forms.Label();
            this.lblNomSc = new System.Windows.Forms.Label();
            this.lblPdsSc = new System.Windows.Forms.Label();
            this.nudSc = new System.Windows.Forms.NumericUpDown();
            this.lblEftsSc = new System.Windows.Forms.Label();
            this.lblTlleOte = new System.Windows.Forms.Label();
            this.lblNomOte = new System.Windows.Forms.Label();
            this.lblPdsOte = new System.Windows.Forms.Label();
            this.nudOte = new System.Windows.Forms.NumericUpDown();
            this.lblEftsOte = new System.Windows.Forms.Label();
            this.lblTlleCrde = new System.Windows.Forms.Label();
            this.lblTlleTrche = new System.Windows.Forms.Label();
            this.lblTlleObjets = new System.Windows.Forms.Label();
            this.lblNomCrde = new System.Windows.Forms.Label();
            this.lblPdsCrde = new System.Windows.Forms.Label();
            this.nudCrde = new System.Windows.Forms.NumericUpDown();
            this.lblEftsCrde = new System.Windows.Forms.Label();
            this.lblNomTrche = new System.Windows.Forms.Label();
            this.lblPdsTrche = new System.Windows.Forms.Label();
            this.nudTrche = new System.Windows.Forms.NumericUpDown();
            this.lblEftsTrche = new System.Windows.Forms.Label();
            this.lblNomObjts = new System.Windows.Forms.Label();
            this.lblPdsObjts = new System.Windows.Forms.Label();
            this.lblNbObjts = new System.Windows.Forms.Label();
            this.lblEftsObjts = new System.Windows.Forms.Label();
            this.rchTxtIvtaires = new System.Windows.Forms.RichTextBox();
            this.tcSortilege = new System.Windows.Forms.TabControl();
            this.tpAqua = new System.Windows.Forms.TabPage();
            this.chkMgieAqua = new System.Windows.Forms.CheckBox();
            this.lblMgieAqua = new System.Windows.Forms.Label();
            this.lblNomMAqua = new System.Windows.Forms.Label();
            this.tpIgnis = new System.Windows.Forms.TabPage();
            this.chkMgieIgnis = new System.Windows.Forms.CheckBox();
            this.lblMgieIgnis = new System.Windows.Forms.Label();
            this.lblNomMIgnis = new System.Windows.Forms.Label();
            this.tpCeleste = new System.Windows.Forms.TabPage();
            this.chkMgieCeleste = new System.Windows.Forms.CheckBox();
            this.lblMgieCeleste = new System.Windows.Forms.Label();
            this.lblNomMCeleste = new System.Windows.Forms.Label();
            this.tpTerrestre = new System.Windows.Forms.TabPage();
            this.chkMgieTerrestre = new System.Windows.Forms.CheckBox();
            this.lblMgieTerrestre = new System.Windows.Forms.Label();
            this.lblNomMTerrestre = new System.Windows.Forms.Label();
            this.tpNature = new System.Windows.Forms.TabPage();
            this.chkMgieNatureMetamphse = new System.Windows.Forms.CheckBox();
            this.lblMgieNatureMetamphse = new System.Windows.Forms.Label();
            this.chkMgieNatureVsionNoir = new System.Windows.Forms.CheckBox();
            this.lblMgieNatureVsionNoir = new System.Windows.Forms.Label();
            this.chkMgieNatureChgmTemp = new System.Windows.Forms.CheckBox();
            this.lblMgieNatureChgmTemp = new System.Windows.Forms.Label();
            this.chkMgieNatureInvoc = new System.Windows.Forms.CheckBox();
            this.lblMgieNatureInvoc = new System.Windows.Forms.Label();
            this.chkMgieNatureComm = new System.Windows.Forms.CheckBox();
            this.lblMgieNatureComm = new System.Windows.Forms.Label();
            this.lblNomMNature = new System.Windows.Forms.Label();
            this.tpDivine = new System.Windows.Forms.TabPage();
            this.chkMgieDivineDvnation = new System.Windows.Forms.CheckBox();
            this.lblMgieDivineDvnation = new System.Windows.Forms.Label();
            this.chkMgieDivineBene = new System.Windows.Forms.CheckBox();
            this.lblMgieDivineBene = new System.Windows.Forms.Label();
            this.chkMgieDivineGueri = new System.Windows.Forms.CheckBox();
            this.lblMgieDivineGueri = new System.Windows.Forms.Label();
            this.chkMgieDivineRestauration = new System.Windows.Forms.CheckBox();
            this.lblMgieDivineRestauration = new System.Windows.Forms.Label();
            this.chkMgieDivineBclrPrtc = new System.Windows.Forms.CheckBox();
            this.lblMgieDivineBclrPrtc = new System.Windows.Forms.Label();
            this.lblNomMDivine = new System.Windows.Forms.Label();
            this.tpDemoniaque = new System.Windows.Forms.TabPage();
            this.chkMgieDemoniaqueIllusions = new System.Windows.Forms.CheckBox();
            this.lblMgieDemoniaqueIllusion = new System.Windows.Forms.Label();
            this.chkMgieDemoniaqueCntrole = new System.Windows.Forms.CheckBox();
            this.lblMgieDemoniaqueCntrole = new System.Windows.Forms.Label();
            this.chkMgieDemoniaqueMldction = new System.Windows.Forms.CheckBox();
            this.lblMgieDemoniaqueMldction = new System.Windows.Forms.Label();
            this.chkMgieDemoniaqueNecro = new System.Windows.Forms.CheckBox();
            this.lblMgieDemoniaqueNecro = new System.Windows.Forms.Label();
            this.chkMgieDemoniaqueAbspton = new System.Windows.Forms.CheckBox();
            this.lblMgieDemoniaqueAbspton = new System.Windows.Forms.Label();
            this.lblNomMDemoniaque = new System.Windows.Forms.Label();
            this.tpNeutre = new System.Windows.Forms.TabPage();
            this.chkMgieNeutreTelkinesie = new System.Windows.Forms.CheckBox();
            this.lblMgieNeutreTelkinesie = new System.Windows.Forms.Label();
            this.chkMgieNeutreMsg = new System.Windows.Forms.CheckBox();
            this.lblMgieNeutreMsg = new System.Windows.Forms.Label();
            this.chkMgieNeutreSsie = new System.Windows.Forms.CheckBox();
            this.lblMgieNeutreSsie = new System.Windows.Forms.Label();
            this.chkMgieNeutreInvsbilté = new System.Windows.Forms.CheckBox();
            this.lblMgieNeutreInvsbilté = new System.Windows.Forms.Label();
            this.chkMgieNeutreAltration = new System.Windows.Forms.CheckBox();
            this.lblMgieNeutreAltration = new System.Windows.Forms.Label();
            this.lblNomMNeutre = new System.Windows.Forms.Label();
            this.rchTbSorts = new System.Windows.Forms.RichTextBox();
            this.btnViderRchTbInventaires = new System.Windows.Forms.Button();
            this.btnViderRchTbSortileges = new System.Windows.Forms.Button();
            this.lblChargeRestanteProgressBar = new System.Windows.Forms.Label();
            this.lblSeparationRestanteMax = new System.Windows.Forms.Label();
            this.lblChargeMaximale = new System.Windows.Forms.Label();
            this.txtChargeMaximale = new System.Windows.Forms.TextBox();
            this.txtChargeRestante = new System.Windows.Forms.TextBox();
            this.lblCuivre = new System.Windows.Forms.Label();
            this.lblArgent = new System.Windows.Forms.Label();
            this.lblOr = new System.Windows.Forms.Label();
            this.txtOr = new System.Windows.Forms.TextBox();
            this.txtArgent = new System.Windows.Forms.TextBox();
            this.txtCuivre = new System.Windows.Forms.TextBox();
            this.tcInventaires.SuspendLayout();
            this.tpArmes.SuspendLayout();
            this.tcArmes.SuspendLayout();
            this.tpEpee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudEpBtrde)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEpBois)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSbreCrbe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGlve)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEpLge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEpCrte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudScrmx)).BeginInit();
            this.tpLances.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudTrdnt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSrse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFrche)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudJvlot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCntus)).BeginInit();
            this.tpPoignards.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDgeAssin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFclGure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCtau)).BeginInit();
            this.tpHaches.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudHcheBhron)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFrncsque)).BeginInit();
            this.tpMasse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMrteauFgron)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMsueChne)).BeginInit();
            this.tpArc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFnde)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAblte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudArc)).BeginInit();
            this.tpChaînes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFaC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFouet)).BeginInit();
            this.tpBatons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSptreNeutre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBgteInfernale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCneLmiere)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBtonNture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudScptreTerre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBtonCelste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBgteFeu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCneAqua)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSctre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBtonChne)).BeginInit();
            this.tpArmures.SuspendLayout();
            this.tcArmure.SuspendLayout();
            this.tbCasque.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCsqueBrbre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChplFr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrvlre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMrn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCfeMle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSpghlm)).BeginInit();
            this.tpBuste.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrsBze)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRbeCuir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrsFr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCtphrcte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBrgne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVtments)).BeginInit();
            this.tpGants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMitne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGntlet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGntMles)).BeginInit();
            this.tpGenouillere.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCmide)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPntlonTle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCuissrd)).BeginInit();
            this.tpChaussures.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSbton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChssuresCuir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSndles)).BeginInit();
            this.tpBouclier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCpeElfique)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPlta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBclrBze)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBclrAmde)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPvois)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEcu)).BeginInit();
            this.tpObjets.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrauFr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrauBois)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlcheArgent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlcheFr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlcheBois)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCntrePson)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPlnteMcnale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCvture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMhoir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTnte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrde)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTrche)).BeginInit();
            this.tcSortilege.SuspendLayout();
            this.tpAqua.SuspendLayout();
            this.tpIgnis.SuspendLayout();
            this.tpCeleste.SuspendLayout();
            this.tpTerrestre.SuspendLayout();
            this.tpNature.SuspendLayout();
            this.tpDivine.SuspendLayout();
            this.tpDemoniaque.SuspendLayout();
            this.tpNeutre.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDgtsEpee
            // 
            this.lblDgtsEpee.AutoSize = true;
            this.lblDgtsEpee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDgtsEpee.Location = new System.Drawing.Point(397, 3);
            this.lblDgtsEpee.Name = "lblDgtsEpee";
            this.lblDgtsEpee.Size = new System.Drawing.Size(41, 13);
            this.lblDgtsEpee.TabIndex = 5;
            this.lblDgtsEpee.Text = "Dégâts";
            // 
            // lblTpeEpee
            // 
            this.lblTpeEpee.AutoSize = true;
            this.lblTpeEpee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTpeEpee.Location = new System.Drawing.Point(325, 3);
            this.lblTpeEpee.Name = "lblTpeEpee";
            this.lblTpeEpee.Size = new System.Drawing.Size(31, 13);
            this.lblTpeEpee.TabIndex = 4;
            this.lblTpeEpee.Text = "Type";
            // 
            // lblNbEpee
            // 
            this.lblNbEpee.AutoSize = true;
            this.lblNbEpee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbEpee.Location = new System.Drawing.Point(266, 3);
            this.lblNbEpee.Name = "lblNbEpee";
            this.lblNbEpee.Size = new System.Drawing.Size(44, 13);
            this.lblNbEpee.TabIndex = 3;
            this.lblNbEpee.Text = "Nombre";
            // 
            // lblPdsEpee
            // 
            this.lblPdsEpee.AutoSize = true;
            this.lblPdsEpee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsEpee.Location = new System.Drawing.Point(128, 3);
            this.lblPdsEpee.Name = "lblPdsEpee";
            this.lblPdsEpee.Size = new System.Drawing.Size(33, 13);
            this.lblPdsEpee.TabIndex = 2;
            this.lblPdsEpee.Text = "Poids";
            // 
            // lblPrtEpee
            // 
            this.lblPrtEpee.AutoSize = true;
            this.lblPrtEpee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrtEpee.Location = new System.Drawing.Point(200, 3);
            this.lblPrtEpee.Name = "lblPrtEpee";
            this.lblPrtEpee.Size = new System.Drawing.Size(38, 13);
            this.lblPrtEpee.TabIndex = 1;
            this.lblPrtEpee.Text = "Portée";
            // 
            // lblNomEpee
            // 
            this.lblNomEpee.AutoSize = true;
            this.lblNomEpee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomEpee.Location = new System.Drawing.Point(34, 3);
            this.lblNomEpee.Name = "lblNomEpee";
            this.lblNomEpee.Size = new System.Drawing.Size(29, 13);
            this.lblNomEpee.TabIndex = 0;
            this.lblNomEpee.Text = "Nom";
            // 
            // btnSauvegarder
            // 
            this.btnSauvegarder.Location = new System.Drawing.Point(729, 297);
            this.btnSauvegarder.Name = "btnSauvegarder";
            this.btnSauvegarder.Size = new System.Drawing.Size(412, 192);
            this.btnSauvegarder.TabIndex = 5;
            this.btnSauvegarder.Text = "Sauvegarder";
            this.btnSauvegarder.UseVisualStyleBackColor = true;
            this.btnSauvegarder.Click += new System.EventHandler(this.btnSauvegarder_Click);
            // 
            // tcInventaires
            // 
            this.tcInventaires.Controls.Add(this.tpArmes);
            this.tcInventaires.Controls.Add(this.tpArmures);
            this.tcInventaires.Controls.Add(this.tpObjets);
            this.tcInventaires.Location = new System.Drawing.Point(12, 12);
            this.tcInventaires.Name = "tcInventaires";
            this.tcInventaires.SelectedIndex = 0;
            this.tcInventaires.Size = new System.Drawing.Size(711, 278);
            this.tcInventaires.TabIndex = 6;
            // 
            // tpArmes
            // 
            this.tpArmes.AutoScroll = true;
            this.tpArmes.Controls.Add(this.tcArmes);
            this.tpArmes.Location = new System.Drawing.Point(4, 22);
            this.tpArmes.Name = "tpArmes";
            this.tpArmes.Padding = new System.Windows.Forms.Padding(3);
            this.tpArmes.Size = new System.Drawing.Size(703, 252);
            this.tpArmes.TabIndex = 0;
            this.tpArmes.Text = "Armes";
            this.tpArmes.UseVisualStyleBackColor = true;
            // 
            // tcArmes
            // 
            this.tcArmes.Controls.Add(this.tpEpee);
            this.tcArmes.Controls.Add(this.tpLances);
            this.tcArmes.Controls.Add(this.tpPoignards);
            this.tcArmes.Controls.Add(this.tpHaches);
            this.tcArmes.Controls.Add(this.tpMasse);
            this.tcArmes.Controls.Add(this.tpArc);
            this.tcArmes.Controls.Add(this.tpChaînes);
            this.tcArmes.Controls.Add(this.tpBatons);
            this.tcArmes.Location = new System.Drawing.Point(0, 0);
            this.tcArmes.Name = "tcArmes";
            this.tcArmes.SelectedIndex = 0;
            this.tcArmes.Size = new System.Drawing.Size(697, 298);
            this.tcArmes.TabIndex = 0;
            // 
            // tpEpee
            // 
            this.tpEpee.AutoScroll = true;
            this.tpEpee.Controls.Add(this.lblPrpieteEpBtrde);
            this.tpEpee.Controls.Add(this.lblDescEpees);
            this.tpEpee.Controls.Add(this.lblVleurEpBtrde);
            this.tpEpee.Controls.Add(this.nudEpBtrde);
            this.tpEpee.Controls.Add(this.chkEpBtrde);
            this.tpEpee.Controls.Add(this.lblNomEpBtrde);
            this.tpEpee.Controls.Add(this.lblPdsEpBtrde);
            this.tpEpee.Controls.Add(this.lblPrteEpBtrde);
            this.tpEpee.Controls.Add(this.lblTpeEpBtrde);
            this.tpEpee.Controls.Add(this.lblDgtsEpBtrde);
            this.tpEpee.Controls.Add(this.lblPrpieteEpBois);
            this.tpEpee.Controls.Add(this.lblVleurEpBois);
            this.tpEpee.Controls.Add(this.nudEpBois);
            this.tpEpee.Controls.Add(this.chkEpBois);
            this.tpEpee.Controls.Add(this.lblNomEpBois);
            this.tpEpee.Controls.Add(this.lblPdsEpBois);
            this.tpEpee.Controls.Add(this.lblPrteEpBois);
            this.tpEpee.Controls.Add(this.lblTpeEpBois);
            this.tpEpee.Controls.Add(this.lblDgtsEpBois);
            this.tpEpee.Controls.Add(this.lblPrpieteSbreCrbe);
            this.tpEpee.Controls.Add(this.lblPrpieteLte);
            this.tpEpee.Controls.Add(this.lblPrpieteGlve);
            this.tpEpee.Controls.Add(this.lblPrpieteEpLge);
            this.tpEpee.Controls.Add(this.lblPrpieteEpCrte);
            this.tpEpee.Controls.Add(this.lblPrpieteScrmx);
            this.tpEpee.Controls.Add(this.lblVleurSbreCrbe);
            this.tpEpee.Controls.Add(this.lblVleurLte);
            this.tpEpee.Controls.Add(this.lblVleurGlve);
            this.tpEpee.Controls.Add(this.lblVleurEpLge);
            this.tpEpee.Controls.Add(this.lblVleurEpCrte);
            this.tpEpee.Controls.Add(this.lblVleurScrmx);
            this.tpEpee.Controls.Add(this.lblPrpieteEpees);
            this.tpEpee.Controls.Add(this.lblVleurEpee);
            this.tpEpee.Controls.Add(this.nudSbreCrbe);
            this.tpEpee.Controls.Add(this.nudLte);
            this.tpEpee.Controls.Add(this.chkSbreCrbe);
            this.tpEpee.Controls.Add(this.chkLte);
            this.tpEpee.Controls.Add(this.chkGlve);
            this.tpEpee.Controls.Add(this.chkEpLge);
            this.tpEpee.Controls.Add(this.chkEpCrte);
            this.tpEpee.Controls.Add(this.chkScrmx);
            this.tpEpee.Controls.Add(this.lblNomSbreCrbe);
            this.tpEpee.Controls.Add(this.lblPdsSbreCrbe);
            this.tpEpee.Controls.Add(this.lblPrteSbreCrbe);
            this.tpEpee.Controls.Add(this.lblTpeSbreCrbe);
            this.tpEpee.Controls.Add(this.lblDgtsSbreCrbe);
            this.tpEpee.Controls.Add(this.lblNomLte);
            this.tpEpee.Controls.Add(this.lblPdsLte);
            this.tpEpee.Controls.Add(this.lblPrteLte);
            this.tpEpee.Controls.Add(this.lblTpeLte);
            this.tpEpee.Controls.Add(this.lblDgtsLte);
            this.tpEpee.Controls.Add(this.lblNomGlve);
            this.tpEpee.Controls.Add(this.lblPdsGlve);
            this.tpEpee.Controls.Add(this.lblPrteGlve);
            this.tpEpee.Controls.Add(this.nudGlve);
            this.tpEpee.Controls.Add(this.lblTpeGlve);
            this.tpEpee.Controls.Add(this.lblDgtsGlve);
            this.tpEpee.Controls.Add(this.lblNomEpLge);
            this.tpEpee.Controls.Add(this.lblPdsEpLge);
            this.tpEpee.Controls.Add(this.lblPrteEpLge);
            this.tpEpee.Controls.Add(this.nudEpLge);
            this.tpEpee.Controls.Add(this.lblTpeEpLge);
            this.tpEpee.Controls.Add(this.lblDgtsEpLge);
            this.tpEpee.Controls.Add(this.lblNomEpCrte);
            this.tpEpee.Controls.Add(this.lblPdsEpCrte);
            this.tpEpee.Controls.Add(this.lblPrteEpCrte);
            this.tpEpee.Controls.Add(this.nudEpCrte);
            this.tpEpee.Controls.Add(this.lblTpeEpCrte);
            this.tpEpee.Controls.Add(this.lblDgtsEpCrte);
            this.tpEpee.Controls.Add(this.lblNomScrmx);
            this.tpEpee.Controls.Add(this.lblPdsScrmx);
            this.tpEpee.Controls.Add(this.lblPrteScrmx);
            this.tpEpee.Controls.Add(this.nudScrmx);
            this.tpEpee.Controls.Add(this.lblTpeScrmx);
            this.tpEpee.Controls.Add(this.lblDgtsScrmx);
            this.tpEpee.Controls.Add(this.lblNomEpee);
            this.tpEpee.Controls.Add(this.lblPrtEpee);
            this.tpEpee.Controls.Add(this.lblPdsEpee);
            this.tpEpee.Controls.Add(this.lblNbEpee);
            this.tpEpee.Controls.Add(this.lblTpeEpee);
            this.tpEpee.Controls.Add(this.lblDgtsEpee);
            this.tpEpee.Location = new System.Drawing.Point(4, 22);
            this.tpEpee.Name = "tpEpee";
            this.tpEpee.Padding = new System.Windows.Forms.Padding(3);
            this.tpEpee.Size = new System.Drawing.Size(689, 272);
            this.tpEpee.TabIndex = 0;
            this.tpEpee.Text = "Épées";
            this.tpEpee.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteEpBtrde
            // 
            this.lblPrpieteEpBtrde.AutoSize = true;
            this.lblPrpieteEpBtrde.Location = new System.Drawing.Point(552, 202);
            this.lblPrpieteEpBtrde.Name = "lblPrpieteEpBtrde";
            this.lblPrpieteEpBtrde.Size = new System.Drawing.Size(78, 13);
            this.lblPrpieteEpBtrde.TabIndex = 124;
            this.lblPrpieteEpBtrde.Text = "AuM, AdM, DT";
            // 
            // lblDescEpees
            // 
            this.lblDescEpees.AutoSize = true;
            this.lblDescEpees.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescEpees.Location = new System.Drawing.Point(10, 239);
            this.lblDescEpees.Name = "lblDescEpees";
            this.lblDescEpees.Size = new System.Drawing.Size(518, 13);
            this.lblDescEpees.TabIndex = 101;
            this.lblDescEpees.Text = "AuM : Arme à une main; AdM : Arme à deux mains; UsT : Un seul côté tranchant, DT " +
    ": Deux côtés tranchant";
            // 
            // lblVleurEpBtrde
            // 
            this.lblVleurEpBtrde.AutoSize = true;
            this.lblVleurEpBtrde.Location = new System.Drawing.Point(454, 202);
            this.lblVleurEpBtrde.Name = "lblVleurEpBtrde";
            this.lblVleurEpBtrde.Size = new System.Drawing.Size(82, 13);
            this.lblVleurEpBtrde.TabIndex = 123;
            this.lblVleurEpBtrde.Text = "3 po, 5 pa, 5 pc";
            // 
            // nudEpBtrde
            // 
            this.nudEpBtrde.Location = new System.Drawing.Point(269, 200);
            this.nudEpBtrde.Name = "nudEpBtrde";
            this.nudEpBtrde.Size = new System.Drawing.Size(41, 20);
            this.nudEpBtrde.TabIndex = 122;
            this.nudEpBtrde.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudEpBtrde.ValueChanged += new System.EventHandler(this.nudEpBtrde_ValueChanged);
            // 
            // chkEpBtrde
            // 
            this.chkEpBtrde.AutoSize = true;
            this.chkEpBtrde.Location = new System.Drawing.Point(13, 202);
            this.chkEpBtrde.Name = "chkEpBtrde";
            this.chkEpBtrde.Size = new System.Drawing.Size(15, 14);
            this.chkEpBtrde.TabIndex = 121;
            this.chkEpBtrde.UseVisualStyleBackColor = true;
            this.chkEpBtrde.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomEpBtrde
            // 
            this.lblNomEpBtrde.AutoSize = true;
            this.lblNomEpBtrde.Location = new System.Drawing.Point(34, 202);
            this.lblNomEpBtrde.Name = "lblNomEpBtrde";
            this.lblNomEpBtrde.Size = new System.Drawing.Size(71, 13);
            this.lblNomEpBtrde.TabIndex = 116;
            this.lblNomEpBtrde.Text = "Épée bâtarde";
            // 
            // lblPdsEpBtrde
            // 
            this.lblPdsEpBtrde.AutoSize = true;
            this.lblPdsEpBtrde.Location = new System.Drawing.Point(128, 202);
            this.lblPdsEpBtrde.Name = "lblPdsEpBtrde";
            this.lblPdsEpBtrde.Size = new System.Drawing.Size(40, 13);
            this.lblPdsEpBtrde.TabIndex = 117;
            this.lblPdsEpBtrde.Text = "1,25kg";
            // 
            // lblPrteEpBtrde
            // 
            this.lblPrteEpBtrde.AutoSize = true;
            this.lblPrteEpBtrde.Location = new System.Drawing.Point(200, 202);
            this.lblPrteEpBtrde.Name = "lblPrteEpBtrde";
            this.lblPrteEpBtrde.Size = new System.Drawing.Size(36, 13);
            this.lblPrteEpBtrde.TabIndex = 118;
            this.lblPrteEpBtrde.Text = "90 cm";
            // 
            // lblTpeEpBtrde
            // 
            this.lblTpeEpBtrde.AutoSize = true;
            this.lblTpeEpBtrde.Location = new System.Drawing.Point(325, 202);
            this.lblTpeEpBtrde.Name = "lblTpeEpBtrde";
            this.lblTpeEpBtrde.Size = new System.Drawing.Size(56, 13);
            this.lblTpeEpBtrde.TabIndex = 119;
            this.lblTpeEpBtrde.Text = "Tranchant";
            // 
            // lblDgtsEpBtrde
            // 
            this.lblDgtsEpBtrde.AutoSize = true;
            this.lblDgtsEpBtrde.Location = new System.Drawing.Point(397, 202);
            this.lblDgtsEpBtrde.Name = "lblDgtsEpBtrde";
            this.lblDgtsEpBtrde.Size = new System.Drawing.Size(48, 13);
            this.lblDgtsEpBtrde.TabIndex = 120;
            this.lblDgtsEpBtrde.Text = "2/1d8+2";
            // 
            // lblPrpieteEpBois
            // 
            this.lblPrpieteEpBois.AutoSize = true;
            this.lblPrpieteEpBois.Location = new System.Drawing.Point(552, 177);
            this.lblPrpieteEpBois.Name = "lblPrpieteEpBois";
            this.lblPrpieteEpBois.Size = new System.Drawing.Size(29, 13);
            this.lblPrpieteEpBois.TabIndex = 115;
            this.lblPrpieteEpBois.Text = "AuM";
            // 
            // lblVleurEpBois
            // 
            this.lblVleurEpBois.AutoSize = true;
            this.lblVleurEpBois.Location = new System.Drawing.Point(454, 177);
            this.lblVleurEpBois.Name = "lblVleurEpBois";
            this.lblVleurEpBois.Size = new System.Drawing.Size(55, 13);
            this.lblVleurEpBois.TabIndex = 114;
            this.lblVleurEpBois.Text = "6 pa, 5 pc";
            // 
            // nudEpBois
            // 
            this.nudEpBois.Location = new System.Drawing.Point(269, 175);
            this.nudEpBois.Name = "nudEpBois";
            this.nudEpBois.Size = new System.Drawing.Size(41, 20);
            this.nudEpBois.TabIndex = 113;
            this.nudEpBois.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudEpBois.ValueChanged += new System.EventHandler(this.nudEpBois_ValueChanged);
            // 
            // chkEpBois
            // 
            this.chkEpBois.AutoSize = true;
            this.chkEpBois.Location = new System.Drawing.Point(13, 177);
            this.chkEpBois.Name = "chkEpBois";
            this.chkEpBois.Size = new System.Drawing.Size(15, 14);
            this.chkEpBois.TabIndex = 112;
            this.chkEpBois.UseVisualStyleBackColor = true;
            this.chkEpBois.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomEpBois
            // 
            this.lblNomEpBois.AutoSize = true;
            this.lblNomEpBois.Location = new System.Drawing.Point(34, 177);
            this.lblNomEpBois.Name = "lblNomEpBois";
            this.lblNomEpBois.Size = new System.Drawing.Size(69, 13);
            this.lblNomEpBois.TabIndex = 107;
            this.lblNomEpBois.Text = "Épée en bois";
            // 
            // lblPdsEpBois
            // 
            this.lblPdsEpBois.AutoSize = true;
            this.lblPdsEpBois.Location = new System.Drawing.Point(128, 177);
            this.lblPdsEpBois.Name = "lblPdsEpBois";
            this.lblPdsEpBois.Size = new System.Drawing.Size(34, 13);
            this.lblPdsEpBois.TabIndex = 108;
            this.lblPdsEpBois.Text = "0,2kg";
            // 
            // lblPrteEpBois
            // 
            this.lblPrteEpBois.AutoSize = true;
            this.lblPrteEpBois.Location = new System.Drawing.Point(200, 177);
            this.lblPrteEpBois.Name = "lblPrteEpBois";
            this.lblPrteEpBois.Size = new System.Drawing.Size(36, 13);
            this.lblPrteEpBois.TabIndex = 109;
            this.lblPrteEpBois.Text = "50 cm";
            // 
            // lblTpeEpBois
            // 
            this.lblTpeEpBois.AutoSize = true;
            this.lblTpeEpBois.Location = new System.Drawing.Point(325, 177);
            this.lblTpeEpBois.Name = "lblTpeEpBois";
            this.lblTpeEpBois.Size = new System.Drawing.Size(62, 13);
            this.lblTpeEpBois.TabIndex = 110;
            this.lblTpeEpBois.Text = "Contondant";
            // 
            // lblDgtsEpBois
            // 
            this.lblDgtsEpBois.AutoSize = true;
            this.lblDgtsEpBois.Location = new System.Drawing.Point(397, 177);
            this.lblDgtsEpBois.Name = "lblDgtsEpBois";
            this.lblDgtsEpBois.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsEpBois.TabIndex = 111;
            this.lblDgtsEpBois.Text = "1";
            // 
            // lblPrpieteSbreCrbe
            // 
            this.lblPrpieteSbreCrbe.AutoSize = true;
            this.lblPrpieteSbreCrbe.Location = new System.Drawing.Point(552, 152);
            this.lblPrpieteSbreCrbe.Name = "lblPrpieteSbreCrbe";
            this.lblPrpieteSbreCrbe.Size = new System.Drawing.Size(55, 13);
            this.lblPrpieteSbreCrbe.TabIndex = 106;
            this.lblPrpieteSbreCrbe.Text = "UsT, AuM";
            // 
            // lblPrpieteLte
            // 
            this.lblPrpieteLte.AutoSize = true;
            this.lblPrpieteLte.Location = new System.Drawing.Point(552, 127);
            this.lblPrpieteLte.Name = "lblPrpieteLte";
            this.lblPrpieteLte.Size = new System.Drawing.Size(55, 13);
            this.lblPrpieteLte.TabIndex = 105;
            this.lblPrpieteLte.Text = "UsT, AuM";
            // 
            // lblPrpieteGlve
            // 
            this.lblPrpieteGlve.AutoSize = true;
            this.lblPrpieteGlve.Location = new System.Drawing.Point(552, 102);
            this.lblPrpieteGlve.Name = "lblPrpieteGlve";
            this.lblPrpieteGlve.Size = new System.Drawing.Size(50, 13);
            this.lblPrpieteGlve.TabIndex = 104;
            this.lblPrpieteGlve.Text = "DT, AuM";
            // 
            // lblPrpieteEpLge
            // 
            this.lblPrpieteEpLge.AutoSize = true;
            this.lblPrpieteEpLge.Location = new System.Drawing.Point(552, 77);
            this.lblPrpieteEpLge.Name = "lblPrpieteEpLge";
            this.lblPrpieteEpLge.Size = new System.Drawing.Size(50, 13);
            this.lblPrpieteEpLge.TabIndex = 103;
            this.lblPrpieteEpLge.Text = "DT, AdM";
            // 
            // lblPrpieteEpCrte
            // 
            this.lblPrpieteEpCrte.AutoSize = true;
            this.lblPrpieteEpCrte.Location = new System.Drawing.Point(552, 52);
            this.lblPrpieteEpCrte.Name = "lblPrpieteEpCrte";
            this.lblPrpieteEpCrte.Size = new System.Drawing.Size(50, 13);
            this.lblPrpieteEpCrte.TabIndex = 102;
            this.lblPrpieteEpCrte.Text = "DT, AuM";
            // 
            // lblPrpieteScrmx
            // 
            this.lblPrpieteScrmx.AutoSize = true;
            this.lblPrpieteScrmx.Location = new System.Drawing.Point(552, 27);
            this.lblPrpieteScrmx.Name = "lblPrpieteScrmx";
            this.lblPrpieteScrmx.Size = new System.Drawing.Size(55, 13);
            this.lblPrpieteScrmx.TabIndex = 100;
            this.lblPrpieteScrmx.Text = "UsT, AuM";
            // 
            // lblVleurSbreCrbe
            // 
            this.lblVleurSbreCrbe.AutoSize = true;
            this.lblVleurSbreCrbe.Location = new System.Drawing.Point(454, 152);
            this.lblVleurSbreCrbe.Name = "lblVleurSbreCrbe";
            this.lblVleurSbreCrbe.Size = new System.Drawing.Size(82, 13);
            this.lblVleurSbreCrbe.TabIndex = 99;
            this.lblVleurSbreCrbe.Text = "1 po, 8 pa, 5 pc";
            // 
            // lblVleurLte
            // 
            this.lblVleurLte.AutoSize = true;
            this.lblVleurLte.Location = new System.Drawing.Point(454, 127);
            this.lblVleurLte.Name = "lblVleurLte";
            this.lblVleurLte.Size = new System.Drawing.Size(55, 13);
            this.lblVleurLte.TabIndex = 98;
            this.lblVleurLte.Text = "1 po, 7 pa";
            // 
            // lblVleurGlve
            // 
            this.lblVleurGlve.AutoSize = true;
            this.lblVleurGlve.Location = new System.Drawing.Point(454, 102);
            this.lblVleurGlve.Name = "lblVleurGlve";
            this.lblVleurGlve.Size = new System.Drawing.Size(82, 13);
            this.lblVleurGlve.TabIndex = 97;
            this.lblVleurGlve.Text = "1 po, 2 pa, 4 pc";
            // 
            // lblVleurEpLge
            // 
            this.lblVleurEpLge.AutoSize = true;
            this.lblVleurEpLge.Location = new System.Drawing.Point(454, 77);
            this.lblVleurEpLge.Name = "lblVleurEpLge";
            this.lblVleurEpLge.Size = new System.Drawing.Size(82, 13);
            this.lblVleurEpLge.TabIndex = 96;
            this.lblVleurEpLge.Text = "2 po, 7 pa, 5 pc";
            // 
            // lblVleurEpCrte
            // 
            this.lblVleurEpCrte.AutoSize = true;
            this.lblVleurEpCrte.Location = new System.Drawing.Point(454, 52);
            this.lblVleurEpCrte.Name = "lblVleurEpCrte";
            this.lblVleurEpCrte.Size = new System.Drawing.Size(55, 13);
            this.lblVleurEpCrte.TabIndex = 95;
            this.lblVleurEpCrte.Text = "1 po, 8 pc";
            // 
            // lblVleurScrmx
            // 
            this.lblVleurScrmx.AutoSize = true;
            this.lblVleurScrmx.Location = new System.Drawing.Point(454, 27);
            this.lblVleurScrmx.Name = "lblVleurScrmx";
            this.lblVleurScrmx.Size = new System.Drawing.Size(28, 13);
            this.lblVleurScrmx.TabIndex = 94;
            this.lblVleurScrmx.Text = "2 po";
            // 
            // lblPrpieteEpees
            // 
            this.lblPrpieteEpees.AutoSize = true;
            this.lblPrpieteEpees.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteEpees.Location = new System.Drawing.Point(552, 3);
            this.lblPrpieteEpees.Name = "lblPrpieteEpees";
            this.lblPrpieteEpees.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteEpees.TabIndex = 93;
            this.lblPrpieteEpees.Text = "Propriété";
            // 
            // lblVleurEpee
            // 
            this.lblVleurEpee.AutoSize = true;
            this.lblVleurEpee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurEpee.Location = new System.Drawing.Point(454, 3);
            this.lblVleurEpee.Name = "lblVleurEpee";
            this.lblVleurEpee.Size = new System.Drawing.Size(37, 13);
            this.lblVleurEpee.TabIndex = 92;
            this.lblVleurEpee.Text = "Valeur";
            // 
            // nudSbreCrbe
            // 
            this.nudSbreCrbe.Location = new System.Drawing.Point(269, 150);
            this.nudSbreCrbe.Name = "nudSbreCrbe";
            this.nudSbreCrbe.Size = new System.Drawing.Size(41, 20);
            this.nudSbreCrbe.TabIndex = 91;
            this.nudSbreCrbe.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSbreCrbe.ValueChanged += new System.EventHandler(this.nudSbreCrbe_ValueChanged);
            // 
            // nudLte
            // 
            this.nudLte.Location = new System.Drawing.Point(269, 125);
            this.nudLte.Name = "nudLte";
            this.nudLte.Size = new System.Drawing.Size(41, 20);
            this.nudLte.TabIndex = 90;
            this.nudLte.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudLte.ValueChanged += new System.EventHandler(this.nudLte_ValueChanged);
            // 
            // chkSbreCrbe
            // 
            this.chkSbreCrbe.AutoSize = true;
            this.chkSbreCrbe.Location = new System.Drawing.Point(13, 152);
            this.chkSbreCrbe.Name = "chkSbreCrbe";
            this.chkSbreCrbe.Size = new System.Drawing.Size(15, 14);
            this.chkSbreCrbe.TabIndex = 89;
            this.chkSbreCrbe.UseVisualStyleBackColor = true;
            this.chkSbreCrbe.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkLte
            // 
            this.chkLte.AutoSize = true;
            this.chkLte.Location = new System.Drawing.Point(13, 127);
            this.chkLte.Name = "chkLte";
            this.chkLte.Size = new System.Drawing.Size(15, 14);
            this.chkLte.TabIndex = 88;
            this.chkLte.UseVisualStyleBackColor = true;
            this.chkLte.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkGlve
            // 
            this.chkGlve.AutoSize = true;
            this.chkGlve.Location = new System.Drawing.Point(13, 102);
            this.chkGlve.Name = "chkGlve";
            this.chkGlve.Size = new System.Drawing.Size(15, 14);
            this.chkGlve.TabIndex = 87;
            this.chkGlve.UseVisualStyleBackColor = true;
            this.chkGlve.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkEpLge
            // 
            this.chkEpLge.AutoSize = true;
            this.chkEpLge.Location = new System.Drawing.Point(13, 77);
            this.chkEpLge.Name = "chkEpLge";
            this.chkEpLge.Size = new System.Drawing.Size(15, 14);
            this.chkEpLge.TabIndex = 86;
            this.chkEpLge.UseVisualStyleBackColor = true;
            this.chkEpLge.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkEpCrte
            // 
            this.chkEpCrte.AutoSize = true;
            this.chkEpCrte.Location = new System.Drawing.Point(13, 52);
            this.chkEpCrte.Name = "chkEpCrte";
            this.chkEpCrte.Size = new System.Drawing.Size(15, 14);
            this.chkEpCrte.TabIndex = 85;
            this.chkEpCrte.UseVisualStyleBackColor = true;
            this.chkEpCrte.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkScrmx
            // 
            this.chkScrmx.AutoSize = true;
            this.chkScrmx.Location = new System.Drawing.Point(13, 27);
            this.chkScrmx.Name = "chkScrmx";
            this.chkScrmx.Size = new System.Drawing.Size(15, 14);
            this.chkScrmx.TabIndex = 84;
            this.chkScrmx.UseVisualStyleBackColor = true;
            this.chkScrmx.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomSbreCrbe
            // 
            this.lblNomSbreCrbe.AutoSize = true;
            this.lblNomSbreCrbe.Location = new System.Drawing.Point(34, 152);
            this.lblNomSbreCrbe.Name = "lblNomSbreCrbe";
            this.lblNomSbreCrbe.Size = new System.Drawing.Size(71, 13);
            this.lblNomSbreCrbe.TabIndex = 78;
            this.lblNomSbreCrbe.Text = "Sabre courbé";
            // 
            // lblPdsSbreCrbe
            // 
            this.lblPdsSbreCrbe.AutoSize = true;
            this.lblPdsSbreCrbe.Location = new System.Drawing.Point(128, 152);
            this.lblPdsSbreCrbe.Name = "lblPdsSbreCrbe";
            this.lblPdsSbreCrbe.Size = new System.Drawing.Size(40, 13);
            this.lblPdsSbreCrbe.TabIndex = 79;
            this.lblPdsSbreCrbe.Text = "0,45kg";
            // 
            // lblPrteSbreCrbe
            // 
            this.lblPrteSbreCrbe.AutoSize = true;
            this.lblPrteSbreCrbe.Location = new System.Drawing.Point(200, 152);
            this.lblPrteSbreCrbe.Name = "lblPrteSbreCrbe";
            this.lblPrteSbreCrbe.Size = new System.Drawing.Size(36, 13);
            this.lblPrteSbreCrbe.TabIndex = 80;
            this.lblPrteSbreCrbe.Text = "90 cm";
            // 
            // lblTpeSbreCrbe
            // 
            this.lblTpeSbreCrbe.AutoSize = true;
            this.lblTpeSbreCrbe.Location = new System.Drawing.Point(325, 152);
            this.lblTpeSbreCrbe.Name = "lblTpeSbreCrbe";
            this.lblTpeSbreCrbe.Size = new System.Drawing.Size(56, 13);
            this.lblTpeSbreCrbe.TabIndex = 82;
            this.lblTpeSbreCrbe.Text = "Tranchant";
            // 
            // lblDgtsSbreCrbe
            // 
            this.lblDgtsSbreCrbe.AutoSize = true;
            this.lblDgtsSbreCrbe.Location = new System.Drawing.Point(397, 152);
            this.lblDgtsSbreCrbe.Name = "lblDgtsSbreCrbe";
            this.lblDgtsSbreCrbe.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsSbreCrbe.TabIndex = 83;
            this.lblDgtsSbreCrbe.Text = "1d8+1";
            // 
            // lblNomLte
            // 
            this.lblNomLte.AutoSize = true;
            this.lblNomLte.Location = new System.Drawing.Point(34, 127);
            this.lblNomLte.Name = "lblNomLte";
            this.lblNomLte.Size = new System.Drawing.Size(31, 13);
            this.lblNomLte.TabIndex = 72;
            this.lblNomLte.Text = "Latte";
            // 
            // lblPdsLte
            // 
            this.lblPdsLte.AutoSize = true;
            this.lblPdsLte.Location = new System.Drawing.Point(128, 127);
            this.lblPdsLte.Name = "lblPdsLte";
            this.lblPdsLte.Size = new System.Drawing.Size(34, 13);
            this.lblPdsLte.TabIndex = 73;
            this.lblPdsLte.Text = "0,5kg";
            // 
            // lblPrteLte
            // 
            this.lblPrteLte.AutoSize = true;
            this.lblPrteLte.Location = new System.Drawing.Point(200, 127);
            this.lblPrteLte.Name = "lblPrteLte";
            this.lblPrteLte.Size = new System.Drawing.Size(36, 13);
            this.lblPrteLte.TabIndex = 74;
            this.lblPrteLte.Text = "90 cm";
            // 
            // lblTpeLte
            // 
            this.lblTpeLte.AutoSize = true;
            this.lblTpeLte.Location = new System.Drawing.Point(325, 127);
            this.lblTpeLte.Name = "lblTpeLte";
            this.lblTpeLte.Size = new System.Drawing.Size(56, 13);
            this.lblTpeLte.TabIndex = 76;
            this.lblTpeLte.Text = "Tranchant";
            // 
            // lblDgtsLte
            // 
            this.lblDgtsLte.AutoSize = true;
            this.lblDgtsLte.Location = new System.Drawing.Point(397, 127);
            this.lblDgtsLte.Name = "lblDgtsLte";
            this.lblDgtsLte.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsLte.TabIndex = 77;
            this.lblDgtsLte.Text = "1d8+2";
            // 
            // lblNomGlve
            // 
            this.lblNomGlve.AutoSize = true;
            this.lblNomGlve.Location = new System.Drawing.Point(34, 102);
            this.lblNomGlve.Name = "lblNomGlve";
            this.lblNomGlve.Size = new System.Drawing.Size(37, 13);
            this.lblNomGlve.TabIndex = 66;
            this.lblNomGlve.Text = "Glaive";
            // 
            // lblPdsGlve
            // 
            this.lblPdsGlve.AutoSize = true;
            this.lblPdsGlve.Location = new System.Drawing.Point(128, 102);
            this.lblPdsGlve.Name = "lblPdsGlve";
            this.lblPdsGlve.Size = new System.Drawing.Size(34, 13);
            this.lblPdsGlve.TabIndex = 67;
            this.lblPdsGlve.Text = "0,6kg";
            // 
            // lblPrteGlve
            // 
            this.lblPrteGlve.AutoSize = true;
            this.lblPrteGlve.Location = new System.Drawing.Point(200, 102);
            this.lblPrteGlve.Name = "lblPrteGlve";
            this.lblPrteGlve.Size = new System.Drawing.Size(36, 13);
            this.lblPrteGlve.TabIndex = 68;
            this.lblPrteGlve.Text = "60 cm";
            // 
            // nudGlve
            // 
            this.nudGlve.Location = new System.Drawing.Point(269, 100);
            this.nudGlve.Name = "nudGlve";
            this.nudGlve.Size = new System.Drawing.Size(41, 20);
            this.nudGlve.TabIndex = 69;
            this.nudGlve.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudGlve.ValueChanged += new System.EventHandler(this.nudGlve_ValueChanged);
            // 
            // lblTpeGlve
            // 
            this.lblTpeGlve.AutoSize = true;
            this.lblTpeGlve.Location = new System.Drawing.Point(325, 102);
            this.lblTpeGlve.Name = "lblTpeGlve";
            this.lblTpeGlve.Size = new System.Drawing.Size(56, 13);
            this.lblTpeGlve.TabIndex = 70;
            this.lblTpeGlve.Text = "Tranchant";
            // 
            // lblDgtsGlve
            // 
            this.lblDgtsGlve.AutoSize = true;
            this.lblDgtsGlve.Location = new System.Drawing.Point(397, 102);
            this.lblDgtsGlve.Name = "lblDgtsGlve";
            this.lblDgtsGlve.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsGlve.TabIndex = 71;
            this.lblDgtsGlve.Text = "1d6+3";
            // 
            // lblNomEpLge
            // 
            this.lblNomEpLge.AutoSize = true;
            this.lblNomEpLge.Location = new System.Drawing.Point(34, 77);
            this.lblNomEpLge.Name = "lblNomEpLge";
            this.lblNomEpLge.Size = new System.Drawing.Size(67, 13);
            this.lblNomEpLge.TabIndex = 60;
            this.lblNomEpLge.Text = "Épée longue";
            // 
            // lblPdsEpLge
            // 
            this.lblPdsEpLge.AutoSize = true;
            this.lblPdsEpLge.Location = new System.Drawing.Point(128, 77);
            this.lblPdsEpLge.Name = "lblPdsEpLge";
            this.lblPdsEpLge.Size = new System.Drawing.Size(34, 13);
            this.lblPdsEpLge.TabIndex = 61;
            this.lblPdsEpLge.Text = "1,5kg";
            // 
            // lblPrteEpLge
            // 
            this.lblPrteEpLge.AutoSize = true;
            this.lblPrteEpLge.Location = new System.Drawing.Point(200, 77);
            this.lblPrteEpLge.Name = "lblPrteEpLge";
            this.lblPrteEpLge.Size = new System.Drawing.Size(24, 13);
            this.lblPrteEpLge.TabIndex = 62;
            this.lblPrteEpLge.Text = "1 m";
            // 
            // nudEpLge
            // 
            this.nudEpLge.Location = new System.Drawing.Point(269, 75);
            this.nudEpLge.Name = "nudEpLge";
            this.nudEpLge.Size = new System.Drawing.Size(41, 20);
            this.nudEpLge.TabIndex = 63;
            this.nudEpLge.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudEpLge.ValueChanged += new System.EventHandler(this.nudEpLge_ValueChanged);
            // 
            // lblTpeEpLge
            // 
            this.lblTpeEpLge.AutoSize = true;
            this.lblTpeEpLge.Location = new System.Drawing.Point(325, 77);
            this.lblTpeEpLge.Name = "lblTpeEpLge";
            this.lblTpeEpLge.Size = new System.Drawing.Size(56, 13);
            this.lblTpeEpLge.TabIndex = 64;
            this.lblTpeEpLge.Text = "Tranchant";
            // 
            // lblDgtsEpLge
            // 
            this.lblDgtsEpLge.AutoSize = true;
            this.lblDgtsEpLge.Location = new System.Drawing.Point(397, 77);
            this.lblDgtsEpLge.Name = "lblDgtsEpLge";
            this.lblDgtsEpLge.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsEpLge.TabIndex = 65;
            this.lblDgtsEpLge.Text = "2d8+4";
            // 
            // lblNomEpCrte
            // 
            this.lblNomEpCrte.AutoSize = true;
            this.lblNomEpCrte.Location = new System.Drawing.Point(34, 52);
            this.lblNomEpCrte.Name = "lblNomEpCrte";
            this.lblNomEpCrte.Size = new System.Drawing.Size(65, 13);
            this.lblNomEpCrte.TabIndex = 54;
            this.lblNomEpCrte.Text = "Épée courte";
            // 
            // lblPdsEpCrte
            // 
            this.lblPdsEpCrte.AutoSize = true;
            this.lblPdsEpCrte.Location = new System.Drawing.Point(128, 52);
            this.lblPdsEpCrte.Name = "lblPdsEpCrte";
            this.lblPdsEpCrte.Size = new System.Drawing.Size(40, 13);
            this.lblPdsEpCrte.TabIndex = 55;
            this.lblPdsEpCrte.Text = "0,35kg";
            // 
            // lblPrteEpCrte
            // 
            this.lblPrteEpCrte.AutoSize = true;
            this.lblPrteEpCrte.Location = new System.Drawing.Point(200, 52);
            this.lblPrteEpCrte.Name = "lblPrteEpCrte";
            this.lblPrteEpCrte.Size = new System.Drawing.Size(36, 13);
            this.lblPrteEpCrte.TabIndex = 56;
            this.lblPrteEpCrte.Text = "65 cm";
            // 
            // nudEpCrte
            // 
            this.nudEpCrte.Location = new System.Drawing.Point(269, 50);
            this.nudEpCrte.Name = "nudEpCrte";
            this.nudEpCrte.Size = new System.Drawing.Size(41, 20);
            this.nudEpCrte.TabIndex = 57;
            this.nudEpCrte.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudEpCrte.ValueChanged += new System.EventHandler(this.nudEpCrte_ValueChanged);
            // 
            // lblTpeEpCrte
            // 
            this.lblTpeEpCrte.AutoSize = true;
            this.lblTpeEpCrte.Location = new System.Drawing.Point(325, 52);
            this.lblTpeEpCrte.Name = "lblTpeEpCrte";
            this.lblTpeEpCrte.Size = new System.Drawing.Size(56, 13);
            this.lblTpeEpCrte.TabIndex = 58;
            this.lblTpeEpCrte.Text = "Tranchant";
            // 
            // lblDgtsEpCrte
            // 
            this.lblDgtsEpCrte.AutoSize = true;
            this.lblDgtsEpCrte.Location = new System.Drawing.Point(397, 52);
            this.lblDgtsEpCrte.Name = "lblDgtsEpCrte";
            this.lblDgtsEpCrte.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsEpCrte.TabIndex = 59;
            this.lblDgtsEpCrte.Text = "1d6+1";
            // 
            // lblNomScrmx
            // 
            this.lblNomScrmx.AutoSize = true;
            this.lblNomScrmx.Location = new System.Drawing.Point(34, 27);
            this.lblNomScrmx.Name = "lblNomScrmx";
            this.lblNomScrmx.Size = new System.Drawing.Size(59, 13);
            this.lblNomScrmx.TabIndex = 48;
            this.lblNomScrmx.Text = "Scramasax";
            // 
            // lblPdsScrmx
            // 
            this.lblPdsScrmx.AutoSize = true;
            this.lblPdsScrmx.Location = new System.Drawing.Point(128, 27);
            this.lblPdsScrmx.Name = "lblPdsScrmx";
            this.lblPdsScrmx.Size = new System.Drawing.Size(40, 13);
            this.lblPdsScrmx.TabIndex = 49;
            this.lblPdsScrmx.Text = "0,55kg";
            // 
            // lblPrteScrmx
            // 
            this.lblPrteScrmx.AutoSize = true;
            this.lblPrteScrmx.Location = new System.Drawing.Point(200, 27);
            this.lblPrteScrmx.Name = "lblPrteScrmx";
            this.lblPrteScrmx.Size = new System.Drawing.Size(36, 13);
            this.lblPrteScrmx.TabIndex = 50;
            this.lblPrteScrmx.Text = "40 cm";
            // 
            // nudScrmx
            // 
            this.nudScrmx.Location = new System.Drawing.Point(269, 25);
            this.nudScrmx.Name = "nudScrmx";
            this.nudScrmx.Size = new System.Drawing.Size(41, 20);
            this.nudScrmx.TabIndex = 51;
            this.nudScrmx.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudScrmx.ValueChanged += new System.EventHandler(this.nudScrmx_ValueChanged);
            // 
            // lblTpeScrmx
            // 
            this.lblTpeScrmx.AutoSize = true;
            this.lblTpeScrmx.Location = new System.Drawing.Point(325, 27);
            this.lblTpeScrmx.Name = "lblTpeScrmx";
            this.lblTpeScrmx.Size = new System.Drawing.Size(56, 13);
            this.lblTpeScrmx.TabIndex = 52;
            this.lblTpeScrmx.Text = "Tranchant";
            // 
            // lblDgtsScrmx
            // 
            this.lblDgtsScrmx.AutoSize = true;
            this.lblDgtsScrmx.Location = new System.Drawing.Point(397, 27);
            this.lblDgtsScrmx.Name = "lblDgtsScrmx";
            this.lblDgtsScrmx.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsScrmx.TabIndex = 53;
            this.lblDgtsScrmx.Text = "1d6+2";
            // 
            // tpLances
            // 
            this.tpLances.AutoScroll = true;
            this.tpLances.Controls.Add(this.lblPprieteTrdnt);
            this.tpLances.Controls.Add(this.lblPprieteSrse);
            this.tpLances.Controls.Add(this.lblPprieteFrche);
            this.tpLances.Controls.Add(this.lblPprieteJvlot);
            this.tpLances.Controls.Add(this.lblPprieteCntus);
            this.tpLances.Controls.Add(this.lblPprieteLances);
            this.tpLances.Controls.Add(this.lblDescLances);
            this.tpLances.Controls.Add(this.lblVleurTrdnt);
            this.tpLances.Controls.Add(this.lblVleurSrse);
            this.tpLances.Controls.Add(this.lblVleurFrche);
            this.tpLances.Controls.Add(this.lblVleurJvlot);
            this.tpLances.Controls.Add(this.lblVleurCntus);
            this.tpLances.Controls.Add(this.lblVleurLance);
            this.tpLances.Controls.Add(this.chkTrdnt);
            this.tpLances.Controls.Add(this.lblNomTrdnt);
            this.tpLances.Controls.Add(this.lblPdsTrdnt);
            this.tpLances.Controls.Add(this.lblPrteTrdnt);
            this.tpLances.Controls.Add(this.nudTrdnt);
            this.tpLances.Controls.Add(this.lblTpeTrdnt);
            this.tpLances.Controls.Add(this.lblDgtsTrdnt);
            this.tpLances.Controls.Add(this.chkSrse);
            this.tpLances.Controls.Add(this.chkFrche);
            this.tpLances.Controls.Add(this.chkJvlot);
            this.tpLances.Controls.Add(this.chkCntus);
            this.tpLances.Controls.Add(this.lblNomSrse);
            this.tpLances.Controls.Add(this.lblPdsSrse);
            this.tpLances.Controls.Add(this.lblPrteSrse);
            this.tpLances.Controls.Add(this.nudSrse);
            this.tpLances.Controls.Add(this.lblTpeSrse);
            this.tpLances.Controls.Add(this.lblDgtsSrse);
            this.tpLances.Controls.Add(this.lblNomFrche);
            this.tpLances.Controls.Add(this.lblPdsFrche);
            this.tpLances.Controls.Add(this.lblPrteFrche);
            this.tpLances.Controls.Add(this.nudFrche);
            this.tpLances.Controls.Add(this.lblTpeFrche);
            this.tpLances.Controls.Add(this.lblDgtsFrche);
            this.tpLances.Controls.Add(this.lblNomJvlot);
            this.tpLances.Controls.Add(this.lblPdsJvlot);
            this.tpLances.Controls.Add(this.lblPrteJvlot);
            this.tpLances.Controls.Add(this.nudJvlot);
            this.tpLances.Controls.Add(this.lblTpeJvlot);
            this.tpLances.Controls.Add(this.lblDgtsJvlot);
            this.tpLances.Controls.Add(this.lblNomCntus);
            this.tpLances.Controls.Add(this.lblPdsCntus);
            this.tpLances.Controls.Add(this.lblPrteCntus);
            this.tpLances.Controls.Add(this.nudCntus);
            this.tpLances.Controls.Add(this.lblTpeCntus);
            this.tpLances.Controls.Add(this.lblDgtsCntus);
            this.tpLances.Controls.Add(this.lblNomLances);
            this.tpLances.Controls.Add(this.lblPrtLances);
            this.tpLances.Controls.Add(this.lblPdsLances);
            this.tpLances.Controls.Add(this.lblNbLances);
            this.tpLances.Controls.Add(this.lblTpeLances);
            this.tpLances.Controls.Add(this.lblDgtsLances);
            this.tpLances.Location = new System.Drawing.Point(4, 22);
            this.tpLances.Name = "tpLances";
            this.tpLances.Padding = new System.Windows.Forms.Padding(3);
            this.tpLances.Size = new System.Drawing.Size(689, 272);
            this.tpLances.TabIndex = 1;
            this.tpLances.Text = "Lances";
            this.tpLances.UseVisualStyleBackColor = true;
            // 
            // lblPprieteTrdnt
            // 
            this.lblPprieteTrdnt.AutoSize = true;
            this.lblPprieteTrdnt.Location = new System.Drawing.Point(552, 127);
            this.lblPprieteTrdnt.Name = "lblPprieteTrdnt";
            this.lblPprieteTrdnt.Size = new System.Drawing.Size(44, 13);
            this.lblPprieteTrdnt.TabIndex = 122;
            this.lblPprieteTrdnt.Text = "Aucune";
            // 
            // lblPprieteSrse
            // 
            this.lblPprieteSrse.AutoSize = true;
            this.lblPprieteSrse.Location = new System.Drawing.Point(552, 102);
            this.lblPprieteSrse.Name = "lblPprieteSrse";
            this.lblPprieteSrse.Size = new System.Drawing.Size(44, 13);
            this.lblPprieteSrse.TabIndex = 121;
            this.lblPprieteSrse.Text = "Aucune";
            // 
            // lblPprieteFrche
            // 
            this.lblPprieteFrche.AutoSize = true;
            this.lblPprieteFrche.Location = new System.Drawing.Point(552, 77);
            this.lblPprieteFrche.Name = "lblPprieteFrche";
            this.lblPprieteFrche.Size = new System.Drawing.Size(44, 13);
            this.lblPprieteFrche.TabIndex = 120;
            this.lblPprieteFrche.Text = "Aucune";
            // 
            // lblPprieteJvlot
            // 
            this.lblPprieteJvlot.AutoSize = true;
            this.lblPprieteJvlot.Location = new System.Drawing.Point(552, 52);
            this.lblPprieteJvlot.Name = "lblPprieteJvlot";
            this.lblPprieteJvlot.Size = new System.Drawing.Size(25, 13);
            this.lblPprieteJvlot.TabIndex = 119;
            this.lblPprieteJvlot.Text = "AdJ";
            // 
            // lblPprieteCntus
            // 
            this.lblPprieteCntus.AutoSize = true;
            this.lblPprieteCntus.Location = new System.Drawing.Point(552, 27);
            this.lblPprieteCntus.Name = "lblPprieteCntus";
            this.lblPprieteCntus.Size = new System.Drawing.Size(123, 13);
            this.lblPprieteCntus.TabIndex = 118;
            this.lblPprieteCntus.Text = "AdCvrie, -3 déplacement";
            // 
            // lblPprieteLances
            // 
            this.lblPprieteLances.AutoSize = true;
            this.lblPprieteLances.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPprieteLances.Location = new System.Drawing.Point(552, 3);
            this.lblPprieteLances.Name = "lblPprieteLances";
            this.lblPprieteLances.Size = new System.Drawing.Size(49, 13);
            this.lblPprieteLances.TabIndex = 117;
            this.lblPprieteLances.Text = "Propriété";
            // 
            // lblDescLances
            // 
            this.lblDescLances.AutoSize = true;
            this.lblDescLances.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescLances.Location = new System.Drawing.Point(10, 170);
            this.lblDescLances.Name = "lblDescLances";
            this.lblDescLances.Size = new System.Drawing.Size(224, 13);
            this.lblDescLances.TabIndex = 116;
            this.lblDescLances.Text = "AdCvrie : Arme de cavalerie; AdJ : Arme de jet";
            // 
            // lblVleurTrdnt
            // 
            this.lblVleurTrdnt.AutoSize = true;
            this.lblVleurTrdnt.Location = new System.Drawing.Point(454, 127);
            this.lblVleurTrdnt.Name = "lblVleurTrdnt";
            this.lblVleurTrdnt.Size = new System.Drawing.Size(82, 13);
            this.lblVleurTrdnt.TabIndex = 115;
            this.lblVleurTrdnt.Text = "4 po, 4 pa, 8 pc";
            // 
            // lblVleurSrse
            // 
            this.lblVleurSrse.AutoSize = true;
            this.lblVleurSrse.Location = new System.Drawing.Point(454, 102);
            this.lblVleurSrse.Name = "lblVleurSrse";
            this.lblVleurSrse.Size = new System.Drawing.Size(55, 13);
            this.lblVleurSrse.TabIndex = 114;
            this.lblVleurSrse.Text = "4 po, 4 pa";
            // 
            // lblVleurFrche
            // 
            this.lblVleurFrche.AutoSize = true;
            this.lblVleurFrche.Location = new System.Drawing.Point(454, 77);
            this.lblVleurFrche.Name = "lblVleurFrche";
            this.lblVleurFrche.Size = new System.Drawing.Size(55, 13);
            this.lblVleurFrche.TabIndex = 113;
            this.lblVleurFrche.Text = "1 po, 5 pc";
            // 
            // lblVleurJvlot
            // 
            this.lblVleurJvlot.AutoSize = true;
            this.lblVleurJvlot.Location = new System.Drawing.Point(454, 52);
            this.lblVleurJvlot.Name = "lblVleurJvlot";
            this.lblVleurJvlot.Size = new System.Drawing.Size(82, 13);
            this.lblVleurJvlot.TabIndex = 112;
            this.lblVleurJvlot.Text = "4 po, 7 pa, 2 pc";
            // 
            // lblVleurCntus
            // 
            this.lblVleurCntus.AutoSize = true;
            this.lblVleurCntus.Location = new System.Drawing.Point(454, 27);
            this.lblVleurCntus.Name = "lblVleurCntus";
            this.lblVleurCntus.Size = new System.Drawing.Size(88, 13);
            this.lblVleurCntus.TabIndex = 111;
            this.lblVleurCntus.Text = "11 po, 6 pa, 6 pc";
            // 
            // lblVleurLance
            // 
            this.lblVleurLance.AutoSize = true;
            this.lblVleurLance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurLance.Location = new System.Drawing.Point(454, 3);
            this.lblVleurLance.Name = "lblVleurLance";
            this.lblVleurLance.Size = new System.Drawing.Size(37, 13);
            this.lblVleurLance.TabIndex = 110;
            this.lblVleurLance.Text = "Valeur";
            // 
            // chkTrdnt
            // 
            this.chkTrdnt.AutoSize = true;
            this.chkTrdnt.Location = new System.Drawing.Point(13, 127);
            this.chkTrdnt.Name = "chkTrdnt";
            this.chkTrdnt.Size = new System.Drawing.Size(15, 14);
            this.chkTrdnt.TabIndex = 109;
            this.chkTrdnt.UseVisualStyleBackColor = true;
            this.chkTrdnt.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomTrdnt
            // 
            this.lblNomTrdnt.AutoSize = true;
            this.lblNomTrdnt.Location = new System.Drawing.Point(34, 127);
            this.lblNomTrdnt.Name = "lblNomTrdnt";
            this.lblNomTrdnt.Size = new System.Drawing.Size(40, 13);
            this.lblNomTrdnt.TabIndex = 103;
            this.lblNomTrdnt.Text = "Trident";
            // 
            // lblPdsTrdnt
            // 
            this.lblPdsTrdnt.AutoSize = true;
            this.lblPdsTrdnt.Location = new System.Drawing.Point(128, 127);
            this.lblPdsTrdnt.Name = "lblPdsTrdnt";
            this.lblPdsTrdnt.Size = new System.Drawing.Size(34, 13);
            this.lblPdsTrdnt.TabIndex = 104;
            this.lblPdsTrdnt.Text = "5,0kg";
            // 
            // lblPrteTrdnt
            // 
            this.lblPrteTrdnt.AutoSize = true;
            this.lblPrteTrdnt.Location = new System.Drawing.Point(200, 127);
            this.lblPrteTrdnt.Name = "lblPrteTrdnt";
            this.lblPrteTrdnt.Size = new System.Drawing.Size(24, 13);
            this.lblPrteTrdnt.TabIndex = 105;
            this.lblPrteTrdnt.Text = "4 m";
            // 
            // nudTrdnt
            // 
            this.nudTrdnt.Location = new System.Drawing.Point(266, 125);
            this.nudTrdnt.Name = "nudTrdnt";
            this.nudTrdnt.Size = new System.Drawing.Size(41, 20);
            this.nudTrdnt.TabIndex = 106;
            this.nudTrdnt.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudTrdnt.ValueChanged += new System.EventHandler(this.nudTrdnt_ValueChanged);
            // 
            // lblTpeTrdnt
            // 
            this.lblTpeTrdnt.AutoSize = true;
            this.lblTpeTrdnt.Location = new System.Drawing.Point(325, 127);
            this.lblTpeTrdnt.Name = "lblTpeTrdnt";
            this.lblTpeTrdnt.Size = new System.Drawing.Size(50, 13);
            this.lblTpeTrdnt.TabIndex = 107;
            this.lblTpeTrdnt.Text = "Perforant";
            // 
            // lblDgtsTrdnt
            // 
            this.lblDgtsTrdnt.AutoSize = true;
            this.lblDgtsTrdnt.Location = new System.Drawing.Point(397, 127);
            this.lblDgtsTrdnt.Name = "lblDgtsTrdnt";
            this.lblDgtsTrdnt.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsTrdnt.TabIndex = 108;
            this.lblDgtsTrdnt.Text = "1d8+4";
            // 
            // chkSrse
            // 
            this.chkSrse.AutoSize = true;
            this.chkSrse.Location = new System.Drawing.Point(13, 102);
            this.chkSrse.Name = "chkSrse";
            this.chkSrse.Size = new System.Drawing.Size(15, 14);
            this.chkSrse.TabIndex = 102;
            this.chkSrse.UseVisualStyleBackColor = true;
            this.chkSrse.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkFrche
            // 
            this.chkFrche.AutoSize = true;
            this.chkFrche.Location = new System.Drawing.Point(13, 77);
            this.chkFrche.Name = "chkFrche";
            this.chkFrche.Size = new System.Drawing.Size(15, 14);
            this.chkFrche.TabIndex = 101;
            this.chkFrche.UseVisualStyleBackColor = true;
            this.chkFrche.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkJvlot
            // 
            this.chkJvlot.AutoSize = true;
            this.chkJvlot.Location = new System.Drawing.Point(13, 52);
            this.chkJvlot.Name = "chkJvlot";
            this.chkJvlot.Size = new System.Drawing.Size(15, 14);
            this.chkJvlot.TabIndex = 99;
            this.chkJvlot.UseVisualStyleBackColor = true;
            this.chkJvlot.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkCntus
            // 
            this.chkCntus.AutoSize = true;
            this.chkCntus.Location = new System.Drawing.Point(13, 27);
            this.chkCntus.Name = "chkCntus";
            this.chkCntus.Size = new System.Drawing.Size(15, 14);
            this.chkCntus.TabIndex = 97;
            this.chkCntus.UseVisualStyleBackColor = true;
            this.chkCntus.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomSrse
            // 
            this.lblNomSrse.AutoSize = true;
            this.lblNomSrse.Location = new System.Drawing.Point(34, 102);
            this.lblNomSrse.Name = "lblNomSrse";
            this.lblNomSrse.Size = new System.Drawing.Size(41, 13);
            this.lblNomSrse.TabIndex = 90;
            this.lblNomSrse.Text = "Sarisse";
            // 
            // lblPdsSrse
            // 
            this.lblPdsSrse.AutoSize = true;
            this.lblPdsSrse.Location = new System.Drawing.Point(128, 102);
            this.lblPdsSrse.Name = "lblPdsSrse";
            this.lblPdsSrse.Size = new System.Drawing.Size(34, 13);
            this.lblPdsSrse.TabIndex = 91;
            this.lblPdsSrse.Text = "4,0kg";
            // 
            // lblPrteSrse
            // 
            this.lblPrteSrse.AutoSize = true;
            this.lblPrteSrse.Location = new System.Drawing.Point(200, 102);
            this.lblPrteSrse.Name = "lblPrteSrse";
            this.lblPrteSrse.Size = new System.Drawing.Size(24, 13);
            this.lblPrteSrse.TabIndex = 92;
            this.lblPrteSrse.Text = "5 m";
            // 
            // nudSrse
            // 
            this.nudSrse.Location = new System.Drawing.Point(266, 100);
            this.nudSrse.Name = "nudSrse";
            this.nudSrse.Size = new System.Drawing.Size(41, 20);
            this.nudSrse.TabIndex = 93;
            this.nudSrse.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSrse.ValueChanged += new System.EventHandler(this.nudSrse_ValueChanged);
            // 
            // lblTpeSrse
            // 
            this.lblTpeSrse.AutoSize = true;
            this.lblTpeSrse.Location = new System.Drawing.Point(325, 102);
            this.lblTpeSrse.Name = "lblTpeSrse";
            this.lblTpeSrse.Size = new System.Drawing.Size(50, 13);
            this.lblTpeSrse.TabIndex = 94;
            this.lblTpeSrse.Text = "Perforant";
            // 
            // lblDgtsSrse
            // 
            this.lblDgtsSrse.AutoSize = true;
            this.lblDgtsSrse.Location = new System.Drawing.Point(397, 102);
            this.lblDgtsSrse.Name = "lblDgtsSrse";
            this.lblDgtsSrse.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsSrse.TabIndex = 95;
            this.lblDgtsSrse.Text = "1d8+2";
            // 
            // lblNomFrche
            // 
            this.lblNomFrche.AutoSize = true;
            this.lblNomFrche.Location = new System.Drawing.Point(34, 77);
            this.lblNomFrche.Name = "lblNomFrche";
            this.lblNomFrche.Size = new System.Drawing.Size(46, 13);
            this.lblNomFrche.TabIndex = 84;
            this.lblNomFrche.Text = "Fourche";
            // 
            // lblPdsFrche
            // 
            this.lblPdsFrche.AutoSize = true;
            this.lblPdsFrche.Location = new System.Drawing.Point(128, 77);
            this.lblPdsFrche.Name = "lblPdsFrche";
            this.lblPdsFrche.Size = new System.Drawing.Size(34, 13);
            this.lblPdsFrche.TabIndex = 85;
            this.lblPdsFrche.Text = "0,8kg";
            // 
            // lblPrteFrche
            // 
            this.lblPrteFrche.AutoSize = true;
            this.lblPrteFrche.Location = new System.Drawing.Point(200, 77);
            this.lblPrteFrche.Name = "lblPrteFrche";
            this.lblPrteFrche.Size = new System.Drawing.Size(24, 13);
            this.lblPrteFrche.TabIndex = 86;
            this.lblPrteFrche.Text = "2 m";
            // 
            // nudFrche
            // 
            this.nudFrche.Location = new System.Drawing.Point(266, 75);
            this.nudFrche.Name = "nudFrche";
            this.nudFrche.Size = new System.Drawing.Size(41, 20);
            this.nudFrche.TabIndex = 87;
            this.nudFrche.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFrche.ValueChanged += new System.EventHandler(this.nudFrche_ValueChanged);
            // 
            // lblTpeFrche
            // 
            this.lblTpeFrche.AutoSize = true;
            this.lblTpeFrche.Location = new System.Drawing.Point(325, 77);
            this.lblTpeFrche.Name = "lblTpeFrche";
            this.lblTpeFrche.Size = new System.Drawing.Size(50, 13);
            this.lblTpeFrche.TabIndex = 88;
            this.lblTpeFrche.Text = "Perforant";
            // 
            // lblDgtsFrche
            // 
            this.lblDgtsFrche.AutoSize = true;
            this.lblDgtsFrche.Location = new System.Drawing.Point(397, 77);
            this.lblDgtsFrche.Name = "lblDgtsFrche";
            this.lblDgtsFrche.Size = new System.Drawing.Size(25, 13);
            this.lblDgtsFrche.TabIndex = 89;
            this.lblDgtsFrche.Text = "1d4";
            // 
            // lblNomJvlot
            // 
            this.lblNomJvlot.AutoSize = true;
            this.lblNomJvlot.Location = new System.Drawing.Point(34, 52);
            this.lblNomJvlot.Name = "lblNomJvlot";
            this.lblNomJvlot.Size = new System.Drawing.Size(41, 13);
            this.lblNomJvlot.TabIndex = 72;
            this.lblNomJvlot.Text = "Javelot";
            // 
            // lblPdsJvlot
            // 
            this.lblPdsJvlot.AutoSize = true;
            this.lblPdsJvlot.Location = new System.Drawing.Point(128, 52);
            this.lblPdsJvlot.Name = "lblPdsJvlot";
            this.lblPdsJvlot.Size = new System.Drawing.Size(34, 13);
            this.lblPdsJvlot.TabIndex = 73;
            this.lblPdsJvlot.Text = "1,0kg";
            // 
            // lblPrteJvlot
            // 
            this.lblPrteJvlot.AutoSize = true;
            this.lblPrteJvlot.Location = new System.Drawing.Point(200, 52);
            this.lblPrteJvlot.Name = "lblPrteJvlot";
            this.lblPrteJvlot.Size = new System.Drawing.Size(24, 13);
            this.lblPrteJvlot.TabIndex = 74;
            this.lblPrteJvlot.Text = "9 m";
            // 
            // nudJvlot
            // 
            this.nudJvlot.Location = new System.Drawing.Point(266, 50);
            this.nudJvlot.Name = "nudJvlot";
            this.nudJvlot.Size = new System.Drawing.Size(41, 20);
            this.nudJvlot.TabIndex = 75;
            this.nudJvlot.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudJvlot.ValueChanged += new System.EventHandler(this.nudJvlot_ValueChanged);
            // 
            // lblTpeJvlot
            // 
            this.lblTpeJvlot.AutoSize = true;
            this.lblTpeJvlot.Location = new System.Drawing.Point(325, 52);
            this.lblTpeJvlot.Name = "lblTpeJvlot";
            this.lblTpeJvlot.Size = new System.Drawing.Size(50, 13);
            this.lblTpeJvlot.TabIndex = 76;
            this.lblTpeJvlot.Text = "Perforant";
            // 
            // lblDgtsJvlot
            // 
            this.lblDgtsJvlot.AutoSize = true;
            this.lblDgtsJvlot.Location = new System.Drawing.Point(397, 52);
            this.lblDgtsJvlot.Name = "lblDgtsJvlot";
            this.lblDgtsJvlot.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsJvlot.TabIndex = 77;
            this.lblDgtsJvlot.Text = "1d6+2";
            // 
            // lblNomCntus
            // 
            this.lblNomCntus.AutoSize = true;
            this.lblNomCntus.Location = new System.Drawing.Point(34, 27);
            this.lblNomCntus.Name = "lblNomCntus";
            this.lblNomCntus.Size = new System.Drawing.Size(40, 13);
            this.lblNomCntus.TabIndex = 60;
            this.lblNomCntus.Text = "Contus";
            // 
            // lblPdsCntus
            // 
            this.lblPdsCntus.AutoSize = true;
            this.lblPdsCntus.Location = new System.Drawing.Point(128, 27);
            this.lblPdsCntus.Name = "lblPdsCntus";
            this.lblPdsCntus.Size = new System.Drawing.Size(40, 13);
            this.lblPdsCntus.TabIndex = 61;
            this.lblPdsCntus.Text = "10,0kg";
            // 
            // lblPrteCntus
            // 
            this.lblPrteCntus.AutoSize = true;
            this.lblPrteCntus.Location = new System.Drawing.Point(200, 27);
            this.lblPrteCntus.Name = "lblPrteCntus";
            this.lblPrteCntus.Size = new System.Drawing.Size(24, 13);
            this.lblPrteCntus.TabIndex = 62;
            this.lblPrteCntus.Text = "4 m";
            // 
            // nudCntus
            // 
            this.nudCntus.Location = new System.Drawing.Point(266, 25);
            this.nudCntus.Name = "nudCntus";
            this.nudCntus.Size = new System.Drawing.Size(41, 20);
            this.nudCntus.TabIndex = 63;
            this.nudCntus.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCntus.ValueChanged += new System.EventHandler(this.nudCntus_ValueChanged);
            // 
            // lblTpeCntus
            // 
            this.lblTpeCntus.AutoSize = true;
            this.lblTpeCntus.Location = new System.Drawing.Point(325, 27);
            this.lblTpeCntus.Name = "lblTpeCntus";
            this.lblTpeCntus.Size = new System.Drawing.Size(50, 13);
            this.lblTpeCntus.TabIndex = 64;
            this.lblTpeCntus.Text = "Perforant";
            // 
            // lblDgtsCntus
            // 
            this.lblDgtsCntus.AutoSize = true;
            this.lblDgtsCntus.Location = new System.Drawing.Point(397, 27);
            this.lblDgtsCntus.Name = "lblDgtsCntus";
            this.lblDgtsCntus.Size = new System.Drawing.Size(43, 13);
            this.lblDgtsCntus.TabIndex = 65;
            this.lblDgtsCntus.Text = "2d10+5";
            // 
            // lblNomLances
            // 
            this.lblNomLances.AutoSize = true;
            this.lblNomLances.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomLances.Location = new System.Drawing.Point(34, 3);
            this.lblNomLances.Name = "lblNomLances";
            this.lblNomLances.Size = new System.Drawing.Size(29, 13);
            this.lblNomLances.TabIndex = 6;
            this.lblNomLances.Text = "Nom";
            // 
            // lblPrtLances
            // 
            this.lblPrtLances.AutoSize = true;
            this.lblPrtLances.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrtLances.Location = new System.Drawing.Point(200, 3);
            this.lblPrtLances.Name = "lblPrtLances";
            this.lblPrtLances.Size = new System.Drawing.Size(38, 13);
            this.lblPrtLances.TabIndex = 7;
            this.lblPrtLances.Text = "Portée";
            // 
            // lblPdsLances
            // 
            this.lblPdsLances.AutoSize = true;
            this.lblPdsLances.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsLances.Location = new System.Drawing.Point(128, 3);
            this.lblPdsLances.Name = "lblPdsLances";
            this.lblPdsLances.Size = new System.Drawing.Size(33, 13);
            this.lblPdsLances.TabIndex = 8;
            this.lblPdsLances.Text = "Poids";
            // 
            // lblNbLances
            // 
            this.lblNbLances.AutoSize = true;
            this.lblNbLances.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbLances.Location = new System.Drawing.Point(266, 3);
            this.lblNbLances.Name = "lblNbLances";
            this.lblNbLances.Size = new System.Drawing.Size(44, 13);
            this.lblNbLances.TabIndex = 9;
            this.lblNbLances.Text = "Nombre";
            // 
            // lblTpeLances
            // 
            this.lblTpeLances.AutoSize = true;
            this.lblTpeLances.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTpeLances.Location = new System.Drawing.Point(325, 3);
            this.lblTpeLances.Name = "lblTpeLances";
            this.lblTpeLances.Size = new System.Drawing.Size(31, 13);
            this.lblTpeLances.TabIndex = 10;
            this.lblTpeLances.Text = "Type";
            // 
            // lblDgtsLances
            // 
            this.lblDgtsLances.AutoSize = true;
            this.lblDgtsLances.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDgtsLances.Location = new System.Drawing.Point(397, 3);
            this.lblDgtsLances.Name = "lblDgtsLances";
            this.lblDgtsLances.Size = new System.Drawing.Size(41, 13);
            this.lblDgtsLances.TabIndex = 11;
            this.lblDgtsLances.Text = "Dégâts";
            // 
            // tpPoignards
            // 
            this.tpPoignards.AutoScroll = true;
            this.tpPoignards.Controls.Add(this.lblDescPoignards);
            this.tpPoignards.Controls.Add(this.lblPrpieteDgeAssin);
            this.tpPoignards.Controls.Add(this.lblPrpieteFclGure);
            this.tpPoignards.Controls.Add(this.lblPrpieteDge);
            this.tpPoignards.Controls.Add(this.lblPrpieteCtau);
            this.tpPoignards.Controls.Add(this.lblPprieteDagues);
            this.tpPoignards.Controls.Add(this.lblVleurDgeAssin);
            this.tpPoignards.Controls.Add(this.chkDgeAssin);
            this.tpPoignards.Controls.Add(this.lblNomDgeAssin);
            this.tpPoignards.Controls.Add(this.lblPdsDgeAssin);
            this.tpPoignards.Controls.Add(this.lblPrteDgeAssin);
            this.tpPoignards.Controls.Add(this.nudDgeAssin);
            this.tpPoignards.Controls.Add(this.lblTpeDgeAssin);
            this.tpPoignards.Controls.Add(this.lblDgtsDgeAssin);
            this.tpPoignards.Controls.Add(this.lblVleurFclGure);
            this.tpPoignards.Controls.Add(this.lblVleurDge);
            this.tpPoignards.Controls.Add(this.lblVleurCtau);
            this.tpPoignards.Controls.Add(this.lblVleurDagues);
            this.tpPoignards.Controls.Add(this.chkFclGure);
            this.tpPoignards.Controls.Add(this.chkDge);
            this.tpPoignards.Controls.Add(this.chkCtau);
            this.tpPoignards.Controls.Add(this.lblNomFclGure);
            this.tpPoignards.Controls.Add(this.lblPdsFclGure);
            this.tpPoignards.Controls.Add(this.lblPrteFclGure);
            this.tpPoignards.Controls.Add(this.nudFclGure);
            this.tpPoignards.Controls.Add(this.lblTpeFclGure);
            this.tpPoignards.Controls.Add(this.lblDgtsFclGure);
            this.tpPoignards.Controls.Add(this.lblNomDge);
            this.tpPoignards.Controls.Add(this.lblPdsDge);
            this.tpPoignards.Controls.Add(this.lblPrteDge);
            this.tpPoignards.Controls.Add(this.nudDge);
            this.tpPoignards.Controls.Add(this.lblTpeDge);
            this.tpPoignards.Controls.Add(this.lblDgtsDge);
            this.tpPoignards.Controls.Add(this.lblNomCtau);
            this.tpPoignards.Controls.Add(this.lblPdsCtau);
            this.tpPoignards.Controls.Add(this.lblPrteCtau);
            this.tpPoignards.Controls.Add(this.nudCtau);
            this.tpPoignards.Controls.Add(this.lblTpeCtau);
            this.tpPoignards.Controls.Add(this.lblDgtsCtau);
            this.tpPoignards.Controls.Add(this.lblNomDagues);
            this.tpPoignards.Controls.Add(this.lblPrteDagues);
            this.tpPoignards.Controls.Add(this.lblPdsDagues);
            this.tpPoignards.Controls.Add(this.lblNbDagues);
            this.tpPoignards.Controls.Add(this.lblTypeDagues);
            this.tpPoignards.Controls.Add(this.lblDgtsDagues);
            this.tpPoignards.Location = new System.Drawing.Point(4, 22);
            this.tpPoignards.Name = "tpPoignards";
            this.tpPoignards.Size = new System.Drawing.Size(689, 272);
            this.tpPoignards.TabIndex = 2;
            this.tpPoignards.Text = "Poignards";
            this.tpPoignards.UseVisualStyleBackColor = true;
            // 
            // lblDescPoignards
            // 
            this.lblDescPoignards.AutoSize = true;
            this.lblDescPoignards.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescPoignards.Location = new System.Drawing.Point(10, 153);
            this.lblDescPoignards.Name = "lblDescPoignards";
            this.lblDescPoignards.Size = new System.Drawing.Size(184, 13);
            this.lblDescPoignards.TabIndex = 133;
            this.lblDescPoignards.Text = "Dissim + : se dissimule plus facilement";
            // 
            // lblPrpieteDgeAssin
            // 
            this.lblPrpieteDgeAssin.AutoSize = true;
            this.lblPrpieteDgeAssin.Location = new System.Drawing.Point(552, 102);
            this.lblPrpieteDgeAssin.Name = "lblPrpieteDgeAssin";
            this.lblPrpieteDgeAssin.Size = new System.Drawing.Size(46, 13);
            this.lblPrpieteDgeAssin.TabIndex = 132;
            this.lblPrpieteDgeAssin.Text = "Dissim +";
            // 
            // lblPrpieteFclGure
            // 
            this.lblPrpieteFclGure.AutoSize = true;
            this.lblPrpieteFclGure.Location = new System.Drawing.Point(552, 77);
            this.lblPrpieteFclGure.Name = "lblPrpieteFclGure";
            this.lblPrpieteFclGure.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteFclGure.TabIndex = 131;
            this.lblPrpieteFclGure.Text = "Aucune";
            // 
            // lblPrpieteDge
            // 
            this.lblPrpieteDge.AutoSize = true;
            this.lblPrpieteDge.Location = new System.Drawing.Point(552, 52);
            this.lblPrpieteDge.Name = "lblPrpieteDge";
            this.lblPrpieteDge.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteDge.TabIndex = 130;
            this.lblPrpieteDge.Text = "Aucune";
            // 
            // lblPrpieteCtau
            // 
            this.lblPrpieteCtau.AutoSize = true;
            this.lblPrpieteCtau.Location = new System.Drawing.Point(552, 27);
            this.lblPrpieteCtau.Name = "lblPrpieteCtau";
            this.lblPrpieteCtau.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCtau.TabIndex = 129;
            this.lblPrpieteCtau.Text = "Aucune";
            // 
            // lblPprieteDagues
            // 
            this.lblPprieteDagues.AutoSize = true;
            this.lblPprieteDagues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPprieteDagues.Location = new System.Drawing.Point(552, 3);
            this.lblPprieteDagues.Name = "lblPprieteDagues";
            this.lblPprieteDagues.Size = new System.Drawing.Size(49, 13);
            this.lblPprieteDagues.TabIndex = 128;
            this.lblPprieteDagues.Text = "Propriété";
            // 
            // lblVleurDgeAssin
            // 
            this.lblVleurDgeAssin.AutoSize = true;
            this.lblVleurDgeAssin.Location = new System.Drawing.Point(454, 102);
            this.lblVleurDgeAssin.Name = "lblVleurDgeAssin";
            this.lblVleurDgeAssin.Size = new System.Drawing.Size(82, 13);
            this.lblVleurDgeAssin.TabIndex = 127;
            this.lblVleurDgeAssin.Text = "1 po, 3 pa, 5 pc";
            // 
            // chkDgeAssin
            // 
            this.chkDgeAssin.AutoSize = true;
            this.chkDgeAssin.Location = new System.Drawing.Point(13, 102);
            this.chkDgeAssin.Name = "chkDgeAssin";
            this.chkDgeAssin.Size = new System.Drawing.Size(15, 14);
            this.chkDgeAssin.TabIndex = 126;
            this.chkDgeAssin.UseVisualStyleBackColor = true;
            this.chkDgeAssin.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomDgeAssin
            // 
            this.lblNomDgeAssin.AutoSize = true;
            this.lblNomDgeAssin.Location = new System.Drawing.Point(34, 102);
            this.lblNomDgeAssin.Name = "lblNomDgeAssin";
            this.lblNomDgeAssin.Size = new System.Drawing.Size(90, 13);
            this.lblNomDgeAssin.TabIndex = 120;
            this.lblNomDgeAssin.Text = "Dague d\'assassin";
            // 
            // lblPdsDgeAssin
            // 
            this.lblPdsDgeAssin.AutoSize = true;
            this.lblPdsDgeAssin.Location = new System.Drawing.Point(128, 102);
            this.lblPdsDgeAssin.Name = "lblPdsDgeAssin";
            this.lblPdsDgeAssin.Size = new System.Drawing.Size(40, 13);
            this.lblPdsDgeAssin.TabIndex = 121;
            this.lblPdsDgeAssin.Text = "0,20kg";
            // 
            // lblPrteDgeAssin
            // 
            this.lblPrteDgeAssin.AutoSize = true;
            this.lblPrteDgeAssin.Location = new System.Drawing.Point(200, 102);
            this.lblPrteDgeAssin.Name = "lblPrteDgeAssin";
            this.lblPrteDgeAssin.Size = new System.Drawing.Size(36, 13);
            this.lblPrteDgeAssin.TabIndex = 122;
            this.lblPrteDgeAssin.Text = "35 cm";
            // 
            // nudDgeAssin
            // 
            this.nudDgeAssin.Location = new System.Drawing.Point(266, 100);
            this.nudDgeAssin.Name = "nudDgeAssin";
            this.nudDgeAssin.Size = new System.Drawing.Size(41, 20);
            this.nudDgeAssin.TabIndex = 123;
            this.nudDgeAssin.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudDgeAssin.ValueChanged += new System.EventHandler(this.nudDgeAssin_ValueChanged);
            // 
            // lblTpeDgeAssin
            // 
            this.lblTpeDgeAssin.AutoSize = true;
            this.lblTpeDgeAssin.Location = new System.Drawing.Point(325, 102);
            this.lblTpeDgeAssin.Name = "lblTpeDgeAssin";
            this.lblTpeDgeAssin.Size = new System.Drawing.Size(50, 13);
            this.lblTpeDgeAssin.TabIndex = 124;
            this.lblTpeDgeAssin.Text = "Perforant";
            // 
            // lblDgtsDgeAssin
            // 
            this.lblDgtsDgeAssin.AutoSize = true;
            this.lblDgtsDgeAssin.Location = new System.Drawing.Point(397, 102);
            this.lblDgtsDgeAssin.Name = "lblDgtsDgeAssin";
            this.lblDgtsDgeAssin.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsDgeAssin.TabIndex = 125;
            this.lblDgtsDgeAssin.Text = "1d6+1";
            // 
            // lblVleurFclGure
            // 
            this.lblVleurFclGure.AutoSize = true;
            this.lblVleurFclGure.Location = new System.Drawing.Point(454, 77);
            this.lblVleurFclGure.Name = "lblVleurFclGure";
            this.lblVleurFclGure.Size = new System.Drawing.Size(82, 13);
            this.lblVleurFclGure.TabIndex = 119;
            this.lblVleurFclGure.Text = "1 po, 2 pa, 5 pc";
            // 
            // lblVleurDge
            // 
            this.lblVleurDge.AutoSize = true;
            this.lblVleurDge.Location = new System.Drawing.Point(454, 52);
            this.lblVleurDge.Name = "lblVleurDge";
            this.lblVleurDge.Size = new System.Drawing.Size(55, 13);
            this.lblVleurDge.TabIndex = 118;
            this.lblVleurDge.Text = "9 pa, 6 pc";
            // 
            // lblVleurCtau
            // 
            this.lblVleurCtau.AutoSize = true;
            this.lblVleurCtau.Location = new System.Drawing.Point(454, 27);
            this.lblVleurCtau.Name = "lblVleurCtau";
            this.lblVleurCtau.Size = new System.Drawing.Size(55, 13);
            this.lblVleurCtau.TabIndex = 117;
            this.lblVleurCtau.Text = "4 pa, 6 pc";
            // 
            // lblVleurDagues
            // 
            this.lblVleurDagues.AutoSize = true;
            this.lblVleurDagues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurDagues.Location = new System.Drawing.Point(454, 3);
            this.lblVleurDagues.Name = "lblVleurDagues";
            this.lblVleurDagues.Size = new System.Drawing.Size(37, 13);
            this.lblVleurDagues.TabIndex = 116;
            this.lblVleurDagues.Text = "Valeur";
            // 
            // chkFclGure
            // 
            this.chkFclGure.AutoSize = true;
            this.chkFclGure.Location = new System.Drawing.Point(13, 77);
            this.chkFclGure.Name = "chkFclGure";
            this.chkFclGure.Size = new System.Drawing.Size(15, 14);
            this.chkFclGure.TabIndex = 99;
            this.chkFclGure.UseVisualStyleBackColor = true;
            this.chkFclGure.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkDge
            // 
            this.chkDge.AutoSize = true;
            this.chkDge.Location = new System.Drawing.Point(13, 52);
            this.chkDge.Name = "chkDge";
            this.chkDge.Size = new System.Drawing.Size(15, 14);
            this.chkDge.TabIndex = 98;
            this.chkDge.UseVisualStyleBackColor = true;
            this.chkDge.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkCtau
            // 
            this.chkCtau.AutoSize = true;
            this.chkCtau.Location = new System.Drawing.Point(13, 27);
            this.chkCtau.Name = "chkCtau";
            this.chkCtau.Size = new System.Drawing.Size(15, 14);
            this.chkCtau.TabIndex = 97;
            this.chkCtau.UseVisualStyleBackColor = true;
            this.chkCtau.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomFclGure
            // 
            this.lblNomFclGure.AutoSize = true;
            this.lblNomFclGure.Location = new System.Drawing.Point(34, 77);
            this.lblNomFclGure.Name = "lblNomFclGure";
            this.lblNomFclGure.Size = new System.Drawing.Size(91, 13);
            this.lblNomFclGure.TabIndex = 30;
            this.lblNomFclGure.Text = "Faucille de guerre";
            // 
            // lblPdsFclGure
            // 
            this.lblPdsFclGure.AutoSize = true;
            this.lblPdsFclGure.Location = new System.Drawing.Point(128, 77);
            this.lblPdsFclGure.Name = "lblPdsFclGure";
            this.lblPdsFclGure.Size = new System.Drawing.Size(40, 13);
            this.lblPdsFclGure.TabIndex = 31;
            this.lblPdsFclGure.Text = "0,30kg";
            // 
            // lblPrteFclGure
            // 
            this.lblPrteFclGure.AutoSize = true;
            this.lblPrteFclGure.Location = new System.Drawing.Point(200, 77);
            this.lblPrteFclGure.Name = "lblPrteFclGure";
            this.lblPrteFclGure.Size = new System.Drawing.Size(36, 13);
            this.lblPrteFclGure.TabIndex = 32;
            this.lblPrteFclGure.Text = "30 cm";
            // 
            // nudFclGure
            // 
            this.nudFclGure.Location = new System.Drawing.Point(266, 75);
            this.nudFclGure.Name = "nudFclGure";
            this.nudFclGure.Size = new System.Drawing.Size(41, 20);
            this.nudFclGure.TabIndex = 33;
            this.nudFclGure.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFclGure.ValueChanged += new System.EventHandler(this.nudFclGure_ValueChanged);
            // 
            // lblTpeFclGure
            // 
            this.lblTpeFclGure.AutoSize = true;
            this.lblTpeFclGure.Location = new System.Drawing.Point(325, 77);
            this.lblTpeFclGure.Name = "lblTpeFclGure";
            this.lblTpeFclGure.Size = new System.Drawing.Size(50, 13);
            this.lblTpeFclGure.TabIndex = 34;
            this.lblTpeFclGure.Text = "Perforant";
            // 
            // lblDgtsFclGure
            // 
            this.lblDgtsFclGure.AutoSize = true;
            this.lblDgtsFclGure.Location = new System.Drawing.Point(397, 77);
            this.lblDgtsFclGure.Name = "lblDgtsFclGure";
            this.lblDgtsFclGure.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsFclGure.TabIndex = 35;
            this.lblDgtsFclGure.Text = "2d4+1";
            // 
            // lblNomDge
            // 
            this.lblNomDge.AutoSize = true;
            this.lblNomDge.Location = new System.Drawing.Point(34, 52);
            this.lblNomDge.Name = "lblNomDge";
            this.lblNomDge.Size = new System.Drawing.Size(39, 13);
            this.lblNomDge.TabIndex = 24;
            this.lblNomDge.Text = "Dague";
            // 
            // lblPdsDge
            // 
            this.lblPdsDge.AutoSize = true;
            this.lblPdsDge.Location = new System.Drawing.Point(128, 52);
            this.lblPdsDge.Name = "lblPdsDge";
            this.lblPdsDge.Size = new System.Drawing.Size(40, 13);
            this.lblPdsDge.TabIndex = 25;
            this.lblPdsDge.Text = "0,15kg";
            // 
            // lblPrteDge
            // 
            this.lblPrteDge.AutoSize = true;
            this.lblPrteDge.Location = new System.Drawing.Point(200, 52);
            this.lblPrteDge.Name = "lblPrteDge";
            this.lblPrteDge.Size = new System.Drawing.Size(36, 13);
            this.lblPrteDge.TabIndex = 26;
            this.lblPrteDge.Text = "29 cm";
            // 
            // nudDge
            // 
            this.nudDge.Location = new System.Drawing.Point(266, 50);
            this.nudDge.Name = "nudDge";
            this.nudDge.Size = new System.Drawing.Size(41, 20);
            this.nudDge.TabIndex = 27;
            this.nudDge.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudDge.ValueChanged += new System.EventHandler(this.nudDge_ValueChanged);
            // 
            // lblTpeDge
            // 
            this.lblTpeDge.AutoSize = true;
            this.lblTpeDge.Location = new System.Drawing.Point(325, 52);
            this.lblTpeDge.Name = "lblTpeDge";
            this.lblTpeDge.Size = new System.Drawing.Size(50, 13);
            this.lblTpeDge.TabIndex = 28;
            this.lblTpeDge.Text = "Perforant";
            // 
            // lblDgtsDge
            // 
            this.lblDgtsDge.AutoSize = true;
            this.lblDgtsDge.Location = new System.Drawing.Point(397, 52);
            this.lblDgtsDge.Name = "lblDgtsDge";
            this.lblDgtsDge.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsDge.TabIndex = 29;
            this.lblDgtsDge.Text = "1d4+2";
            // 
            // lblNomCtau
            // 
            this.lblNomCtau.AutoSize = true;
            this.lblNomCtau.Location = new System.Drawing.Point(34, 27);
            this.lblNomCtau.Name = "lblNomCtau";
            this.lblNomCtau.Size = new System.Drawing.Size(47, 13);
            this.lblNomCtau.TabIndex = 18;
            this.lblNomCtau.Text = "Couteau";
            // 
            // lblPdsCtau
            // 
            this.lblPdsCtau.AutoSize = true;
            this.lblPdsCtau.Location = new System.Drawing.Point(128, 27);
            this.lblPdsCtau.Name = "lblPdsCtau";
            this.lblPdsCtau.Size = new System.Drawing.Size(40, 13);
            this.lblPdsCtau.TabIndex = 19;
            this.lblPdsCtau.Text = "0,21kg";
            // 
            // lblPrteCtau
            // 
            this.lblPrteCtau.AutoSize = true;
            this.lblPrteCtau.Location = new System.Drawing.Point(200, 27);
            this.lblPrteCtau.Name = "lblPrteCtau";
            this.lblPrteCtau.Size = new System.Drawing.Size(36, 13);
            this.lblPrteCtau.TabIndex = 20;
            this.lblPrteCtau.Text = "23 cm";
            // 
            // nudCtau
            // 
            this.nudCtau.Location = new System.Drawing.Point(266, 25);
            this.nudCtau.Name = "nudCtau";
            this.nudCtau.Size = new System.Drawing.Size(41, 20);
            this.nudCtau.TabIndex = 21;
            this.nudCtau.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCtau.ValueChanged += new System.EventHandler(this.nudCtau_ValueChanged);
            // 
            // lblTpeCtau
            // 
            this.lblTpeCtau.AutoSize = true;
            this.lblTpeCtau.Location = new System.Drawing.Point(325, 27);
            this.lblTpeCtau.Name = "lblTpeCtau";
            this.lblTpeCtau.Size = new System.Drawing.Size(50, 13);
            this.lblTpeCtau.TabIndex = 22;
            this.lblTpeCtau.Text = "Perforant";
            // 
            // lblDgtsCtau
            // 
            this.lblDgtsCtau.AutoSize = true;
            this.lblDgtsCtau.Location = new System.Drawing.Point(397, 27);
            this.lblDgtsCtau.Name = "lblDgtsCtau";
            this.lblDgtsCtau.Size = new System.Drawing.Size(25, 13);
            this.lblDgtsCtau.TabIndex = 23;
            this.lblDgtsCtau.Text = "1d4";
            // 
            // lblNomDagues
            // 
            this.lblNomDagues.AutoSize = true;
            this.lblNomDagues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomDagues.Location = new System.Drawing.Point(34, 3);
            this.lblNomDagues.Name = "lblNomDagues";
            this.lblNomDagues.Size = new System.Drawing.Size(29, 13);
            this.lblNomDagues.TabIndex = 12;
            this.lblNomDagues.Text = "Nom";
            // 
            // lblPrteDagues
            // 
            this.lblPrteDagues.AutoSize = true;
            this.lblPrteDagues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrteDagues.Location = new System.Drawing.Point(200, 3);
            this.lblPrteDagues.Name = "lblPrteDagues";
            this.lblPrteDagues.Size = new System.Drawing.Size(38, 13);
            this.lblPrteDagues.TabIndex = 13;
            this.lblPrteDagues.Text = "Portée";
            // 
            // lblPdsDagues
            // 
            this.lblPdsDagues.AutoSize = true;
            this.lblPdsDagues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsDagues.Location = new System.Drawing.Point(128, 3);
            this.lblPdsDagues.Name = "lblPdsDagues";
            this.lblPdsDagues.Size = new System.Drawing.Size(33, 13);
            this.lblPdsDagues.TabIndex = 14;
            this.lblPdsDagues.Text = "Poids";
            // 
            // lblNbDagues
            // 
            this.lblNbDagues.AutoSize = true;
            this.lblNbDagues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbDagues.Location = new System.Drawing.Point(266, 3);
            this.lblNbDagues.Name = "lblNbDagues";
            this.lblNbDagues.Size = new System.Drawing.Size(44, 13);
            this.lblNbDagues.TabIndex = 15;
            this.lblNbDagues.Text = "Nombre";
            // 
            // lblTypeDagues
            // 
            this.lblTypeDagues.AutoSize = true;
            this.lblTypeDagues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTypeDagues.Location = new System.Drawing.Point(325, 3);
            this.lblTypeDagues.Name = "lblTypeDagues";
            this.lblTypeDagues.Size = new System.Drawing.Size(31, 13);
            this.lblTypeDagues.TabIndex = 16;
            this.lblTypeDagues.Text = "Type";
            // 
            // lblDgtsDagues
            // 
            this.lblDgtsDagues.AutoSize = true;
            this.lblDgtsDagues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDgtsDagues.Location = new System.Drawing.Point(397, 3);
            this.lblDgtsDagues.Name = "lblDgtsDagues";
            this.lblDgtsDagues.Size = new System.Drawing.Size(41, 13);
            this.lblDgtsDagues.TabIndex = 17;
            this.lblDgtsDagues.Text = "Dégâts";
            // 
            // tpHaches
            // 
            this.tpHaches.AutoScroll = true;
            this.tpHaches.Controls.Add(this.lblPrpieteHcheBhron);
            this.tpHaches.Controls.Add(this.lblVleurHcheBhron);
            this.tpHaches.Controls.Add(this.chkHcheBhron);
            this.tpHaches.Controls.Add(this.lblNomHcheBhron);
            this.tpHaches.Controls.Add(this.lblPdsHcheBhron);
            this.tpHaches.Controls.Add(this.lblPrteHcheBhron);
            this.tpHaches.Controls.Add(this.nudHcheBhron);
            this.tpHaches.Controls.Add(this.lblTpeHcheBhron);
            this.tpHaches.Controls.Add(this.lblDgtsHcheBhron);
            this.tpHaches.Controls.Add(this.label3);
            this.tpHaches.Controls.Add(this.lblPrpieteFrncsque);
            this.tpHaches.Controls.Add(this.lblPrpieteHaches);
            this.tpHaches.Controls.Add(this.lblVleurFrncsque);
            this.tpHaches.Controls.Add(this.lblVleurHache);
            this.tpHaches.Controls.Add(this.chkFrncsque);
            this.tpHaches.Controls.Add(this.lblNomFrncsque);
            this.tpHaches.Controls.Add(this.lblPdsFrncsque);
            this.tpHaches.Controls.Add(this.lblPrteFrncsque);
            this.tpHaches.Controls.Add(this.nudFrncsque);
            this.tpHaches.Controls.Add(this.lblTpeFrncsque);
            this.tpHaches.Controls.Add(this.lblDgtsFrncsque);
            this.tpHaches.Controls.Add(this.lblNomHache);
            this.tpHaches.Controls.Add(this.lblPrteHache);
            this.tpHaches.Controls.Add(this.lblPdsHache);
            this.tpHaches.Controls.Add(this.lblNbHache);
            this.tpHaches.Controls.Add(this.lblTpeHache);
            this.tpHaches.Controls.Add(this.lblDgtsHache);
            this.tpHaches.Location = new System.Drawing.Point(4, 22);
            this.tpHaches.Name = "tpHaches";
            this.tpHaches.Size = new System.Drawing.Size(689, 272);
            this.tpHaches.TabIndex = 3;
            this.tpHaches.Text = "Haches";
            this.tpHaches.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteHcheBhron
            // 
            this.lblPrpieteHcheBhron.AutoSize = true;
            this.lblPrpieteHcheBhron.Location = new System.Drawing.Point(552, 52);
            this.lblPrpieteHcheBhron.Name = "lblPrpieteHcheBhron";
            this.lblPrpieteHcheBhron.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteHcheBhron.TabIndex = 140;
            this.lblPrpieteHcheBhron.Text = "Aucune";
            // 
            // lblVleurHcheBhron
            // 
            this.lblVleurHcheBhron.AutoSize = true;
            this.lblVleurHcheBhron.Location = new System.Drawing.Point(454, 52);
            this.lblVleurHcheBhron.Name = "lblVleurHcheBhron";
            this.lblVleurHcheBhron.Size = new System.Drawing.Size(55, 13);
            this.lblVleurHcheBhron.TabIndex = 139;
            this.lblVleurHcheBhron.Text = "1 po, 9 pa";
            // 
            // chkHcheBhron
            // 
            this.chkHcheBhron.AutoSize = true;
            this.chkHcheBhron.Location = new System.Drawing.Point(13, 52);
            this.chkHcheBhron.Name = "chkHcheBhron";
            this.chkHcheBhron.Size = new System.Drawing.Size(15, 14);
            this.chkHcheBhron.TabIndex = 138;
            this.chkHcheBhron.UseVisualStyleBackColor = true;
            this.chkHcheBhron.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomHcheBhron
            // 
            this.lblNomHcheBhron.AutoSize = true;
            this.lblNomHcheBhron.Location = new System.Drawing.Point(34, 52);
            this.lblNomHcheBhron.Name = "lblNomHcheBhron";
            this.lblNomHcheBhron.Size = new System.Drawing.Size(87, 13);
            this.lblNomHcheBhron.TabIndex = 132;
            this.lblNomHcheBhron.Text = "Hache bûcheron";
            // 
            // lblPdsHcheBhron
            // 
            this.lblPdsHcheBhron.AutoSize = true;
            this.lblPdsHcheBhron.Location = new System.Drawing.Point(128, 52);
            this.lblPdsHcheBhron.Name = "lblPdsHcheBhron";
            this.lblPdsHcheBhron.Size = new System.Drawing.Size(34, 13);
            this.lblPdsHcheBhron.TabIndex = 133;
            this.lblPdsHcheBhron.Text = "2,5kg";
            // 
            // lblPrteHcheBhron
            // 
            this.lblPrteHcheBhron.AutoSize = true;
            this.lblPrteHcheBhron.Location = new System.Drawing.Point(200, 52);
            this.lblPrteHcheBhron.Name = "lblPrteHcheBhron";
            this.lblPrteHcheBhron.Size = new System.Drawing.Size(36, 13);
            this.lblPrteHcheBhron.TabIndex = 134;
            this.lblPrteHcheBhron.Text = "55 cm";
            // 
            // nudHcheBhron
            // 
            this.nudHcheBhron.Location = new System.Drawing.Point(266, 50);
            this.nudHcheBhron.Name = "nudHcheBhron";
            this.nudHcheBhron.Size = new System.Drawing.Size(41, 20);
            this.nudHcheBhron.TabIndex = 135;
            this.nudHcheBhron.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudHcheBhron.ValueChanged += new System.EventHandler(this.nudHcheBhron_ValueChanged);
            // 
            // lblTpeHcheBhron
            // 
            this.lblTpeHcheBhron.AutoSize = true;
            this.lblTpeHcheBhron.Location = new System.Drawing.Point(325, 52);
            this.lblTpeHcheBhron.Name = "lblTpeHcheBhron";
            this.lblTpeHcheBhron.Size = new System.Drawing.Size(56, 13);
            this.lblTpeHcheBhron.TabIndex = 136;
            this.lblTpeHcheBhron.Text = "Tranchant";
            // 
            // lblDgtsHcheBhron
            // 
            this.lblDgtsHcheBhron.AutoSize = true;
            this.lblDgtsHcheBhron.Location = new System.Drawing.Point(397, 52);
            this.lblDgtsHcheBhron.Name = "lblDgtsHcheBhron";
            this.lblDgtsHcheBhron.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsHcheBhron.TabIndex = 137;
            this.lblDgtsHcheBhron.Text = "1d6+1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 131;
            this.label3.Text = "AdJ : Arme de jet";
            // 
            // lblPrpieteFrncsque
            // 
            this.lblPrpieteFrncsque.AutoSize = true;
            this.lblPrpieteFrncsque.Location = new System.Drawing.Point(552, 27);
            this.lblPrpieteFrncsque.Name = "lblPrpieteFrncsque";
            this.lblPrpieteFrncsque.Size = new System.Drawing.Size(25, 13);
            this.lblPrpieteFrncsque.TabIndex = 130;
            this.lblPrpieteFrncsque.Text = "AdJ";
            // 
            // lblPrpieteHaches
            // 
            this.lblPrpieteHaches.AutoSize = true;
            this.lblPrpieteHaches.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteHaches.Location = new System.Drawing.Point(552, 3);
            this.lblPrpieteHaches.Name = "lblPrpieteHaches";
            this.lblPrpieteHaches.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteHaches.TabIndex = 129;
            this.lblPrpieteHaches.Text = "Propriété";
            // 
            // lblVleurFrncsque
            // 
            this.lblVleurFrncsque.AutoSize = true;
            this.lblVleurFrncsque.Location = new System.Drawing.Point(454, 27);
            this.lblVleurFrncsque.Name = "lblVleurFrncsque";
            this.lblVleurFrncsque.Size = new System.Drawing.Size(82, 13);
            this.lblVleurFrncsque.TabIndex = 121;
            this.lblVleurFrncsque.Text = "3 po, 7 pa, 5 pc";
            // 
            // lblVleurHache
            // 
            this.lblVleurHache.AutoSize = true;
            this.lblVleurHache.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurHache.Location = new System.Drawing.Point(454, 3);
            this.lblVleurHache.Name = "lblVleurHache";
            this.lblVleurHache.Size = new System.Drawing.Size(37, 13);
            this.lblVleurHache.TabIndex = 120;
            this.lblVleurHache.Text = "Valeur";
            // 
            // chkFrncsque
            // 
            this.chkFrncsque.AutoSize = true;
            this.chkFrncsque.Location = new System.Drawing.Point(13, 27);
            this.chkFrncsque.Name = "chkFrncsque";
            this.chkFrncsque.Size = new System.Drawing.Size(15, 14);
            this.chkFrncsque.TabIndex = 98;
            this.chkFrncsque.UseVisualStyleBackColor = true;
            this.chkFrncsque.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomFrncsque
            // 
            this.lblNomFrncsque.AutoSize = true;
            this.lblNomFrncsque.Location = new System.Drawing.Point(34, 27);
            this.lblNomFrncsque.Name = "lblNomFrncsque";
            this.lblNomFrncsque.Size = new System.Drawing.Size(59, 13);
            this.lblNomFrncsque.TabIndex = 78;
            this.lblNomFrncsque.Text = "Francisque";
            // 
            // lblPdsFrncsque
            // 
            this.lblPdsFrncsque.AutoSize = true;
            this.lblPdsFrncsque.Location = new System.Drawing.Point(128, 27);
            this.lblPdsFrncsque.Name = "lblPdsFrncsque";
            this.lblPdsFrncsque.Size = new System.Drawing.Size(34, 13);
            this.lblPdsFrncsque.TabIndex = 79;
            this.lblPdsFrncsque.Text = "1,3kg";
            // 
            // lblPrteFrncsque
            // 
            this.lblPrteFrncsque.AutoSize = true;
            this.lblPrteFrncsque.Location = new System.Drawing.Point(200, 27);
            this.lblPrteFrncsque.Name = "lblPrteFrncsque";
            this.lblPrteFrncsque.Size = new System.Drawing.Size(24, 13);
            this.lblPrteFrncsque.TabIndex = 80;
            this.lblPrteFrncsque.Text = "4 m";
            // 
            // nudFrncsque
            // 
            this.nudFrncsque.Location = new System.Drawing.Point(266, 25);
            this.nudFrncsque.Name = "nudFrncsque";
            this.nudFrncsque.Size = new System.Drawing.Size(41, 20);
            this.nudFrncsque.TabIndex = 81;
            this.nudFrncsque.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFrncsque.ValueChanged += new System.EventHandler(this.nudFrncsque_ValueChanged);
            // 
            // lblTpeFrncsque
            // 
            this.lblTpeFrncsque.AutoSize = true;
            this.lblTpeFrncsque.Location = new System.Drawing.Point(325, 27);
            this.lblTpeFrncsque.Name = "lblTpeFrncsque";
            this.lblTpeFrncsque.Size = new System.Drawing.Size(56, 13);
            this.lblTpeFrncsque.TabIndex = 82;
            this.lblTpeFrncsque.Text = "Tranchant";
            // 
            // lblDgtsFrncsque
            // 
            this.lblDgtsFrncsque.AutoSize = true;
            this.lblDgtsFrncsque.Location = new System.Drawing.Point(397, 27);
            this.lblDgtsFrncsque.Name = "lblDgtsFrncsque";
            this.lblDgtsFrncsque.Size = new System.Drawing.Size(43, 13);
            this.lblDgtsFrncsque.TabIndex = 83;
            this.lblDgtsFrncsque.Text = "1d10+2";
            // 
            // lblNomHache
            // 
            this.lblNomHache.AutoSize = true;
            this.lblNomHache.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomHache.Location = new System.Drawing.Point(34, 3);
            this.lblNomHache.Name = "lblNomHache";
            this.lblNomHache.Size = new System.Drawing.Size(29, 13);
            this.lblNomHache.TabIndex = 18;
            this.lblNomHache.Text = "Nom";
            // 
            // lblPrteHache
            // 
            this.lblPrteHache.AutoSize = true;
            this.lblPrteHache.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrteHache.Location = new System.Drawing.Point(200, 3);
            this.lblPrteHache.Name = "lblPrteHache";
            this.lblPrteHache.Size = new System.Drawing.Size(38, 13);
            this.lblPrteHache.TabIndex = 19;
            this.lblPrteHache.Text = "Portée";
            // 
            // lblPdsHache
            // 
            this.lblPdsHache.AutoSize = true;
            this.lblPdsHache.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsHache.Location = new System.Drawing.Point(128, 3);
            this.lblPdsHache.Name = "lblPdsHache";
            this.lblPdsHache.Size = new System.Drawing.Size(33, 13);
            this.lblPdsHache.TabIndex = 20;
            this.lblPdsHache.Text = "Poids";
            // 
            // lblNbHache
            // 
            this.lblNbHache.AutoSize = true;
            this.lblNbHache.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbHache.Location = new System.Drawing.Point(266, 3);
            this.lblNbHache.Name = "lblNbHache";
            this.lblNbHache.Size = new System.Drawing.Size(44, 13);
            this.lblNbHache.TabIndex = 21;
            this.lblNbHache.Text = "Nombre";
            // 
            // lblTpeHache
            // 
            this.lblTpeHache.AutoSize = true;
            this.lblTpeHache.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTpeHache.Location = new System.Drawing.Point(325, 3);
            this.lblTpeHache.Name = "lblTpeHache";
            this.lblTpeHache.Size = new System.Drawing.Size(31, 13);
            this.lblTpeHache.TabIndex = 22;
            this.lblTpeHache.Text = "Type";
            // 
            // lblDgtsHache
            // 
            this.lblDgtsHache.AutoSize = true;
            this.lblDgtsHache.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDgtsHache.Location = new System.Drawing.Point(397, 3);
            this.lblDgtsHache.Name = "lblDgtsHache";
            this.lblDgtsHache.Size = new System.Drawing.Size(41, 13);
            this.lblDgtsHache.TabIndex = 23;
            this.lblDgtsHache.Text = "Dégâts";
            // 
            // tpMasse
            // 
            this.tpMasse.AutoScroll = true;
            this.tpMasse.Controls.Add(this.lblPrpieteMrteauFgron);
            this.tpMasse.Controls.Add(this.lblVleurMrteauFgron);
            this.tpMasse.Controls.Add(this.chkMrteauFgron);
            this.tpMasse.Controls.Add(this.lblNomMrteauFgron);
            this.tpMasse.Controls.Add(this.lblPdsMrteauFgron);
            this.tpMasse.Controls.Add(this.lblPrteMrteauFgron);
            this.tpMasse.Controls.Add(this.nudMrteauFgron);
            this.tpMasse.Controls.Add(this.lblTpeMrteauFgron);
            this.tpMasse.Controls.Add(this.lblDgtsMrteauFgron);
            this.tpMasse.Controls.Add(this.label1);
            this.tpMasse.Controls.Add(this.lblPrpieteMsueChne);
            this.tpMasse.Controls.Add(this.lblVleurMsueChne);
            this.tpMasse.Controls.Add(this.chkMsueChne);
            this.tpMasse.Controls.Add(this.lblNomMsueChne);
            this.tpMasse.Controls.Add(this.lblPdsMsueChne);
            this.tpMasse.Controls.Add(this.lblPrteMsueChne);
            this.tpMasse.Controls.Add(this.nudMsueChne);
            this.tpMasse.Controls.Add(this.lblTpeMsueChne);
            this.tpMasse.Controls.Add(this.lblDgtsMsueChne);
            this.tpMasse.Controls.Add(this.lblPrpieteMassues);
            this.tpMasse.Controls.Add(this.lblVleurMassues);
            this.tpMasse.Controls.Add(this.lblNomMassues);
            this.tpMasse.Controls.Add(this.lblPrteMassues);
            this.tpMasse.Controls.Add(this.lblPdsMassues);
            this.tpMasse.Controls.Add(this.lblNbMassues);
            this.tpMasse.Controls.Add(this.lblTpeMassues);
            this.tpMasse.Controls.Add(this.lblDgtsMassues);
            this.tpMasse.Location = new System.Drawing.Point(4, 22);
            this.tpMasse.Name = "tpMasse";
            this.tpMasse.Size = new System.Drawing.Size(689, 272);
            this.tpMasse.TabIndex = 4;
            this.tpMasse.Text = "Masses";
            this.tpMasse.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteMrteauFgron
            // 
            this.lblPrpieteMrteauFgron.AutoSize = true;
            this.lblPrpieteMrteauFgron.Location = new System.Drawing.Point(552, 52);
            this.lblPrpieteMrteauFgron.Name = "lblPrpieteMrteauFgron";
            this.lblPrpieteMrteauFgron.Size = new System.Drawing.Size(38, 13);
            this.lblPrpieteMrteauFgron.TabIndex = 156;
            this.lblPrpieteMrteauFgron.Text = "Assom";
            // 
            // lblVleurMrteauFgron
            // 
            this.lblVleurMrteauFgron.AutoSize = true;
            this.lblVleurMrteauFgron.Location = new System.Drawing.Point(454, 52);
            this.lblVleurMrteauFgron.Name = "lblVleurMrteauFgron";
            this.lblVleurMrteauFgron.Size = new System.Drawing.Size(82, 13);
            this.lblVleurMrteauFgron.TabIndex = 155;
            this.lblVleurMrteauFgron.Text = "1 po, 6 pa, 4 pc";
            // 
            // chkMrteauFgron
            // 
            this.chkMrteauFgron.AutoSize = true;
            this.chkMrteauFgron.Location = new System.Drawing.Point(13, 52);
            this.chkMrteauFgron.Name = "chkMrteauFgron";
            this.chkMrteauFgron.Size = new System.Drawing.Size(15, 14);
            this.chkMrteauFgron.TabIndex = 154;
            this.chkMrteauFgron.UseVisualStyleBackColor = true;
            this.chkMrteauFgron.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomMrteauFgron
            // 
            this.lblNomMrteauFgron.AutoSize = true;
            this.lblNomMrteauFgron.Location = new System.Drawing.Point(34, 52);
            this.lblNomMrteauFgron.Name = "lblNomMrteauFgron";
            this.lblNomMrteauFgron.Size = new System.Drawing.Size(88, 13);
            this.lblNomMrteauFgron.TabIndex = 148;
            this.lblNomMrteauFgron.Text = "Marteau forgeron";
            // 
            // lblPdsMrteauFgron
            // 
            this.lblPdsMrteauFgron.AutoSize = true;
            this.lblPdsMrteauFgron.Location = new System.Drawing.Point(128, 52);
            this.lblPdsMrteauFgron.Name = "lblPdsMrteauFgron";
            this.lblPdsMrteauFgron.Size = new System.Drawing.Size(34, 13);
            this.lblPdsMrteauFgron.TabIndex = 149;
            this.lblPdsMrteauFgron.Text = "1,9kg";
            // 
            // lblPrteMrteauFgron
            // 
            this.lblPrteMrteauFgron.AutoSize = true;
            this.lblPrteMrteauFgron.Location = new System.Drawing.Point(200, 52);
            this.lblPrteMrteauFgron.Name = "lblPrteMrteauFgron";
            this.lblPrteMrteauFgron.Size = new System.Drawing.Size(36, 13);
            this.lblPrteMrteauFgron.TabIndex = 150;
            this.lblPrteMrteauFgron.Text = "50 cm";
            // 
            // nudMrteauFgron
            // 
            this.nudMrteauFgron.Location = new System.Drawing.Point(266, 50);
            this.nudMrteauFgron.Name = "nudMrteauFgron";
            this.nudMrteauFgron.Size = new System.Drawing.Size(41, 20);
            this.nudMrteauFgron.TabIndex = 151;
            this.nudMrteauFgron.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudMrteauFgron.ValueChanged += new System.EventHandler(this.nudMrteauFgron_ValueChanged);
            // 
            // lblTpeMrteauFgron
            // 
            this.lblTpeMrteauFgron.AutoSize = true;
            this.lblTpeMrteauFgron.Location = new System.Drawing.Point(325, 52);
            this.lblTpeMrteauFgron.Name = "lblTpeMrteauFgron";
            this.lblTpeMrteauFgron.Size = new System.Drawing.Size(62, 13);
            this.lblTpeMrteauFgron.TabIndex = 152;
            this.lblTpeMrteauFgron.Text = "Contondant";
            // 
            // lblDgtsMrteauFgron
            // 
            this.lblDgtsMrteauFgron.AutoSize = true;
            this.lblDgtsMrteauFgron.Location = new System.Drawing.Point(397, 52);
            this.lblDgtsMrteauFgron.Name = "lblDgtsMrteauFgron";
            this.lblDgtsMrteauFgron.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsMrteauFgron.TabIndex = 153;
            this.lblDgtsMrteauFgron.Text = "1d6+2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(232, 13);
            this.label1.TabIndex = 147;
            this.label1.Text = "Assom : peut assommer la cible (sauf exception)";
            // 
            // lblPrpieteMsueChne
            // 
            this.lblPrpieteMsueChne.AutoSize = true;
            this.lblPrpieteMsueChne.Location = new System.Drawing.Point(552, 27);
            this.lblPrpieteMsueChne.Name = "lblPrpieteMsueChne";
            this.lblPrpieteMsueChne.Size = new System.Drawing.Size(38, 13);
            this.lblPrpieteMsueChne.TabIndex = 146;
            this.lblPrpieteMsueChne.Text = "Assom";
            // 
            // lblVleurMsueChne
            // 
            this.lblVleurMsueChne.AutoSize = true;
            this.lblVleurMsueChne.Location = new System.Drawing.Point(454, 27);
            this.lblVleurMsueChne.Name = "lblVleurMsueChne";
            this.lblVleurMsueChne.Size = new System.Drawing.Size(28, 13);
            this.lblVleurMsueChne.TabIndex = 145;
            this.lblVleurMsueChne.Text = "1 po";
            // 
            // chkMsueChne
            // 
            this.chkMsueChne.AutoSize = true;
            this.chkMsueChne.Location = new System.Drawing.Point(13, 27);
            this.chkMsueChne.Name = "chkMsueChne";
            this.chkMsueChne.Size = new System.Drawing.Size(15, 14);
            this.chkMsueChne.TabIndex = 144;
            this.chkMsueChne.UseVisualStyleBackColor = true;
            this.chkMsueChne.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomMsueChne
            // 
            this.lblNomMsueChne.AutoSize = true;
            this.lblNomMsueChne.Location = new System.Drawing.Point(34, 27);
            this.lblNomMsueChne.Name = "lblNomMsueChne";
            this.lblNomMsueChne.Size = new System.Drawing.Size(77, 13);
            this.lblNomMsueChne.TabIndex = 138;
            this.lblNomMsueChne.Text = "Massue chêne";
            // 
            // lblPdsMsueChne
            // 
            this.lblPdsMsueChne.AutoSize = true;
            this.lblPdsMsueChne.Location = new System.Drawing.Point(128, 27);
            this.lblPdsMsueChne.Name = "lblPdsMsueChne";
            this.lblPdsMsueChne.Size = new System.Drawing.Size(40, 13);
            this.lblPdsMsueChne.TabIndex = 139;
            this.lblPdsMsueChne.Text = "0,55kg";
            // 
            // lblPrteMsueChne
            // 
            this.lblPrteMsueChne.AutoSize = true;
            this.lblPrteMsueChne.Location = new System.Drawing.Point(200, 27);
            this.lblPrteMsueChne.Name = "lblPrteMsueChne";
            this.lblPrteMsueChne.Size = new System.Drawing.Size(36, 13);
            this.lblPrteMsueChne.TabIndex = 140;
            this.lblPrteMsueChne.Text = "45 cm";
            // 
            // nudMsueChne
            // 
            this.nudMsueChne.Location = new System.Drawing.Point(266, 25);
            this.nudMsueChne.Name = "nudMsueChne";
            this.nudMsueChne.Size = new System.Drawing.Size(41, 20);
            this.nudMsueChne.TabIndex = 141;
            this.nudMsueChne.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudMsueChne.ValueChanged += new System.EventHandler(this.nudMsueChne_ValueChanged);
            // 
            // lblTpeMsueChne
            // 
            this.lblTpeMsueChne.AutoSize = true;
            this.lblTpeMsueChne.Location = new System.Drawing.Point(325, 27);
            this.lblTpeMsueChne.Name = "lblTpeMsueChne";
            this.lblTpeMsueChne.Size = new System.Drawing.Size(62, 13);
            this.lblTpeMsueChne.TabIndex = 142;
            this.lblTpeMsueChne.Text = "Contondant";
            // 
            // lblDgtsMsueChne
            // 
            this.lblDgtsMsueChne.AutoSize = true;
            this.lblDgtsMsueChne.Location = new System.Drawing.Point(397, 27);
            this.lblDgtsMsueChne.Name = "lblDgtsMsueChne";
            this.lblDgtsMsueChne.Size = new System.Drawing.Size(37, 13);
            this.lblDgtsMsueChne.TabIndex = 143;
            this.lblDgtsMsueChne.Text = "1d4+1";
            // 
            // lblPrpieteMassues
            // 
            this.lblPrpieteMassues.AutoSize = true;
            this.lblPrpieteMassues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteMassues.Location = new System.Drawing.Point(552, 3);
            this.lblPrpieteMassues.Name = "lblPrpieteMassues";
            this.lblPrpieteMassues.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteMassues.TabIndex = 137;
            this.lblPrpieteMassues.Text = "Propriété";
            // 
            // lblVleurMassues
            // 
            this.lblVleurMassues.AutoSize = true;
            this.lblVleurMassues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurMassues.Location = new System.Drawing.Point(454, 3);
            this.lblVleurMassues.Name = "lblVleurMassues";
            this.lblVleurMassues.Size = new System.Drawing.Size(37, 13);
            this.lblVleurMassues.TabIndex = 136;
            this.lblVleurMassues.Text = "Valeur";
            // 
            // lblNomMassues
            // 
            this.lblNomMassues.AutoSize = true;
            this.lblNomMassues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomMassues.Location = new System.Drawing.Point(34, 3);
            this.lblNomMassues.Name = "lblNomMassues";
            this.lblNomMassues.Size = new System.Drawing.Size(29, 13);
            this.lblNomMassues.TabIndex = 130;
            this.lblNomMassues.Text = "Nom";
            // 
            // lblPrteMassues
            // 
            this.lblPrteMassues.AutoSize = true;
            this.lblPrteMassues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrteMassues.Location = new System.Drawing.Point(200, 3);
            this.lblPrteMassues.Name = "lblPrteMassues";
            this.lblPrteMassues.Size = new System.Drawing.Size(38, 13);
            this.lblPrteMassues.TabIndex = 131;
            this.lblPrteMassues.Text = "Portée";
            // 
            // lblPdsMassues
            // 
            this.lblPdsMassues.AutoSize = true;
            this.lblPdsMassues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsMassues.Location = new System.Drawing.Point(128, 3);
            this.lblPdsMassues.Name = "lblPdsMassues";
            this.lblPdsMassues.Size = new System.Drawing.Size(33, 13);
            this.lblPdsMassues.TabIndex = 132;
            this.lblPdsMassues.Text = "Poids";
            // 
            // lblNbMassues
            // 
            this.lblNbMassues.AutoSize = true;
            this.lblNbMassues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbMassues.Location = new System.Drawing.Point(266, 3);
            this.lblNbMassues.Name = "lblNbMassues";
            this.lblNbMassues.Size = new System.Drawing.Size(44, 13);
            this.lblNbMassues.TabIndex = 133;
            this.lblNbMassues.Text = "Nombre";
            // 
            // lblTpeMassues
            // 
            this.lblTpeMassues.AutoSize = true;
            this.lblTpeMassues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTpeMassues.Location = new System.Drawing.Point(325, 3);
            this.lblTpeMassues.Name = "lblTpeMassues";
            this.lblTpeMassues.Size = new System.Drawing.Size(31, 13);
            this.lblTpeMassues.TabIndex = 134;
            this.lblTpeMassues.Text = "Type";
            // 
            // lblDgtsMassues
            // 
            this.lblDgtsMassues.AutoSize = true;
            this.lblDgtsMassues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDgtsMassues.Location = new System.Drawing.Point(397, 3);
            this.lblDgtsMassues.Name = "lblDgtsMassues";
            this.lblDgtsMassues.Size = new System.Drawing.Size(41, 13);
            this.lblDgtsMassues.TabIndex = 135;
            this.lblDgtsMassues.Text = "Dégâts";
            // 
            // tpArc
            // 
            this.tpArc.AutoScroll = true;
            this.tpArc.Controls.Add(this.lblPrpieteFnde);
            this.tpArc.Controls.Add(this.lblPrpieteAblte);
            this.tpArc.Controls.Add(this.lblDescArcs);
            this.tpArc.Controls.Add(this.lblPrpieteArc);
            this.tpArc.Controls.Add(this.lblPrpieteArcs);
            this.tpArc.Controls.Add(this.lblVleurFnde);
            this.tpArc.Controls.Add(this.lblVleurAblte);
            this.tpArc.Controls.Add(this.lblVleurArc);
            this.tpArc.Controls.Add(this.lblVleurArcs);
            this.tpArc.Controls.Add(this.lblPdsFnde);
            this.tpArc.Controls.Add(this.chkFnde);
            this.tpArc.Controls.Add(this.chkAblte);
            this.tpArc.Controls.Add(this.chkArc);
            this.tpArc.Controls.Add(this.lblNomFnde);
            this.tpArc.Controls.Add(this.lblPrteFnde);
            this.tpArc.Controls.Add(this.nudFnde);
            this.tpArc.Controls.Add(this.lblTpeFnde);
            this.tpArc.Controls.Add(this.lblDgtsFnde);
            this.tpArc.Controls.Add(this.lblNomAblte);
            this.tpArc.Controls.Add(this.lblPdsAblte);
            this.tpArc.Controls.Add(this.lblPrteAblte);
            this.tpArc.Controls.Add(this.nudAblte);
            this.tpArc.Controls.Add(this.lblTpeAblte);
            this.tpArc.Controls.Add(this.lblDgtsAblte);
            this.tpArc.Controls.Add(this.lblNomArc);
            this.tpArc.Controls.Add(this.lblPdsArc);
            this.tpArc.Controls.Add(this.lblPrteArc);
            this.tpArc.Controls.Add(this.nudArc);
            this.tpArc.Controls.Add(this.lblTpeArc);
            this.tpArc.Controls.Add(this.lblDgtsArc);
            this.tpArc.Controls.Add(this.lblNomArcs);
            this.tpArc.Controls.Add(this.lblPrteArcs);
            this.tpArc.Controls.Add(this.lblPdsArcs);
            this.tpArc.Controls.Add(this.lblNbArcs);
            this.tpArc.Controls.Add(this.lblTpeArcs);
            this.tpArc.Controls.Add(this.lblDgtsArcs);
            this.tpArc.Location = new System.Drawing.Point(4, 22);
            this.tpArc.Name = "tpArc";
            this.tpArc.Size = new System.Drawing.Size(689, 272);
            this.tpArc.TabIndex = 5;
            this.tpArc.Text = "Arcs";
            this.tpArc.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteFnde
            // 
            this.lblPrpieteFnde.AutoSize = true;
            this.lblPrpieteFnde.Location = new System.Drawing.Point(552, 77);
            this.lblPrpieteFnde.Name = "lblPrpieteFnde";
            this.lblPrpieteFnde.Size = new System.Drawing.Size(27, 13);
            this.lblPrpieteFnde.TabIndex = 134;
            this.lblPrpieteFnde.Text = "AdT";
            // 
            // lblPrpieteAblte
            // 
            this.lblPrpieteAblte.AutoSize = true;
            this.lblPrpieteAblte.Location = new System.Drawing.Point(552, 52);
            this.lblPrpieteAblte.Name = "lblPrpieteAblte";
            this.lblPrpieteAblte.Size = new System.Drawing.Size(27, 13);
            this.lblPrpieteAblte.TabIndex = 133;
            this.lblPrpieteAblte.Text = "AdT";
            // 
            // lblDescArcs
            // 
            this.lblDescArcs.AutoSize = true;
            this.lblDescArcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescArcs.Location = new System.Drawing.Point(8, 131);
            this.lblDescArcs.Name = "lblDescArcs";
            this.lblDescArcs.Size = new System.Drawing.Size(218, 13);
            this.lblDescArcs.TabIndex = 132;
            this.lblDescArcs.Text = "AdT : Arme de trait; mun : + dégâts munitions";
            // 
            // lblPrpieteArc
            // 
            this.lblPrpieteArc.AutoSize = true;
            this.lblPrpieteArc.Location = new System.Drawing.Point(552, 27);
            this.lblPrpieteArc.Name = "lblPrpieteArc";
            this.lblPrpieteArc.Size = new System.Drawing.Size(27, 13);
            this.lblPrpieteArc.TabIndex = 131;
            this.lblPrpieteArc.Text = "AdT";
            // 
            // lblPrpieteArcs
            // 
            this.lblPrpieteArcs.AutoSize = true;
            this.lblPrpieteArcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteArcs.Location = new System.Drawing.Point(552, 3);
            this.lblPrpieteArcs.Name = "lblPrpieteArcs";
            this.lblPrpieteArcs.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteArcs.TabIndex = 130;
            this.lblPrpieteArcs.Text = "Propriété";
            // 
            // lblVleurFnde
            // 
            this.lblVleurFnde.AutoSize = true;
            this.lblVleurFnde.Location = new System.Drawing.Point(454, 77);
            this.lblVleurFnde.Name = "lblVleurFnde";
            this.lblVleurFnde.Size = new System.Drawing.Size(55, 13);
            this.lblVleurFnde.TabIndex = 125;
            this.lblVleurFnde.Text = "2 po, 6 pa";
            // 
            // lblVleurAblte
            // 
            this.lblVleurAblte.AutoSize = true;
            this.lblVleurAblte.Location = new System.Drawing.Point(454, 52);
            this.lblVleurAblte.Name = "lblVleurAblte";
            this.lblVleurAblte.Size = new System.Drawing.Size(55, 13);
            this.lblVleurAblte.TabIndex = 124;
            this.lblVleurAblte.Text = "9 po, 5 pa";
            // 
            // lblVleurArc
            // 
            this.lblVleurArc.AutoSize = true;
            this.lblVleurArc.Location = new System.Drawing.Point(454, 27);
            this.lblVleurArc.Name = "lblVleurArc";
            this.lblVleurArc.Size = new System.Drawing.Size(82, 13);
            this.lblVleurArc.TabIndex = 123;
            this.lblVleurArc.Text = "8 po, 3 pa, 2 pc";
            // 
            // lblVleurArcs
            // 
            this.lblVleurArcs.AutoSize = true;
            this.lblVleurArcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurArcs.Location = new System.Drawing.Point(454, 3);
            this.lblVleurArcs.Name = "lblVleurArcs";
            this.lblVleurArcs.Size = new System.Drawing.Size(37, 13);
            this.lblVleurArcs.TabIndex = 122;
            this.lblVleurArcs.Text = "Valeur";
            // 
            // lblPdsFnde
            // 
            this.lblPdsFnde.AutoSize = true;
            this.lblPdsFnde.Location = new System.Drawing.Point(128, 77);
            this.lblPdsFnde.Name = "lblPdsFnde";
            this.lblPdsFnde.Size = new System.Drawing.Size(46, 13);
            this.lblPdsFnde.TabIndex = 69;
            this.lblPdsFnde.Text = "0,030kg";
            // 
            // chkFnde
            // 
            this.chkFnde.AutoSize = true;
            this.chkFnde.Location = new System.Drawing.Point(13, 77);
            this.chkFnde.Name = "chkFnde";
            this.chkFnde.Size = new System.Drawing.Size(15, 14);
            this.chkFnde.TabIndex = 68;
            this.chkFnde.UseVisualStyleBackColor = true;
            this.chkFnde.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkAblte
            // 
            this.chkAblte.AutoSize = true;
            this.chkAblte.Location = new System.Drawing.Point(13, 52);
            this.chkAblte.Name = "chkAblte";
            this.chkAblte.Size = new System.Drawing.Size(15, 14);
            this.chkAblte.TabIndex = 67;
            this.chkAblte.UseVisualStyleBackColor = true;
            this.chkAblte.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkArc
            // 
            this.chkArc.AutoSize = true;
            this.chkArc.Location = new System.Drawing.Point(13, 27);
            this.chkArc.Name = "chkArc";
            this.chkArc.Size = new System.Drawing.Size(15, 14);
            this.chkArc.TabIndex = 66;
            this.chkArc.UseVisualStyleBackColor = true;
            this.chkArc.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomFnde
            // 
            this.lblNomFnde.AutoSize = true;
            this.lblNomFnde.Location = new System.Drawing.Point(34, 77);
            this.lblNomFnde.Name = "lblNomFnde";
            this.lblNomFnde.Size = new System.Drawing.Size(40, 13);
            this.lblNomFnde.TabIndex = 60;
            this.lblNomFnde.Text = "Fronde";
            // 
            // lblPrteFnde
            // 
            this.lblPrteFnde.AutoSize = true;
            this.lblPrteFnde.Location = new System.Drawing.Point(200, 77);
            this.lblPrteFnde.Name = "lblPrteFnde";
            this.lblPrteFnde.Size = new System.Drawing.Size(24, 13);
            this.lblPrteFnde.TabIndex = 62;
            this.lblPrteFnde.Text = "9 m";
            // 
            // nudFnde
            // 
            this.nudFnde.Location = new System.Drawing.Point(266, 77);
            this.nudFnde.Name = "nudFnde";
            this.nudFnde.Size = new System.Drawing.Size(41, 20);
            this.nudFnde.TabIndex = 63;
            this.nudFnde.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFnde.ValueChanged += new System.EventHandler(this.nudFnde_ValueChanged);
            // 
            // lblTpeFnde
            // 
            this.lblTpeFnde.AutoSize = true;
            this.lblTpeFnde.Location = new System.Drawing.Point(325, 77);
            this.lblTpeFnde.Name = "lblTpeFnde";
            this.lblTpeFnde.Size = new System.Drawing.Size(62, 13);
            this.lblTpeFnde.TabIndex = 64;
            this.lblTpeFnde.Text = "Contondant";
            // 
            // lblDgtsFnde
            // 
            this.lblDgtsFnde.AutoSize = true;
            this.lblDgtsFnde.Location = new System.Drawing.Point(397, 77);
            this.lblDgtsFnde.Name = "lblDgtsFnde";
            this.lblDgtsFnde.Size = new System.Drawing.Size(39, 13);
            this.lblDgtsFnde.TabIndex = 65;
            this.lblDgtsFnde.Text = "4+mun";
            // 
            // lblNomAblte
            // 
            this.lblNomAblte.AutoSize = true;
            this.lblNomAblte.Location = new System.Drawing.Point(34, 52);
            this.lblNomAblte.Name = "lblNomAblte";
            this.lblNomAblte.Size = new System.Drawing.Size(46, 13);
            this.lblNomAblte.TabIndex = 54;
            this.lblNomAblte.Text = "Arbalète";
            // 
            // lblPdsAblte
            // 
            this.lblPdsAblte.AutoSize = true;
            this.lblPdsAblte.Location = new System.Drawing.Point(128, 52);
            this.lblPdsAblte.Name = "lblPdsAblte";
            this.lblPdsAblte.Size = new System.Drawing.Size(34, 13);
            this.lblPdsAblte.TabIndex = 55;
            this.lblPdsAblte.Text = "2,0kg";
            // 
            // lblPrteAblte
            // 
            this.lblPrteAblte.AutoSize = true;
            this.lblPrteAblte.Location = new System.Drawing.Point(200, 52);
            this.lblPrteAblte.Name = "lblPrteAblte";
            this.lblPrteAblte.Size = new System.Drawing.Size(30, 13);
            this.lblPrteAblte.TabIndex = 56;
            this.lblPrteAblte.Text = "15 m";
            // 
            // nudAblte
            // 
            this.nudAblte.Location = new System.Drawing.Point(266, 50);
            this.nudAblte.Name = "nudAblte";
            this.nudAblte.Size = new System.Drawing.Size(41, 20);
            this.nudAblte.TabIndex = 57;
            this.nudAblte.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudAblte.ValueChanged += new System.EventHandler(this.nudAblte_ValueChanged);
            // 
            // lblTpeAblte
            // 
            this.lblTpeAblte.AutoSize = true;
            this.lblTpeAblte.Location = new System.Drawing.Point(325, 52);
            this.lblTpeAblte.Name = "lblTpeAblte";
            this.lblTpeAblte.Size = new System.Drawing.Size(50, 13);
            this.lblTpeAblte.TabIndex = 58;
            this.lblTpeAblte.Text = "Perforant";
            // 
            // lblDgtsAblte
            // 
            this.lblDgtsAblte.AutoSize = true;
            this.lblDgtsAblte.Location = new System.Drawing.Point(397, 52);
            this.lblDgtsAblte.Name = "lblDgtsAblte";
            this.lblDgtsAblte.Size = new System.Drawing.Size(45, 13);
            this.lblDgtsAblte.TabIndex = 59;
            this.lblDgtsAblte.Text = "10+mun";
            // 
            // lblNomArc
            // 
            this.lblNomArc.AutoSize = true;
            this.lblNomArc.Location = new System.Drawing.Point(34, 27);
            this.lblNomArc.Name = "lblNomArc";
            this.lblNomArc.Size = new System.Drawing.Size(23, 13);
            this.lblNomArc.TabIndex = 36;
            this.lblNomArc.Text = "Arc";
            // 
            // lblPdsArc
            // 
            this.lblPdsArc.AutoSize = true;
            this.lblPdsArc.Location = new System.Drawing.Point(128, 27);
            this.lblPdsArc.Name = "lblPdsArc";
            this.lblPdsArc.Size = new System.Drawing.Size(34, 13);
            this.lblPdsArc.TabIndex = 37;
            this.lblPdsArc.Text = "1,0kg";
            // 
            // lblPrteArc
            // 
            this.lblPrteArc.AutoSize = true;
            this.lblPrteArc.Location = new System.Drawing.Point(200, 27);
            this.lblPrteArc.Name = "lblPrteArc";
            this.lblPrteArc.Size = new System.Drawing.Size(30, 13);
            this.lblPrteArc.TabIndex = 38;
            this.lblPrteArc.Text = "18 m";
            // 
            // nudArc
            // 
            this.nudArc.Location = new System.Drawing.Point(266, 25);
            this.nudArc.Name = "nudArc";
            this.nudArc.Size = new System.Drawing.Size(41, 20);
            this.nudArc.TabIndex = 39;
            this.nudArc.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudArc.ValueChanged += new System.EventHandler(this.nudArc_ValueChanged);
            // 
            // lblTpeArc
            // 
            this.lblTpeArc.AutoSize = true;
            this.lblTpeArc.Location = new System.Drawing.Point(325, 27);
            this.lblTpeArc.Name = "lblTpeArc";
            this.lblTpeArc.Size = new System.Drawing.Size(50, 13);
            this.lblTpeArc.TabIndex = 40;
            this.lblTpeArc.Text = "Perforant";
            // 
            // lblDgtsArc
            // 
            this.lblDgtsArc.AutoSize = true;
            this.lblDgtsArc.Location = new System.Drawing.Point(397, 27);
            this.lblDgtsArc.Name = "lblDgtsArc";
            this.lblDgtsArc.Size = new System.Drawing.Size(39, 13);
            this.lblDgtsArc.TabIndex = 41;
            this.lblDgtsArc.Text = "8+mun";
            // 
            // lblNomArcs
            // 
            this.lblNomArcs.AutoSize = true;
            this.lblNomArcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomArcs.Location = new System.Drawing.Point(34, 3);
            this.lblNomArcs.Name = "lblNomArcs";
            this.lblNomArcs.Size = new System.Drawing.Size(29, 13);
            this.lblNomArcs.TabIndex = 6;
            this.lblNomArcs.Text = "Nom";
            // 
            // lblPrteArcs
            // 
            this.lblPrteArcs.AutoSize = true;
            this.lblPrteArcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrteArcs.Location = new System.Drawing.Point(200, 3);
            this.lblPrteArcs.Name = "lblPrteArcs";
            this.lblPrteArcs.Size = new System.Drawing.Size(38, 13);
            this.lblPrteArcs.TabIndex = 7;
            this.lblPrteArcs.Text = "Portée";
            // 
            // lblPdsArcs
            // 
            this.lblPdsArcs.AutoSize = true;
            this.lblPdsArcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsArcs.Location = new System.Drawing.Point(128, 3);
            this.lblPdsArcs.Name = "lblPdsArcs";
            this.lblPdsArcs.Size = new System.Drawing.Size(33, 13);
            this.lblPdsArcs.TabIndex = 8;
            this.lblPdsArcs.Text = "Poids";
            // 
            // lblNbArcs
            // 
            this.lblNbArcs.AutoSize = true;
            this.lblNbArcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbArcs.Location = new System.Drawing.Point(266, 3);
            this.lblNbArcs.Name = "lblNbArcs";
            this.lblNbArcs.Size = new System.Drawing.Size(44, 13);
            this.lblNbArcs.TabIndex = 9;
            this.lblNbArcs.Text = "Nombre";
            // 
            // lblTpeArcs
            // 
            this.lblTpeArcs.AutoSize = true;
            this.lblTpeArcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTpeArcs.Location = new System.Drawing.Point(325, 3);
            this.lblTpeArcs.Name = "lblTpeArcs";
            this.lblTpeArcs.Size = new System.Drawing.Size(31, 13);
            this.lblTpeArcs.TabIndex = 10;
            this.lblTpeArcs.Text = "Type";
            // 
            // lblDgtsArcs
            // 
            this.lblDgtsArcs.AutoSize = true;
            this.lblDgtsArcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDgtsArcs.Location = new System.Drawing.Point(397, 3);
            this.lblDgtsArcs.Name = "lblDgtsArcs";
            this.lblDgtsArcs.Size = new System.Drawing.Size(41, 13);
            this.lblDgtsArcs.TabIndex = 11;
            this.lblDgtsArcs.Text = "Dégâts";
            // 
            // tpChaînes
            // 
            this.tpChaînes.AutoScroll = true;
            this.tpChaînes.Controls.Add(this.lblPrpieteFaC);
            this.tpChaînes.Controls.Add(this.lblPrpieteFouet);
            this.tpChaînes.Controls.Add(this.label12);
            this.tpChaînes.Controls.Add(this.lblVleurFaC);
            this.tpChaînes.Controls.Add(this.lblVleurFouet);
            this.tpChaînes.Controls.Add(this.lblVleurChaines);
            this.tpChaînes.Controls.Add(this.lblPdsFouet);
            this.tpChaînes.Controls.Add(this.chkFaC);
            this.tpChaînes.Controls.Add(this.chkFouet);
            this.tpChaînes.Controls.Add(this.lblNomFaC);
            this.tpChaînes.Controls.Add(this.lblPdsFaC);
            this.tpChaînes.Controls.Add(this.lblPrteFaC);
            this.tpChaînes.Controls.Add(this.nudFaC);
            this.tpChaînes.Controls.Add(this.lblTpeFaC);
            this.tpChaînes.Controls.Add(this.lblDgtsFaC);
            this.tpChaînes.Controls.Add(this.lblNomFouet);
            this.tpChaînes.Controls.Add(this.lblPrteFouet);
            this.tpChaînes.Controls.Add(this.nudFouet);
            this.tpChaînes.Controls.Add(this.lblTpeFouet);
            this.tpChaînes.Controls.Add(this.lblDgtsFouet);
            this.tpChaînes.Controls.Add(this.lblNomChaines);
            this.tpChaînes.Controls.Add(this.lblPrteChaines);
            this.tpChaînes.Controls.Add(this.lblPdsChaines);
            this.tpChaînes.Controls.Add(this.lblNbChaines);
            this.tpChaînes.Controls.Add(this.lblTpeChaines);
            this.tpChaînes.Controls.Add(this.lblDgtsChaines);
            this.tpChaînes.Location = new System.Drawing.Point(4, 22);
            this.tpChaînes.Name = "tpChaînes";
            this.tpChaînes.Size = new System.Drawing.Size(689, 272);
            this.tpChaînes.TabIndex = 6;
            this.tpChaînes.Text = "Chaînes";
            this.tpChaînes.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteFaC
            // 
            this.lblPrpieteFaC.AutoSize = true;
            this.lblPrpieteFaC.Location = new System.Drawing.Point(552, 52);
            this.lblPrpieteFaC.Name = "lblPrpieteFaC";
            this.lblPrpieteFaC.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteFaC.TabIndex = 137;
            this.lblPrpieteFaC.Text = "Aucune";
            // 
            // lblPrpieteFouet
            // 
            this.lblPrpieteFouet.AutoSize = true;
            this.lblPrpieteFouet.Location = new System.Drawing.Point(552, 27);
            this.lblPrpieteFouet.Name = "lblPrpieteFouet";
            this.lblPrpieteFouet.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteFouet.TabIndex = 136;
            this.lblPrpieteFouet.Text = "Aucune";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(552, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 13);
            this.label12.TabIndex = 135;
            this.label12.Text = "Propriété";
            // 
            // lblVleurFaC
            // 
            this.lblVleurFaC.AutoSize = true;
            this.lblVleurFaC.Location = new System.Drawing.Point(454, 52);
            this.lblVleurFaC.Name = "lblVleurFaC";
            this.lblVleurFaC.Size = new System.Drawing.Size(82, 13);
            this.lblVleurFaC.TabIndex = 127;
            this.lblVleurFaC.Text = "2 po, 9 pa, 5 pc";
            // 
            // lblVleurFouet
            // 
            this.lblVleurFouet.AutoSize = true;
            this.lblVleurFouet.Location = new System.Drawing.Point(454, 27);
            this.lblVleurFouet.Name = "lblVleurFouet";
            this.lblVleurFouet.Size = new System.Drawing.Size(82, 13);
            this.lblVleurFouet.TabIndex = 126;
            this.lblVleurFouet.Text = "1 po, 6 pa, 9 pc";
            // 
            // lblVleurChaines
            // 
            this.lblVleurChaines.AutoSize = true;
            this.lblVleurChaines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurChaines.Location = new System.Drawing.Point(454, 3);
            this.lblVleurChaines.Name = "lblVleurChaines";
            this.lblVleurChaines.Size = new System.Drawing.Size(37, 13);
            this.lblVleurChaines.TabIndex = 125;
            this.lblVleurChaines.Text = "Valeur";
            // 
            // lblPdsFouet
            // 
            this.lblPdsFouet.AutoSize = true;
            this.lblPdsFouet.Location = new System.Drawing.Point(128, 27);
            this.lblPdsFouet.Name = "lblPdsFouet";
            this.lblPdsFouet.Size = new System.Drawing.Size(40, 13);
            this.lblPdsFouet.TabIndex = 87;
            this.lblPdsFouet.Text = "0,13kg";
            // 
            // chkFaC
            // 
            this.chkFaC.AutoSize = true;
            this.chkFaC.Location = new System.Drawing.Point(13, 52);
            this.chkFaC.Name = "chkFaC";
            this.chkFaC.Size = new System.Drawing.Size(15, 14);
            this.chkFaC.TabIndex = 86;
            this.chkFaC.UseVisualStyleBackColor = true;
            this.chkFaC.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkFouet
            // 
            this.chkFouet.AutoSize = true;
            this.chkFouet.Location = new System.Drawing.Point(13, 27);
            this.chkFouet.Name = "chkFouet";
            this.chkFouet.Size = new System.Drawing.Size(15, 14);
            this.chkFouet.TabIndex = 85;
            this.chkFouet.UseVisualStyleBackColor = true;
            this.chkFouet.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomFaC
            // 
            this.lblNomFaC.AutoSize = true;
            this.lblNomFaC.Location = new System.Drawing.Point(34, 52);
            this.lblNomFaC.Name = "lblNomFaC";
            this.lblNomFaC.Size = new System.Drawing.Size(89, 13);
            this.lblNomFaC.TabIndex = 54;
            this.lblNomFaC.Text = "Faucille à chaîne";
            // 
            // lblPdsFaC
            // 
            this.lblPdsFaC.AutoSize = true;
            this.lblPdsFaC.Location = new System.Drawing.Point(128, 52);
            this.lblPdsFaC.Name = "lblPdsFaC";
            this.lblPdsFaC.Size = new System.Drawing.Size(34, 13);
            this.lblPdsFaC.TabIndex = 55;
            this.lblPdsFaC.Text = "0,9kg";
            // 
            // lblPrteFaC
            // 
            this.lblPrteFaC.AutoSize = true;
            this.lblPrteFaC.Location = new System.Drawing.Point(200, 52);
            this.lblPrteFaC.Name = "lblPrteFaC";
            this.lblPrteFaC.Size = new System.Drawing.Size(24, 13);
            this.lblPrteFaC.TabIndex = 56;
            this.lblPrteFaC.Text = "3 m";
            // 
            // nudFaC
            // 
            this.nudFaC.Location = new System.Drawing.Point(266, 50);
            this.nudFaC.Name = "nudFaC";
            this.nudFaC.Size = new System.Drawing.Size(41, 20);
            this.nudFaC.TabIndex = 57;
            this.nudFaC.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFaC.ValueChanged += new System.EventHandler(this.nudFaC_ValueChanged);
            // 
            // lblTpeFaC
            // 
            this.lblTpeFaC.AutoSize = true;
            this.lblTpeFaC.Location = new System.Drawing.Point(325, 52);
            this.lblTpeFaC.Name = "lblTpeFaC";
            this.lblTpeFaC.Size = new System.Drawing.Size(56, 13);
            this.lblTpeFaC.TabIndex = 58;
            this.lblTpeFaC.Text = "Tranchant";
            // 
            // lblDgtsFaC
            // 
            this.lblDgtsFaC.AutoSize = true;
            this.lblDgtsFaC.Location = new System.Drawing.Point(397, 52);
            this.lblDgtsFaC.Name = "lblDgtsFaC";
            this.lblDgtsFaC.Size = new System.Drawing.Size(31, 13);
            this.lblDgtsFaC.TabIndex = 59;
            this.lblDgtsFaC.Text = "1d10";
            // 
            // lblNomFouet
            // 
            this.lblNomFouet.AutoSize = true;
            this.lblNomFouet.Location = new System.Drawing.Point(34, 27);
            this.lblNomFouet.Name = "lblNomFouet";
            this.lblNomFouet.Size = new System.Drawing.Size(34, 13);
            this.lblNomFouet.TabIndex = 48;
            this.lblNomFouet.Text = "Fouet";
            // 
            // lblPrteFouet
            // 
            this.lblPrteFouet.AutoSize = true;
            this.lblPrteFouet.Location = new System.Drawing.Point(200, 27);
            this.lblPrteFouet.Name = "lblPrteFouet";
            this.lblPrteFouet.Size = new System.Drawing.Size(33, 13);
            this.lblPrteFouet.TabIndex = 50;
            this.lblPrteFouet.Text = "2.5 m";
            // 
            // nudFouet
            // 
            this.nudFouet.Location = new System.Drawing.Point(266, 25);
            this.nudFouet.Name = "nudFouet";
            this.nudFouet.Size = new System.Drawing.Size(41, 20);
            this.nudFouet.TabIndex = 51;
            this.nudFouet.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFouet.ValueChanged += new System.EventHandler(this.nudFouet_ValueChanged);
            // 
            // lblTpeFouet
            // 
            this.lblTpeFouet.AutoSize = true;
            this.lblTpeFouet.Location = new System.Drawing.Point(325, 27);
            this.lblTpeFouet.Name = "lblTpeFouet";
            this.lblTpeFouet.Size = new System.Drawing.Size(62, 13);
            this.lblTpeFouet.TabIndex = 52;
            this.lblTpeFouet.Text = "Contondant";
            // 
            // lblDgtsFouet
            // 
            this.lblDgtsFouet.AutoSize = true;
            this.lblDgtsFouet.Location = new System.Drawing.Point(397, 27);
            this.lblDgtsFouet.Name = "lblDgtsFouet";
            this.lblDgtsFouet.Size = new System.Drawing.Size(25, 13);
            this.lblDgtsFouet.TabIndex = 53;
            this.lblDgtsFouet.Text = "1d6";
            // 
            // lblNomChaines
            // 
            this.lblNomChaines.AutoSize = true;
            this.lblNomChaines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomChaines.Location = new System.Drawing.Point(34, 3);
            this.lblNomChaines.Name = "lblNomChaines";
            this.lblNomChaines.Size = new System.Drawing.Size(29, 13);
            this.lblNomChaines.TabIndex = 12;
            this.lblNomChaines.Text = "Nom";
            // 
            // lblPrteChaines
            // 
            this.lblPrteChaines.AutoSize = true;
            this.lblPrteChaines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrteChaines.Location = new System.Drawing.Point(200, 3);
            this.lblPrteChaines.Name = "lblPrteChaines";
            this.lblPrteChaines.Size = new System.Drawing.Size(38, 13);
            this.lblPrteChaines.TabIndex = 13;
            this.lblPrteChaines.Text = "Portée";
            // 
            // lblPdsChaines
            // 
            this.lblPdsChaines.AutoSize = true;
            this.lblPdsChaines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsChaines.Location = new System.Drawing.Point(128, 3);
            this.lblPdsChaines.Name = "lblPdsChaines";
            this.lblPdsChaines.Size = new System.Drawing.Size(33, 13);
            this.lblPdsChaines.TabIndex = 14;
            this.lblPdsChaines.Text = "Poids";
            // 
            // lblNbChaines
            // 
            this.lblNbChaines.AutoSize = true;
            this.lblNbChaines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbChaines.Location = new System.Drawing.Point(266, 3);
            this.lblNbChaines.Name = "lblNbChaines";
            this.lblNbChaines.Size = new System.Drawing.Size(44, 13);
            this.lblNbChaines.TabIndex = 15;
            this.lblNbChaines.Text = "Nombre";
            // 
            // lblTpeChaines
            // 
            this.lblTpeChaines.AutoSize = true;
            this.lblTpeChaines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTpeChaines.Location = new System.Drawing.Point(325, 3);
            this.lblTpeChaines.Name = "lblTpeChaines";
            this.lblTpeChaines.Size = new System.Drawing.Size(31, 13);
            this.lblTpeChaines.TabIndex = 16;
            this.lblTpeChaines.Text = "Type";
            // 
            // lblDgtsChaines
            // 
            this.lblDgtsChaines.AutoSize = true;
            this.lblDgtsChaines.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDgtsChaines.Location = new System.Drawing.Point(397, 3);
            this.lblDgtsChaines.Name = "lblDgtsChaines";
            this.lblDgtsChaines.Size = new System.Drawing.Size(41, 13);
            this.lblDgtsChaines.TabIndex = 17;
            this.lblDgtsChaines.Text = "Dégâts";
            // 
            // tpBatons
            // 
            this.tpBatons.AutoScroll = true;
            this.tpBatons.Controls.Add(this.lblDescBatons);
            this.tpBatons.Controls.Add(this.lblPrpieteSptreNeutre);
            this.tpBatons.Controls.Add(this.lblVleurSptreNeutre);
            this.tpBatons.Controls.Add(this.chkSptreNeutre);
            this.tpBatons.Controls.Add(this.lblPrteSptreNeutre);
            this.tpBatons.Controls.Add(this.lblEftsSptreNeutre);
            this.tpBatons.Controls.Add(this.lblNomSptreNeutre);
            this.tpBatons.Controls.Add(this.lblPdsSptreNeutre);
            this.tpBatons.Controls.Add(this.nudSptreNeutre);
            this.tpBatons.Controls.Add(this.lblTpeSptreNeutre);
            this.tpBatons.Controls.Add(this.lblDgtsSptreNeutre);
            this.tpBatons.Controls.Add(this.lblPrpieteBgteInfernale);
            this.tpBatons.Controls.Add(this.lblVleurBgteInfernale);
            this.tpBatons.Controls.Add(this.chkBgteInfernale);
            this.tpBatons.Controls.Add(this.lblPrteBgteInfernale);
            this.tpBatons.Controls.Add(this.lblEftsBgteInfernale);
            this.tpBatons.Controls.Add(this.lblNomBgteInfernale);
            this.tpBatons.Controls.Add(this.lblPdsBgteInfernale);
            this.tpBatons.Controls.Add(this.nudBgteInfernale);
            this.tpBatons.Controls.Add(this.lblTpeBgteInfernale);
            this.tpBatons.Controls.Add(this.lblDgtsBgteInfernale);
            this.tpBatons.Controls.Add(this.lblPrpieteCneLmiere);
            this.tpBatons.Controls.Add(this.lblVleurCneLmiere);
            this.tpBatons.Controls.Add(this.chkCneLmiere);
            this.tpBatons.Controls.Add(this.lblPrteCneLmiere);
            this.tpBatons.Controls.Add(this.lblEftsCneLmiere);
            this.tpBatons.Controls.Add(this.lblNomCneLmiere);
            this.tpBatons.Controls.Add(this.lblPdsCneLmiere);
            this.tpBatons.Controls.Add(this.nudCneLmiere);
            this.tpBatons.Controls.Add(this.lblTpeCneLmiere);
            this.tpBatons.Controls.Add(this.lblDgtsCneLmiere);
            this.tpBatons.Controls.Add(this.lblPrpieteBtonNture);
            this.tpBatons.Controls.Add(this.lblVleurBtonNture);
            this.tpBatons.Controls.Add(this.chkBtonNture);
            this.tpBatons.Controls.Add(this.lblPrteBtonNture);
            this.tpBatons.Controls.Add(this.lblEftsBtonNture);
            this.tpBatons.Controls.Add(this.lblNomBtonNture);
            this.tpBatons.Controls.Add(this.lblPdsBtonNture);
            this.tpBatons.Controls.Add(this.nudBtonNture);
            this.tpBatons.Controls.Add(this.lblTpeBtonNture);
            this.tpBatons.Controls.Add(this.lblDgtsBtonNture);
            this.tpBatons.Controls.Add(this.lblPrpieteScptreTerre);
            this.tpBatons.Controls.Add(this.lblVleurScptreTerre);
            this.tpBatons.Controls.Add(this.chkScptreTerre);
            this.tpBatons.Controls.Add(this.lblPrteScptreTerre);
            this.tpBatons.Controls.Add(this.lblEftsScptreTerre);
            this.tpBatons.Controls.Add(this.lblNomScptreTerre);
            this.tpBatons.Controls.Add(this.lblPdsScptreTerre);
            this.tpBatons.Controls.Add(this.nudScptreTerre);
            this.tpBatons.Controls.Add(this.lblTpeScptreTerre);
            this.tpBatons.Controls.Add(this.lblDgtsScptreTerre);
            this.tpBatons.Controls.Add(this.lblPrpieteBtonCelste);
            this.tpBatons.Controls.Add(this.lblVleurBtonCelste);
            this.tpBatons.Controls.Add(this.chkBtonCelste);
            this.tpBatons.Controls.Add(this.lblPrteBtonCelste);
            this.tpBatons.Controls.Add(this.lblEftsBtonCelste);
            this.tpBatons.Controls.Add(this.lblNomBtonCelste);
            this.tpBatons.Controls.Add(this.lblPdsBtonCelste);
            this.tpBatons.Controls.Add(this.nudBtonCelste);
            this.tpBatons.Controls.Add(this.lblTpeBtonCelste);
            this.tpBatons.Controls.Add(this.lblDgtsBtonCelste);
            this.tpBatons.Controls.Add(this.lblPrpieteBgteFeu);
            this.tpBatons.Controls.Add(this.lblVleurBgteFeu);
            this.tpBatons.Controls.Add(this.chkBgteFeu);
            this.tpBatons.Controls.Add(this.lblPrteBgteFeu);
            this.tpBatons.Controls.Add(this.lblEftsBgteFeu);
            this.tpBatons.Controls.Add(this.lblNomBgteFeu);
            this.tpBatons.Controls.Add(this.lblPdsBgteFeu);
            this.tpBatons.Controls.Add(this.nudBgteFeu);
            this.tpBatons.Controls.Add(this.lblTpeBgteFeu);
            this.tpBatons.Controls.Add(this.lblDgtsBgteFeu);
            this.tpBatons.Controls.Add(this.lblPrpieteCneAqua);
            this.tpBatons.Controls.Add(this.lblVleurCneAqua);
            this.tpBatons.Controls.Add(this.chkCneAqua);
            this.tpBatons.Controls.Add(this.lblPrteCneAqua);
            this.tpBatons.Controls.Add(this.lblEftsCneAqua);
            this.tpBatons.Controls.Add(this.lblNomCneAqua);
            this.tpBatons.Controls.Add(this.lblPdsCneAqua);
            this.tpBatons.Controls.Add(this.nudCneAqua);
            this.tpBatons.Controls.Add(this.lblTpeCneAqua);
            this.tpBatons.Controls.Add(this.lblDgtsCneAqua);
            this.tpBatons.Controls.Add(this.lblPrpieteSctre);
            this.tpBatons.Controls.Add(this.lblPrpieteBtonChne);
            this.tpBatons.Controls.Add(this.lblPrpieteBatons);
            this.tpBatons.Controls.Add(this.lblVleurSctre);
            this.tpBatons.Controls.Add(this.lblVleurBtonChne);
            this.tpBatons.Controls.Add(this.lblVleurBatons);
            this.tpBatons.Controls.Add(this.chkSctre);
            this.tpBatons.Controls.Add(this.lblPrteSctre);
            this.tpBatons.Controls.Add(this.lblPrteBtonChne);
            this.tpBatons.Controls.Add(this.lblPrteBton);
            this.tpBatons.Controls.Add(this.chkBtonChne);
            this.tpBatons.Controls.Add(this.lblEftsSctre);
            this.tpBatons.Controls.Add(this.lblNomSctre);
            this.tpBatons.Controls.Add(this.lblPdsSctre);
            this.tpBatons.Controls.Add(this.nudSctre);
            this.tpBatons.Controls.Add(this.lblTpeSctre);
            this.tpBatons.Controls.Add(this.lblDgtsSctre);
            this.tpBatons.Controls.Add(this.lblEftsBtonChne);
            this.tpBatons.Controls.Add(this.lblEftsBton);
            this.tpBatons.Controls.Add(this.lblNomBtonChne);
            this.tpBatons.Controls.Add(this.lblPdsBtonChne);
            this.tpBatons.Controls.Add(this.nudBtonChne);
            this.tpBatons.Controls.Add(this.lblTpeBtonChne);
            this.tpBatons.Controls.Add(this.lblDgtsBtonChne);
            this.tpBatons.Controls.Add(this.lblNomBton);
            this.tpBatons.Controls.Add(this.lblPdsBton);
            this.tpBatons.Controls.Add(this.lblNbBton);
            this.tpBatons.Controls.Add(this.lblTpeBton);
            this.tpBatons.Controls.Add(this.lblDgtsBton);
            this.tpBatons.Location = new System.Drawing.Point(4, 22);
            this.tpBatons.Name = "tpBatons";
            this.tpBatons.Size = new System.Drawing.Size(689, 272);
            this.tpBatons.TabIndex = 7;
            this.tpBatons.Text = "Bâtons";
            this.tpBatons.UseVisualStyleBackColor = true;
            // 
            // lblDescBatons
            // 
            this.lblDescBatons.AutoSize = true;
            this.lblDescBatons.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescBatons.Location = new System.Drawing.Point(10, 281);
            this.lblDescBatons.Name = "lblDescBatons";
            this.lblDescBatons.Size = new System.Drawing.Size(75, 13);
            this.lblDescBatons.TabIndex = 19;
            this.lblDescBatons.Text = "enrg = énergie";
            // 
            // lblPrpieteSptreNeutre
            // 
            this.lblPrpieteSptreNeutre.AutoSize = true;
            this.lblPrpieteSptreNeutre.Location = new System.Drawing.Point(661, 252);
            this.lblPrpieteSptreNeutre.Name = "lblPrpieteSptreNeutre";
            this.lblPrpieteSptreNeutre.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteSptreNeutre.TabIndex = 220;
            this.lblPrpieteSptreNeutre.Text = "Aucune";
            // 
            // lblVleurSptreNeutre
            // 
            this.lblVleurSptreNeutre.AutoSize = true;
            this.lblVleurSptreNeutre.Location = new System.Drawing.Point(552, 252);
            this.lblVleurSptreNeutre.Name = "lblVleurSptreNeutre";
            this.lblVleurSptreNeutre.Size = new System.Drawing.Size(82, 13);
            this.lblVleurSptreNeutre.TabIndex = 219;
            this.lblVleurSptreNeutre.Text = "2 po, 5 pa, 3 pc";
            // 
            // chkSptreNeutre
            // 
            this.chkSptreNeutre.AutoSize = true;
            this.chkSptreNeutre.Location = new System.Drawing.Point(13, 252);
            this.chkSptreNeutre.Name = "chkSptreNeutre";
            this.chkSptreNeutre.Size = new System.Drawing.Size(15, 14);
            this.chkSptreNeutre.TabIndex = 218;
            this.chkSptreNeutre.UseVisualStyleBackColor = true;
            this.chkSptreNeutre.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblPrteSptreNeutre
            // 
            this.lblPrteSptreNeutre.AutoSize = true;
            this.lblPrteSptreNeutre.Location = new System.Drawing.Point(200, 252);
            this.lblPrteSptreNeutre.Name = "lblPrteSptreNeutre";
            this.lblPrteSptreNeutre.Size = new System.Drawing.Size(36, 13);
            this.lblPrteSptreNeutre.TabIndex = 217;
            this.lblPrteSptreNeutre.Text = "60 cm";
            // 
            // lblEftsSptreNeutre
            // 
            this.lblEftsSptreNeutre.AutoSize = true;
            this.lblEftsSptreNeutre.Location = new System.Drawing.Point(454, 252);
            this.lblEftsSptreNeutre.Name = "lblEftsSptreNeutre";
            this.lblEftsSptreNeutre.Size = new System.Drawing.Size(93, 13);
            this.lblEftsSptreNeutre.TabIndex = 216;
            this.lblEftsSptreNeutre.Text = "-1 enrg sort neutre";
            // 
            // lblNomSptreNeutre
            // 
            this.lblNomSptreNeutre.AutoSize = true;
            this.lblNomSptreNeutre.Location = new System.Drawing.Point(34, 252);
            this.lblNomSptreNeutre.Name = "lblNomSptreNeutre";
            this.lblNomSptreNeutre.Size = new System.Drawing.Size(90, 13);
            this.lblNomSptreNeutre.TabIndex = 211;
            this.lblNomSptreNeutre.Text = "Sceptre neutralité";
            // 
            // lblPdsSptreNeutre
            // 
            this.lblPdsSptreNeutre.AutoSize = true;
            this.lblPdsSptreNeutre.Location = new System.Drawing.Point(128, 252);
            this.lblPdsSptreNeutre.Name = "lblPdsSptreNeutre";
            this.lblPdsSptreNeutre.Size = new System.Drawing.Size(40, 13);
            this.lblPdsSptreNeutre.TabIndex = 212;
            this.lblPdsSptreNeutre.Text = "0,70kg";
            // 
            // nudSptreNeutre
            // 
            this.nudSptreNeutre.Location = new System.Drawing.Point(266, 250);
            this.nudSptreNeutre.Name = "nudSptreNeutre";
            this.nudSptreNeutre.Size = new System.Drawing.Size(41, 20);
            this.nudSptreNeutre.TabIndex = 213;
            this.nudSptreNeutre.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSptreNeutre.ValueChanged += new System.EventHandler(this.nudSptreNeutre_ValueChanged);
            // 
            // lblTpeSptreNeutre
            // 
            this.lblTpeSptreNeutre.AutoSize = true;
            this.lblTpeSptreNeutre.Location = new System.Drawing.Point(325, 252);
            this.lblTpeSptreNeutre.Name = "lblTpeSptreNeutre";
            this.lblTpeSptreNeutre.Size = new System.Drawing.Size(62, 13);
            this.lblTpeSptreNeutre.TabIndex = 214;
            this.lblTpeSptreNeutre.Text = "Contondant";
            // 
            // lblDgtsSptreNeutre
            // 
            this.lblDgtsSptreNeutre.AutoSize = true;
            this.lblDgtsSptreNeutre.Location = new System.Drawing.Point(397, 252);
            this.lblDgtsSptreNeutre.Name = "lblDgtsSptreNeutre";
            this.lblDgtsSptreNeutre.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsSptreNeutre.TabIndex = 215;
            this.lblDgtsSptreNeutre.Text = "1";
            // 
            // lblPrpieteBgteInfernale
            // 
            this.lblPrpieteBgteInfernale.AutoSize = true;
            this.lblPrpieteBgteInfernale.Location = new System.Drawing.Point(661, 227);
            this.lblPrpieteBgteInfernale.Name = "lblPrpieteBgteInfernale";
            this.lblPrpieteBgteInfernale.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteBgteInfernale.TabIndex = 210;
            this.lblPrpieteBgteInfernale.Text = "Aucune";
            // 
            // lblVleurBgteInfernale
            // 
            this.lblVleurBgteInfernale.AutoSize = true;
            this.lblVleurBgteInfernale.Location = new System.Drawing.Point(552, 227);
            this.lblVleurBgteInfernale.Name = "lblVleurBgteInfernale";
            this.lblVleurBgteInfernale.Size = new System.Drawing.Size(82, 13);
            this.lblVleurBgteInfernale.TabIndex = 209;
            this.lblVleurBgteInfernale.Text = "2 po, 1 pa, 8 pc";
            // 
            // chkBgteInfernale
            // 
            this.chkBgteInfernale.AutoSize = true;
            this.chkBgteInfernale.Location = new System.Drawing.Point(13, 227);
            this.chkBgteInfernale.Name = "chkBgteInfernale";
            this.chkBgteInfernale.Size = new System.Drawing.Size(15, 14);
            this.chkBgteInfernale.TabIndex = 208;
            this.chkBgteInfernale.UseVisualStyleBackColor = true;
            this.chkBgteInfernale.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblPrteBgteInfernale
            // 
            this.lblPrteBgteInfernale.AutoSize = true;
            this.lblPrteBgteInfernale.Location = new System.Drawing.Point(200, 227);
            this.lblPrteBgteInfernale.Name = "lblPrteBgteInfernale";
            this.lblPrteBgteInfernale.Size = new System.Drawing.Size(36, 13);
            this.lblPrteBgteInfernale.TabIndex = 207;
            this.lblPrteBgteInfernale.Text = "40 cm";
            // 
            // lblEftsBgteInfernale
            // 
            this.lblEftsBgteInfernale.AutoSize = true;
            this.lblEftsBgteInfernale.Location = new System.Drawing.Point(454, 227);
            this.lblEftsBgteInfernale.Name = "lblEftsBgteInfernale";
            this.lblEftsBgteInfernale.Size = new System.Drawing.Size(95, 13);
            this.lblEftsBgteInfernale.TabIndex = 206;
            this.lblEftsBgteInfernale.Text = "-1 enrg sort démon";
            // 
            // lblNomBgteInfernale
            // 
            this.lblNomBgteInfernale.AutoSize = true;
            this.lblNomBgteInfernale.Location = new System.Drawing.Point(34, 227);
            this.lblNomBgteInfernale.Name = "lblNomBgteInfernale";
            this.lblNomBgteInfernale.Size = new System.Drawing.Size(93, 13);
            this.lblNomBgteInfernale.TabIndex = 201;
            this.lblNomBgteInfernale.Text = "Baguette infernale";
            // 
            // lblPdsBgteInfernale
            // 
            this.lblPdsBgteInfernale.AutoSize = true;
            this.lblPdsBgteInfernale.Location = new System.Drawing.Point(128, 227);
            this.lblPdsBgteInfernale.Name = "lblPdsBgteInfernale";
            this.lblPdsBgteInfernale.Size = new System.Drawing.Size(40, 13);
            this.lblPdsBgteInfernale.TabIndex = 202;
            this.lblPdsBgteInfernale.Text = "0,37kg";
            // 
            // nudBgteInfernale
            // 
            this.nudBgteInfernale.Location = new System.Drawing.Point(266, 225);
            this.nudBgteInfernale.Name = "nudBgteInfernale";
            this.nudBgteInfernale.Size = new System.Drawing.Size(41, 20);
            this.nudBgteInfernale.TabIndex = 203;
            this.nudBgteInfernale.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBgteInfernale.ValueChanged += new System.EventHandler(this.nudBgteInfernale_ValueChanged);
            // 
            // lblTpeBgteInfernale
            // 
            this.lblTpeBgteInfernale.AutoSize = true;
            this.lblTpeBgteInfernale.Location = new System.Drawing.Point(325, 227);
            this.lblTpeBgteInfernale.Name = "lblTpeBgteInfernale";
            this.lblTpeBgteInfernale.Size = new System.Drawing.Size(50, 13);
            this.lblTpeBgteInfernale.TabIndex = 204;
            this.lblTpeBgteInfernale.Text = "Perforant";
            // 
            // lblDgtsBgteInfernale
            // 
            this.lblDgtsBgteInfernale.AutoSize = true;
            this.lblDgtsBgteInfernale.Location = new System.Drawing.Point(397, 227);
            this.lblDgtsBgteInfernale.Name = "lblDgtsBgteInfernale";
            this.lblDgtsBgteInfernale.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsBgteInfernale.TabIndex = 205;
            this.lblDgtsBgteInfernale.Text = "1";
            // 
            // lblPrpieteCneLmiere
            // 
            this.lblPrpieteCneLmiere.AutoSize = true;
            this.lblPrpieteCneLmiere.Location = new System.Drawing.Point(661, 203);
            this.lblPrpieteCneLmiere.Name = "lblPrpieteCneLmiere";
            this.lblPrpieteCneLmiere.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCneLmiere.TabIndex = 200;
            this.lblPrpieteCneLmiere.Text = "Aucune";
            // 
            // lblVleurCneLmiere
            // 
            this.lblVleurCneLmiere.AutoSize = true;
            this.lblVleurCneLmiere.Location = new System.Drawing.Point(552, 202);
            this.lblVleurCneLmiere.Name = "lblVleurCneLmiere";
            this.lblVleurCneLmiere.Size = new System.Drawing.Size(82, 13);
            this.lblVleurCneLmiere.TabIndex = 199;
            this.lblVleurCneLmiere.Text = "3 po, 5 pa, 3 pc";
            // 
            // chkCneLmiere
            // 
            this.chkCneLmiere.AutoSize = true;
            this.chkCneLmiere.Location = new System.Drawing.Point(13, 202);
            this.chkCneLmiere.Name = "chkCneLmiere";
            this.chkCneLmiere.Size = new System.Drawing.Size(15, 14);
            this.chkCneLmiere.TabIndex = 198;
            this.chkCneLmiere.UseVisualStyleBackColor = true;
            this.chkCneLmiere.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblPrteCneLmiere
            // 
            this.lblPrteCneLmiere.AutoSize = true;
            this.lblPrteCneLmiere.Location = new System.Drawing.Point(200, 202);
            this.lblPrteCneLmiere.Name = "lblPrteCneLmiere";
            this.lblPrteCneLmiere.Size = new System.Drawing.Size(36, 13);
            this.lblPrteCneLmiere.TabIndex = 197;
            this.lblPrteCneLmiere.Text = "65 cm";
            // 
            // lblEftsCneLmiere
            // 
            this.lblEftsCneLmiere.AutoSize = true;
            this.lblEftsCneLmiere.Location = new System.Drawing.Point(454, 202);
            this.lblEftsCneLmiere.Name = "lblEftsCneLmiere";
            this.lblEftsCneLmiere.Size = new System.Drawing.Size(85, 13);
            this.lblEftsCneLmiere.TabIndex = 196;
            this.lblEftsCneLmiere.Text = "-1 enrg sort divin";
            // 
            // lblNomCneLmiere
            // 
            this.lblNomCneLmiere.AutoSize = true;
            this.lblNomCneLmiere.Location = new System.Drawing.Point(34, 202);
            this.lblNomCneLmiere.Name = "lblNomCneLmiere";
            this.lblNomCneLmiere.Size = new System.Drawing.Size(89, 13);
            this.lblNomCneLmiere.TabIndex = 191;
            this.lblNomCneLmiere.Text = "Canne de lumière";
            // 
            // lblPdsCneLmiere
            // 
            this.lblPdsCneLmiere.AutoSize = true;
            this.lblPdsCneLmiere.Location = new System.Drawing.Point(128, 202);
            this.lblPdsCneLmiere.Name = "lblPdsCneLmiere";
            this.lblPdsCneLmiere.Size = new System.Drawing.Size(40, 13);
            this.lblPdsCneLmiere.TabIndex = 192;
            this.lblPdsCneLmiere.Text = "0,65kg";
            // 
            // nudCneLmiere
            // 
            this.nudCneLmiere.Location = new System.Drawing.Point(266, 200);
            this.nudCneLmiere.Name = "nudCneLmiere";
            this.nudCneLmiere.Size = new System.Drawing.Size(41, 20);
            this.nudCneLmiere.TabIndex = 193;
            this.nudCneLmiere.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCneLmiere.ValueChanged += new System.EventHandler(this.nudCneLmiere_ValueChanged);
            // 
            // lblTpeCneLmiere
            // 
            this.lblTpeCneLmiere.AutoSize = true;
            this.lblTpeCneLmiere.Location = new System.Drawing.Point(325, 202);
            this.lblTpeCneLmiere.Name = "lblTpeCneLmiere";
            this.lblTpeCneLmiere.Size = new System.Drawing.Size(62, 13);
            this.lblTpeCneLmiere.TabIndex = 194;
            this.lblTpeCneLmiere.Text = "Contondant";
            // 
            // lblDgtsCneLmiere
            // 
            this.lblDgtsCneLmiere.AutoSize = true;
            this.lblDgtsCneLmiere.Location = new System.Drawing.Point(397, 202);
            this.lblDgtsCneLmiere.Name = "lblDgtsCneLmiere";
            this.lblDgtsCneLmiere.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsCneLmiere.TabIndex = 195;
            this.lblDgtsCneLmiere.Text = "1";
            // 
            // lblPrpieteBtonNture
            // 
            this.lblPrpieteBtonNture.AutoSize = true;
            this.lblPrpieteBtonNture.Location = new System.Drawing.Point(661, 177);
            this.lblPrpieteBtonNture.Name = "lblPrpieteBtonNture";
            this.lblPrpieteBtonNture.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteBtonNture.TabIndex = 190;
            this.lblPrpieteBtonNture.Text = "Aucune";
            // 
            // lblVleurBtonNture
            // 
            this.lblVleurBtonNture.AutoSize = true;
            this.lblVleurBtonNture.Location = new System.Drawing.Point(552, 177);
            this.lblVleurBtonNture.Name = "lblVleurBtonNture";
            this.lblVleurBtonNture.Size = new System.Drawing.Size(82, 13);
            this.lblVleurBtonNture.TabIndex = 189;
            this.lblVleurBtonNture.Text = "2 po, 9 pa, 6 pc";
            // 
            // chkBtonNture
            // 
            this.chkBtonNture.AutoSize = true;
            this.chkBtonNture.Location = new System.Drawing.Point(13, 177);
            this.chkBtonNture.Name = "chkBtonNture";
            this.chkBtonNture.Size = new System.Drawing.Size(15, 14);
            this.chkBtonNture.TabIndex = 188;
            this.chkBtonNture.UseVisualStyleBackColor = true;
            this.chkBtonNture.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblPrteBtonNture
            // 
            this.lblPrteBtonNture.AutoSize = true;
            this.lblPrteBtonNture.Location = new System.Drawing.Point(200, 177);
            this.lblPrteBtonNture.Name = "lblPrteBtonNture";
            this.lblPrteBtonNture.Size = new System.Drawing.Size(36, 13);
            this.lblPrteBtonNture.TabIndex = 187;
            this.lblPrteBtonNture.Text = "65 cm";
            // 
            // lblEftsBtonNture
            // 
            this.lblEftsBtonNture.AutoSize = true;
            this.lblEftsBtonNture.Location = new System.Drawing.Point(454, 177);
            this.lblEftsBtonNture.Name = "lblEftsBtonNture";
            this.lblEftsBtonNture.Size = new System.Drawing.Size(93, 13);
            this.lblEftsBtonNture.TabIndex = 186;
            this.lblEftsBtonNture.Text = "-1 enrg sort nature";
            // 
            // lblNomBtonNture
            // 
            this.lblNomBtonNture.AutoSize = true;
            this.lblNomBtonNture.Location = new System.Drawing.Point(34, 177);
            this.lblNomBtonNture.Name = "lblNomBtonNture";
            this.lblNomBtonNture.Size = new System.Drawing.Size(87, 13);
            this.lblNomBtonNture.TabIndex = 181;
            this.lblNomBtonNture.Text = "Bâton des sylves";
            // 
            // lblPdsBtonNture
            // 
            this.lblPdsBtonNture.AutoSize = true;
            this.lblPdsBtonNture.Location = new System.Drawing.Point(128, 177);
            this.lblPdsBtonNture.Name = "lblPdsBtonNture";
            this.lblPdsBtonNture.Size = new System.Drawing.Size(40, 13);
            this.lblPdsBtonNture.TabIndex = 182;
            this.lblPdsBtonNture.Text = "0,40kg";
            // 
            // nudBtonNture
            // 
            this.nudBtonNture.Location = new System.Drawing.Point(266, 175);
            this.nudBtonNture.Name = "nudBtonNture";
            this.nudBtonNture.Size = new System.Drawing.Size(41, 20);
            this.nudBtonNture.TabIndex = 183;
            this.nudBtonNture.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBtonNture.ValueChanged += new System.EventHandler(this.nudBtonNture_ValueChanged);
            // 
            // lblTpeBtonNture
            // 
            this.lblTpeBtonNture.AutoSize = true;
            this.lblTpeBtonNture.Location = new System.Drawing.Point(325, 177);
            this.lblTpeBtonNture.Name = "lblTpeBtonNture";
            this.lblTpeBtonNture.Size = new System.Drawing.Size(62, 13);
            this.lblTpeBtonNture.TabIndex = 184;
            this.lblTpeBtonNture.Text = "Contondant";
            // 
            // lblDgtsBtonNture
            // 
            this.lblDgtsBtonNture.AutoSize = true;
            this.lblDgtsBtonNture.Location = new System.Drawing.Point(397, 177);
            this.lblDgtsBtonNture.Name = "lblDgtsBtonNture";
            this.lblDgtsBtonNture.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsBtonNture.TabIndex = 185;
            this.lblDgtsBtonNture.Text = "1";
            // 
            // lblPrpieteScptreTerre
            // 
            this.lblPrpieteScptreTerre.AutoSize = true;
            this.lblPrpieteScptreTerre.Location = new System.Drawing.Point(661, 152);
            this.lblPrpieteScptreTerre.Name = "lblPrpieteScptreTerre";
            this.lblPrpieteScptreTerre.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteScptreTerre.TabIndex = 180;
            this.lblPrpieteScptreTerre.Text = "Aucune";
            // 
            // lblVleurScptreTerre
            // 
            this.lblVleurScptreTerre.AutoSize = true;
            this.lblVleurScptreTerre.Location = new System.Drawing.Point(552, 152);
            this.lblVleurScptreTerre.Name = "lblVleurScptreTerre";
            this.lblVleurScptreTerre.Size = new System.Drawing.Size(82, 13);
            this.lblVleurScptreTerre.TabIndex = 179;
            this.lblVleurScptreTerre.Text = "2 po, 2 pa, 3 pc";
            // 
            // chkScptreTerre
            // 
            this.chkScptreTerre.AutoSize = true;
            this.chkScptreTerre.Location = new System.Drawing.Point(13, 152);
            this.chkScptreTerre.Name = "chkScptreTerre";
            this.chkScptreTerre.Size = new System.Drawing.Size(15, 14);
            this.chkScptreTerre.TabIndex = 178;
            this.chkScptreTerre.UseVisualStyleBackColor = true;
            this.chkScptreTerre.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblPrteScptreTerre
            // 
            this.lblPrteScptreTerre.AutoSize = true;
            this.lblPrteScptreTerre.Location = new System.Drawing.Point(200, 152);
            this.lblPrteScptreTerre.Name = "lblPrteScptreTerre";
            this.lblPrteScptreTerre.Size = new System.Drawing.Size(36, 13);
            this.lblPrteScptreTerre.TabIndex = 177;
            this.lblPrteScptreTerre.Text = "70 cm";
            // 
            // lblEftsScptreTerre
            // 
            this.lblEftsScptreTerre.AutoSize = true;
            this.lblEftsScptreTerre.Location = new System.Drawing.Point(454, 152);
            this.lblEftsScptreTerre.Name = "lblEftsScptreTerre";
            this.lblEftsScptreTerre.Size = new System.Drawing.Size(84, 13);
            this.lblEftsScptreTerre.TabIndex = 176;
            this.lblEftsScptreTerre.Text = "-1 enrg sort terre";
            // 
            // lblNomScptreTerre
            // 
            this.lblNomScptreTerre.AutoSize = true;
            this.lblNomScptreTerre.Location = new System.Drawing.Point(34, 152);
            this.lblNomScptreTerre.Name = "lblNomScptreTerre";
            this.lblNomScptreTerre.Size = new System.Drawing.Size(85, 13);
            this.lblNomScptreTerre.TabIndex = 171;
            this.lblNomScptreTerre.Text = "Sceptre terrestre";
            // 
            // lblPdsScptreTerre
            // 
            this.lblPdsScptreTerre.AutoSize = true;
            this.lblPdsScptreTerre.Location = new System.Drawing.Point(128, 152);
            this.lblPdsScptreTerre.Name = "lblPdsScptreTerre";
            this.lblPdsScptreTerre.Size = new System.Drawing.Size(40, 13);
            this.lblPdsScptreTerre.TabIndex = 172;
            this.lblPdsScptreTerre.Text = "0,55kg";
            // 
            // nudScptreTerre
            // 
            this.nudScptreTerre.Location = new System.Drawing.Point(266, 150);
            this.nudScptreTerre.Name = "nudScptreTerre";
            this.nudScptreTerre.Size = new System.Drawing.Size(41, 20);
            this.nudScptreTerre.TabIndex = 173;
            this.nudScptreTerre.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudScptreTerre.ValueChanged += new System.EventHandler(this.nudScptreTerre_ValueChanged);
            // 
            // lblTpeScptreTerre
            // 
            this.lblTpeScptreTerre.AutoSize = true;
            this.lblTpeScptreTerre.Location = new System.Drawing.Point(325, 152);
            this.lblTpeScptreTerre.Name = "lblTpeScptreTerre";
            this.lblTpeScptreTerre.Size = new System.Drawing.Size(62, 13);
            this.lblTpeScptreTerre.TabIndex = 174;
            this.lblTpeScptreTerre.Text = "Contondant";
            // 
            // lblDgtsScptreTerre
            // 
            this.lblDgtsScptreTerre.AutoSize = true;
            this.lblDgtsScptreTerre.Location = new System.Drawing.Point(397, 152);
            this.lblDgtsScptreTerre.Name = "lblDgtsScptreTerre";
            this.lblDgtsScptreTerre.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsScptreTerre.TabIndex = 175;
            this.lblDgtsScptreTerre.Text = "1";
            // 
            // lblPrpieteBtonCelste
            // 
            this.lblPrpieteBtonCelste.AutoSize = true;
            this.lblPrpieteBtonCelste.Location = new System.Drawing.Point(661, 127);
            this.lblPrpieteBtonCelste.Name = "lblPrpieteBtonCelste";
            this.lblPrpieteBtonCelste.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteBtonCelste.TabIndex = 170;
            this.lblPrpieteBtonCelste.Text = "Aucune";
            // 
            // lblVleurBtonCelste
            // 
            this.lblVleurBtonCelste.AutoSize = true;
            this.lblVleurBtonCelste.Location = new System.Drawing.Point(552, 127);
            this.lblVleurBtonCelste.Name = "lblVleurBtonCelste";
            this.lblVleurBtonCelste.Size = new System.Drawing.Size(82, 13);
            this.lblVleurBtonCelste.TabIndex = 169;
            this.lblVleurBtonCelste.Text = "2 po, 5 pa, 6 pc";
            // 
            // chkBtonCelste
            // 
            this.chkBtonCelste.AutoSize = true;
            this.chkBtonCelste.Location = new System.Drawing.Point(13, 127);
            this.chkBtonCelste.Name = "chkBtonCelste";
            this.chkBtonCelste.Size = new System.Drawing.Size(15, 14);
            this.chkBtonCelste.TabIndex = 168;
            this.chkBtonCelste.UseVisualStyleBackColor = true;
            this.chkBtonCelste.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblPrteBtonCelste
            // 
            this.lblPrteBtonCelste.AutoSize = true;
            this.lblPrteBtonCelste.Location = new System.Drawing.Point(200, 127);
            this.lblPrteBtonCelste.Name = "lblPrteBtonCelste";
            this.lblPrteBtonCelste.Size = new System.Drawing.Size(36, 13);
            this.lblPrteBtonCelste.TabIndex = 167;
            this.lblPrteBtonCelste.Text = "60 cm";
            // 
            // lblEftsBtonCelste
            // 
            this.lblEftsBtonCelste.AutoSize = true;
            this.lblEftsBtonCelste.Location = new System.Drawing.Point(454, 127);
            this.lblEftsBtonCelste.Name = "lblEftsBtonCelste";
            this.lblEftsBtonCelste.Size = new System.Drawing.Size(97, 13);
            this.lblEftsBtonCelste.TabIndex = 166;
            this.lblEftsBtonCelste.Text = "-1 enrg sort céleste";
            // 
            // lblNomBtonCelste
            // 
            this.lblNomBtonCelste.AutoSize = true;
            this.lblNomBtonCelste.Location = new System.Drawing.Point(34, 127);
            this.lblNomBtonCelste.Name = "lblNomBtonCelste";
            this.lblNomBtonCelste.Size = new System.Drawing.Size(72, 13);
            this.lblNomBtonCelste.TabIndex = 161;
            this.lblNomBtonCelste.Text = "Bâton céleste";
            // 
            // lblPdsBtonCelste
            // 
            this.lblPdsBtonCelste.AutoSize = true;
            this.lblPdsBtonCelste.Location = new System.Drawing.Point(128, 127);
            this.lblPdsBtonCelste.Name = "lblPdsBtonCelste";
            this.lblPdsBtonCelste.Size = new System.Drawing.Size(40, 13);
            this.lblPdsBtonCelste.TabIndex = 162;
            this.lblPdsBtonCelste.Text = "0,25kg";
            // 
            // nudBtonCelste
            // 
            this.nudBtonCelste.Location = new System.Drawing.Point(266, 125);
            this.nudBtonCelste.Name = "nudBtonCelste";
            this.nudBtonCelste.Size = new System.Drawing.Size(41, 20);
            this.nudBtonCelste.TabIndex = 163;
            this.nudBtonCelste.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBtonCelste.ValueChanged += new System.EventHandler(this.nudBtonCelste_ValueChanged);
            // 
            // lblTpeBtonCelste
            // 
            this.lblTpeBtonCelste.AutoSize = true;
            this.lblTpeBtonCelste.Location = new System.Drawing.Point(325, 127);
            this.lblTpeBtonCelste.Name = "lblTpeBtonCelste";
            this.lblTpeBtonCelste.Size = new System.Drawing.Size(62, 13);
            this.lblTpeBtonCelste.TabIndex = 164;
            this.lblTpeBtonCelste.Text = "Contondant";
            // 
            // lblDgtsBtonCelste
            // 
            this.lblDgtsBtonCelste.AutoSize = true;
            this.lblDgtsBtonCelste.Location = new System.Drawing.Point(397, 128);
            this.lblDgtsBtonCelste.Name = "lblDgtsBtonCelste";
            this.lblDgtsBtonCelste.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsBtonCelste.TabIndex = 165;
            this.lblDgtsBtonCelste.Text = "1";
            // 
            // lblPrpieteBgteFeu
            // 
            this.lblPrpieteBgteFeu.AutoSize = true;
            this.lblPrpieteBgteFeu.Location = new System.Drawing.Point(661, 102);
            this.lblPrpieteBgteFeu.Name = "lblPrpieteBgteFeu";
            this.lblPrpieteBgteFeu.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteBgteFeu.TabIndex = 160;
            this.lblPrpieteBgteFeu.Text = "Aucune";
            // 
            // lblVleurBgteFeu
            // 
            this.lblVleurBgteFeu.AutoSize = true;
            this.lblVleurBgteFeu.Location = new System.Drawing.Point(552, 102);
            this.lblVleurBgteFeu.Name = "lblVleurBgteFeu";
            this.lblVleurBgteFeu.Size = new System.Drawing.Size(55, 13);
            this.lblVleurBgteFeu.TabIndex = 159;
            this.lblVleurBgteFeu.Text = "2 po, 3 pc";
            // 
            // chkBgteFeu
            // 
            this.chkBgteFeu.AutoSize = true;
            this.chkBgteFeu.Location = new System.Drawing.Point(13, 102);
            this.chkBgteFeu.Name = "chkBgteFeu";
            this.chkBgteFeu.Size = new System.Drawing.Size(15, 14);
            this.chkBgteFeu.TabIndex = 158;
            this.chkBgteFeu.UseVisualStyleBackColor = true;
            this.chkBgteFeu.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblPrteBgteFeu
            // 
            this.lblPrteBgteFeu.AutoSize = true;
            this.lblPrteBgteFeu.Location = new System.Drawing.Point(200, 102);
            this.lblPrteBgteFeu.Name = "lblPrteBgteFeu";
            this.lblPrteBgteFeu.Size = new System.Drawing.Size(36, 13);
            this.lblPrteBgteFeu.TabIndex = 157;
            this.lblPrteBgteFeu.Text = "35 cm";
            // 
            // lblEftsBgteFeu
            // 
            this.lblEftsBgteFeu.AutoSize = true;
            this.lblEftsBgteFeu.Location = new System.Drawing.Point(454, 102);
            this.lblEftsBgteFeu.Name = "lblEftsBgteFeu";
            this.lblEftsBgteFeu.Size = new System.Drawing.Size(84, 13);
            this.lblEftsBgteFeu.TabIndex = 156;
            this.lblEftsBgteFeu.Text = "-1 enrg sort ignis";
            // 
            // lblNomBgteFeu
            // 
            this.lblNomBgteFeu.AutoSize = true;
            this.lblNomBgteFeu.Location = new System.Drawing.Point(34, 102);
            this.lblNomBgteFeu.Name = "lblNomBgteFeu";
            this.lblNomBgteFeu.Size = new System.Drawing.Size(83, 13);
            this.lblNomBgteFeu.TabIndex = 151;
            this.lblNomBgteFeu.Text = "Baguette de feu";
            // 
            // lblPdsBgteFeu
            // 
            this.lblPdsBgteFeu.AutoSize = true;
            this.lblPdsBgteFeu.Location = new System.Drawing.Point(128, 102);
            this.lblPdsBgteFeu.Name = "lblPdsBgteFeu";
            this.lblPdsBgteFeu.Size = new System.Drawing.Size(40, 13);
            this.lblPdsBgteFeu.TabIndex = 152;
            this.lblPdsBgteFeu.Text = "0,35kg";
            // 
            // nudBgteFeu
            // 
            this.nudBgteFeu.Location = new System.Drawing.Point(266, 100);
            this.nudBgteFeu.Name = "nudBgteFeu";
            this.nudBgteFeu.Size = new System.Drawing.Size(41, 20);
            this.nudBgteFeu.TabIndex = 153;
            this.nudBgteFeu.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBgteFeu.ValueChanged += new System.EventHandler(this.nudBgteFeu_ValueChanged);
            // 
            // lblTpeBgteFeu
            // 
            this.lblTpeBgteFeu.AutoSize = true;
            this.lblTpeBgteFeu.Location = new System.Drawing.Point(325, 102);
            this.lblTpeBgteFeu.Name = "lblTpeBgteFeu";
            this.lblTpeBgteFeu.Size = new System.Drawing.Size(50, 13);
            this.lblTpeBgteFeu.TabIndex = 154;
            this.lblTpeBgteFeu.Text = "Perforant";
            // 
            // lblDgtsBgteFeu
            // 
            this.lblDgtsBgteFeu.AutoSize = true;
            this.lblDgtsBgteFeu.Location = new System.Drawing.Point(397, 102);
            this.lblDgtsBgteFeu.Name = "lblDgtsBgteFeu";
            this.lblDgtsBgteFeu.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsBgteFeu.TabIndex = 155;
            this.lblDgtsBgteFeu.Text = "1";
            // 
            // lblPrpieteCneAqua
            // 
            this.lblPrpieteCneAqua.AutoSize = true;
            this.lblPrpieteCneAqua.Location = new System.Drawing.Point(661, 77);
            this.lblPrpieteCneAqua.Name = "lblPrpieteCneAqua";
            this.lblPrpieteCneAqua.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCneAqua.TabIndex = 150;
            this.lblPrpieteCneAqua.Text = "Aucune";
            // 
            // lblVleurCneAqua
            // 
            this.lblVleurCneAqua.AutoSize = true;
            this.lblVleurCneAqua.Location = new System.Drawing.Point(552, 77);
            this.lblVleurCneAqua.Name = "lblVleurCneAqua";
            this.lblVleurCneAqua.Size = new System.Drawing.Size(55, 13);
            this.lblVleurCneAqua.TabIndex = 149;
            this.lblVleurCneAqua.Text = "2 po, 2 pa";
            // 
            // chkCneAqua
            // 
            this.chkCneAqua.AutoSize = true;
            this.chkCneAqua.Location = new System.Drawing.Point(13, 77);
            this.chkCneAqua.Name = "chkCneAqua";
            this.chkCneAqua.Size = new System.Drawing.Size(15, 14);
            this.chkCneAqua.TabIndex = 148;
            this.chkCneAqua.UseVisualStyleBackColor = true;
            this.chkCneAqua.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblPrteCneAqua
            // 
            this.lblPrteCneAqua.AutoSize = true;
            this.lblPrteCneAqua.Location = new System.Drawing.Point(200, 77);
            this.lblPrteCneAqua.Name = "lblPrteCneAqua";
            this.lblPrteCneAqua.Size = new System.Drawing.Size(36, 13);
            this.lblPrteCneAqua.TabIndex = 147;
            this.lblPrteCneAqua.Text = "75 cm";
            // 
            // lblEftsCneAqua
            // 
            this.lblEftsCneAqua.AutoSize = true;
            this.lblEftsCneAqua.Location = new System.Drawing.Point(454, 77);
            this.lblEftsCneAqua.Name = "lblEftsCneAqua";
            this.lblEftsCneAqua.Size = new System.Drawing.Size(87, 13);
            this.lblEftsCneAqua.TabIndex = 146;
            this.lblEftsCneAqua.Text = "-1 enrg sort aqua";
            // 
            // lblNomCneAqua
            // 
            this.lblNomCneAqua.AutoSize = true;
            this.lblNomCneAqua.Location = new System.Drawing.Point(34, 77);
            this.lblNomCneAqua.Name = "lblNomCneAqua";
            this.lblNomCneAqua.Size = new System.Drawing.Size(89, 13);
            this.lblNomCneAqua.TabIndex = 141;
            this.lblNomCneAqua.Text = "Canne Aquatique";
            // 
            // lblPdsCneAqua
            // 
            this.lblPdsCneAqua.AutoSize = true;
            this.lblPdsCneAqua.Location = new System.Drawing.Point(128, 77);
            this.lblPdsCneAqua.Name = "lblPdsCneAqua";
            this.lblPdsCneAqua.Size = new System.Drawing.Size(40, 13);
            this.lblPdsCneAqua.TabIndex = 142;
            this.lblPdsCneAqua.Text = "0,45kg";
            // 
            // nudCneAqua
            // 
            this.nudCneAqua.Location = new System.Drawing.Point(266, 75);
            this.nudCneAqua.Name = "nudCneAqua";
            this.nudCneAqua.Size = new System.Drawing.Size(41, 20);
            this.nudCneAqua.TabIndex = 143;
            this.nudCneAqua.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCneAqua.ValueChanged += new System.EventHandler(this.nudCneAqua_ValueChanged);
            // 
            // lblTpeCneAqua
            // 
            this.lblTpeCneAqua.AutoSize = true;
            this.lblTpeCneAqua.Location = new System.Drawing.Point(325, 77);
            this.lblTpeCneAqua.Name = "lblTpeCneAqua";
            this.lblTpeCneAqua.Size = new System.Drawing.Size(62, 13);
            this.lblTpeCneAqua.TabIndex = 144;
            this.lblTpeCneAqua.Text = "Contondant";
            // 
            // lblDgtsCneAqua
            // 
            this.lblDgtsCneAqua.AutoSize = true;
            this.lblDgtsCneAqua.Location = new System.Drawing.Point(397, 77);
            this.lblDgtsCneAqua.Name = "lblDgtsCneAqua";
            this.lblDgtsCneAqua.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsCneAqua.TabIndex = 145;
            this.lblDgtsCneAqua.Text = "1";
            // 
            // lblPrpieteSctre
            // 
            this.lblPrpieteSctre.AutoSize = true;
            this.lblPrpieteSctre.Location = new System.Drawing.Point(661, 52);
            this.lblPrpieteSctre.Name = "lblPrpieteSctre";
            this.lblPrpieteSctre.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteSctre.TabIndex = 140;
            this.lblPrpieteSctre.Text = "Aucune";
            // 
            // lblPrpieteBtonChne
            // 
            this.lblPrpieteBtonChne.AutoSize = true;
            this.lblPrpieteBtonChne.Location = new System.Drawing.Point(661, 27);
            this.lblPrpieteBtonChne.Name = "lblPrpieteBtonChne";
            this.lblPrpieteBtonChne.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteBtonChne.TabIndex = 139;
            this.lblPrpieteBtonChne.Text = "Aucune";
            // 
            // lblPrpieteBatons
            // 
            this.lblPrpieteBatons.AutoSize = true;
            this.lblPrpieteBatons.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteBatons.Location = new System.Drawing.Point(661, 3);
            this.lblPrpieteBatons.Name = "lblPrpieteBatons";
            this.lblPrpieteBatons.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteBatons.TabIndex = 138;
            this.lblPrpieteBatons.Text = "Propriété";
            // 
            // lblVleurSctre
            // 
            this.lblVleurSctre.AutoSize = true;
            this.lblVleurSctre.Location = new System.Drawing.Point(552, 52);
            this.lblVleurSctre.Name = "lblVleurSctre";
            this.lblVleurSctre.Size = new System.Drawing.Size(88, 13);
            this.lblVleurSctre.TabIndex = 130;
            this.lblVleurSctre.Text = "20 po, 7 pa, 8 pc";
            // 
            // lblVleurBtonChne
            // 
            this.lblVleurBtonChne.AutoSize = true;
            this.lblVleurBtonChne.Location = new System.Drawing.Point(552, 27);
            this.lblVleurBtonChne.Name = "lblVleurBtonChne";
            this.lblVleurBtonChne.Size = new System.Drawing.Size(55, 13);
            this.lblVleurBtonChne.TabIndex = 129;
            this.lblVleurBtonChne.Text = "4 pa, 8 pc";
            // 
            // lblVleurBatons
            // 
            this.lblVleurBatons.AutoSize = true;
            this.lblVleurBatons.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurBatons.Location = new System.Drawing.Point(552, 3);
            this.lblVleurBatons.Name = "lblVleurBatons";
            this.lblVleurBatons.Size = new System.Drawing.Size(37, 13);
            this.lblVleurBatons.TabIndex = 128;
            this.lblVleurBatons.Text = "Valeur";
            // 
            // chkSctre
            // 
            this.chkSctre.AutoSize = true;
            this.chkSctre.Location = new System.Drawing.Point(13, 52);
            this.chkSctre.Name = "chkSctre";
            this.chkSctre.Size = new System.Drawing.Size(15, 14);
            this.chkSctre.TabIndex = 89;
            this.chkSctre.UseVisualStyleBackColor = true;
            this.chkSctre.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblPrteSctre
            // 
            this.lblPrteSctre.AutoSize = true;
            this.lblPrteSctre.Location = new System.Drawing.Point(200, 52);
            this.lblPrteSctre.Name = "lblPrteSctre";
            this.lblPrteSctre.Size = new System.Drawing.Size(36, 13);
            this.lblPrteSctre.TabIndex = 88;
            this.lblPrteSctre.Text = "70 cm";
            // 
            // lblPrteBtonChne
            // 
            this.lblPrteBtonChne.AutoSize = true;
            this.lblPrteBtonChne.Location = new System.Drawing.Point(200, 27);
            this.lblPrteBtonChne.Name = "lblPrteBtonChne";
            this.lblPrteBtonChne.Size = new System.Drawing.Size(36, 13);
            this.lblPrteBtonChne.TabIndex = 87;
            this.lblPrteBtonChne.Text = "60 cm";
            // 
            // lblPrteBton
            // 
            this.lblPrteBton.AutoSize = true;
            this.lblPrteBton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrteBton.Location = new System.Drawing.Point(200, 3);
            this.lblPrteBton.Name = "lblPrteBton";
            this.lblPrteBton.Size = new System.Drawing.Size(38, 13);
            this.lblPrteBton.TabIndex = 86;
            this.lblPrteBton.Text = "Portée";
            // 
            // chkBtonChne
            // 
            this.chkBtonChne.AutoSize = true;
            this.chkBtonChne.Location = new System.Drawing.Point(13, 27);
            this.chkBtonChne.Name = "chkBtonChne";
            this.chkBtonChne.Size = new System.Drawing.Size(15, 14);
            this.chkBtonChne.TabIndex = 85;
            this.chkBtonChne.UseVisualStyleBackColor = true;
            this.chkBtonChne.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblEftsSctre
            // 
            this.lblEftsSctre.AutoSize = true;
            this.lblEftsSctre.Location = new System.Drawing.Point(454, 52);
            this.lblEftsSctre.Name = "lblEftsSctre";
            this.lblEftsSctre.Size = new System.Drawing.Size(61, 13);
            this.lblEftsSctre.TabIndex = 67;
            this.lblEftsSctre.Text = "-1 enrg tout";
            // 
            // lblNomSctre
            // 
            this.lblNomSctre.AutoSize = true;
            this.lblNomSctre.Location = new System.Drawing.Point(34, 52);
            this.lblNomSctre.Name = "lblNomSctre";
            this.lblNomSctre.Size = new System.Drawing.Size(87, 13);
            this.lblNomSctre.TabIndex = 62;
            this.lblNomSctre.Text = "Sceptre des fées";
            // 
            // lblPdsSctre
            // 
            this.lblPdsSctre.AutoSize = true;
            this.lblPdsSctre.Location = new System.Drawing.Point(128, 52);
            this.lblPdsSctre.Name = "lblPdsSctre";
            this.lblPdsSctre.Size = new System.Drawing.Size(34, 13);
            this.lblPdsSctre.TabIndex = 63;
            this.lblPdsSctre.Text = "0,5kg";
            // 
            // nudSctre
            // 
            this.nudSctre.Location = new System.Drawing.Point(266, 50);
            this.nudSctre.Name = "nudSctre";
            this.nudSctre.Size = new System.Drawing.Size(41, 20);
            this.nudSctre.TabIndex = 64;
            this.nudSctre.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSctre.ValueChanged += new System.EventHandler(this.nudSctre_ValueChanged);
            // 
            // lblTpeSctre
            // 
            this.lblTpeSctre.AutoSize = true;
            this.lblTpeSctre.Location = new System.Drawing.Point(325, 52);
            this.lblTpeSctre.Name = "lblTpeSctre";
            this.lblTpeSctre.Size = new System.Drawing.Size(62, 13);
            this.lblTpeSctre.TabIndex = 65;
            this.lblTpeSctre.Text = "Contondant";
            // 
            // lblDgtsSctre
            // 
            this.lblDgtsSctre.AutoSize = true;
            this.lblDgtsSctre.Location = new System.Drawing.Point(397, 52);
            this.lblDgtsSctre.Name = "lblDgtsSctre";
            this.lblDgtsSctre.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsSctre.TabIndex = 66;
            this.lblDgtsSctre.Text = "1";
            // 
            // lblEftsBtonChne
            // 
            this.lblEftsBtonChne.AutoSize = true;
            this.lblEftsBtonChne.Location = new System.Drawing.Point(454, 27);
            this.lblEftsBtonChne.Name = "lblEftsBtonChne";
            this.lblEftsBtonChne.Size = new System.Drawing.Size(38, 13);
            this.lblEftsBtonChne.TabIndex = 61;
            this.lblEftsBtonChne.Text = "Aucun";
            // 
            // lblEftsBton
            // 
            this.lblEftsBton.AutoSize = true;
            this.lblEftsBton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEftsBton.Location = new System.Drawing.Point(454, 3);
            this.lblEftsBton.Name = "lblEftsBton";
            this.lblEftsBton.Size = new System.Drawing.Size(34, 13);
            this.lblEftsBton.TabIndex = 60;
            this.lblEftsBton.Text = "Effets";
            // 
            // lblNomBtonChne
            // 
            this.lblNomBtonChne.AutoSize = true;
            this.lblNomBtonChne.Location = new System.Drawing.Point(34, 27);
            this.lblNomBtonChne.Name = "lblNomBtonChne";
            this.lblNomBtonChne.Size = new System.Drawing.Size(83, 13);
            this.lblNomBtonChne.TabIndex = 54;
            this.lblNomBtonChne.Text = "Bâton de chêne";
            // 
            // lblPdsBtonChne
            // 
            this.lblPdsBtonChne.AutoSize = true;
            this.lblPdsBtonChne.Location = new System.Drawing.Point(128, 27);
            this.lblPdsBtonChne.Name = "lblPdsBtonChne";
            this.lblPdsBtonChne.Size = new System.Drawing.Size(40, 13);
            this.lblPdsBtonChne.TabIndex = 55;
            this.lblPdsBtonChne.Text = "0,25kg";
            // 
            // nudBtonChne
            // 
            this.nudBtonChne.Location = new System.Drawing.Point(266, 25);
            this.nudBtonChne.Name = "nudBtonChne";
            this.nudBtonChne.Size = new System.Drawing.Size(41, 20);
            this.nudBtonChne.TabIndex = 57;
            this.nudBtonChne.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBtonChne.ValueChanged += new System.EventHandler(this.nudBtonChne_ValueChanged);
            // 
            // lblTpeBtonChne
            // 
            this.lblTpeBtonChne.AutoSize = true;
            this.lblTpeBtonChne.Location = new System.Drawing.Point(325, 27);
            this.lblTpeBtonChne.Name = "lblTpeBtonChne";
            this.lblTpeBtonChne.Size = new System.Drawing.Size(62, 13);
            this.lblTpeBtonChne.TabIndex = 58;
            this.lblTpeBtonChne.Text = "Contondant";
            // 
            // lblDgtsBtonChne
            // 
            this.lblDgtsBtonChne.AutoSize = true;
            this.lblDgtsBtonChne.Location = new System.Drawing.Point(397, 27);
            this.lblDgtsBtonChne.Name = "lblDgtsBtonChne";
            this.lblDgtsBtonChne.Size = new System.Drawing.Size(13, 13);
            this.lblDgtsBtonChne.TabIndex = 59;
            this.lblDgtsBtonChne.Text = "1";
            // 
            // lblNomBton
            // 
            this.lblNomBton.AutoSize = true;
            this.lblNomBton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomBton.Location = new System.Drawing.Point(34, 3);
            this.lblNomBton.Name = "lblNomBton";
            this.lblNomBton.Size = new System.Drawing.Size(29, 13);
            this.lblNomBton.TabIndex = 6;
            this.lblNomBton.Text = "Nom";
            // 
            // lblPdsBton
            // 
            this.lblPdsBton.AutoSize = true;
            this.lblPdsBton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsBton.Location = new System.Drawing.Point(128, 3);
            this.lblPdsBton.Name = "lblPdsBton";
            this.lblPdsBton.Size = new System.Drawing.Size(33, 13);
            this.lblPdsBton.TabIndex = 8;
            this.lblPdsBton.Text = "Poids";
            // 
            // lblNbBton
            // 
            this.lblNbBton.AutoSize = true;
            this.lblNbBton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbBton.Location = new System.Drawing.Point(266, 3);
            this.lblNbBton.Name = "lblNbBton";
            this.lblNbBton.Size = new System.Drawing.Size(44, 13);
            this.lblNbBton.TabIndex = 9;
            this.lblNbBton.Text = "Nombre";
            // 
            // lblTpeBton
            // 
            this.lblTpeBton.AutoSize = true;
            this.lblTpeBton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTpeBton.Location = new System.Drawing.Point(325, 3);
            this.lblTpeBton.Name = "lblTpeBton";
            this.lblTpeBton.Size = new System.Drawing.Size(31, 13);
            this.lblTpeBton.TabIndex = 10;
            this.lblTpeBton.Text = "Type";
            // 
            // lblDgtsBton
            // 
            this.lblDgtsBton.AutoSize = true;
            this.lblDgtsBton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDgtsBton.Location = new System.Drawing.Point(397, 3);
            this.lblDgtsBton.Name = "lblDgtsBton";
            this.lblDgtsBton.Size = new System.Drawing.Size(41, 13);
            this.lblDgtsBton.TabIndex = 11;
            this.lblDgtsBton.Text = "Dégâts";
            // 
            // tpArmures
            // 
            this.tpArmures.Controls.Add(this.tcArmure);
            this.tpArmures.Location = new System.Drawing.Point(4, 22);
            this.tpArmures.Name = "tpArmures";
            this.tpArmures.Size = new System.Drawing.Size(703, 252);
            this.tpArmures.TabIndex = 1;
            this.tpArmures.Text = "Armure";
            this.tpArmures.UseVisualStyleBackColor = true;
            // 
            // tcArmure
            // 
            this.tcArmure.Controls.Add(this.tbCasque);
            this.tcArmure.Controls.Add(this.tpBuste);
            this.tcArmure.Controls.Add(this.tpGants);
            this.tcArmure.Controls.Add(this.tpGenouillere);
            this.tcArmure.Controls.Add(this.tpChaussures);
            this.tcArmure.Controls.Add(this.tpBouclier);
            this.tcArmure.Location = new System.Drawing.Point(3, 3);
            this.tcArmure.Name = "tcArmure";
            this.tcArmure.SelectedIndex = 0;
            this.tcArmure.Size = new System.Drawing.Size(697, 246);
            this.tcArmure.TabIndex = 0;
            // 
            // tbCasque
            // 
            this.tbCasque.AutoScroll = true;
            this.tbCasque.Controls.Add(this.lblPrpieteCsqueBrbre);
            this.tbCasque.Controls.Add(this.lblPrpieteChplFr);
            this.tbCasque.Controls.Add(this.lblPrpieteCrvlre);
            this.tbCasque.Controls.Add(this.lblPrpieteMrn);
            this.tbCasque.Controls.Add(this.lblPrpieteCfeMle);
            this.tbCasque.Controls.Add(this.lblPrpieteSpghlm);
            this.tbCasque.Controls.Add(this.lblPrpieteCasques);
            this.tbCasque.Controls.Add(this.lblDescDeuxCasques);
            this.tbCasque.Controls.Add(this.lblDescCasques);
            this.tbCasque.Controls.Add(this.lblVleurCsqueBrbre);
            this.tbCasque.Controls.Add(this.lblVleurChplFr);
            this.tbCasque.Controls.Add(this.lblVleurMrn);
            this.tbCasque.Controls.Add(this.lblVleurCrvlre);
            this.tbCasque.Controls.Add(this.lblVleurCfeMle);
            this.tbCasque.Controls.Add(this.lblVleurSpghlm);
            this.tbCasque.Controls.Add(this.label5);
            this.tbCasque.Controls.Add(this.chkCsqueBrbre);
            this.tbCasque.Controls.Add(this.chkChplFr);
            this.tbCasque.Controls.Add(this.chkCrvlre);
            this.tbCasque.Controls.Add(this.chkMrn);
            this.tbCasque.Controls.Add(this.chkCfeMle);
            this.tbCasque.Controls.Add(this.chkSpghlm);
            this.tbCasque.Controls.Add(this.lblNomCsqueBrbre);
            this.tbCasque.Controls.Add(this.lblPdsCsqueBrbre);
            this.tbCasque.Controls.Add(this.nudCsqueBrbre);
            this.tbCasque.Controls.Add(this.lblEftsCsqueBrbre);
            this.tbCasque.Controls.Add(this.lblNomChplFr);
            this.tbCasque.Controls.Add(this.lblPdsChplFr);
            this.tbCasque.Controls.Add(this.nudChplFr);
            this.tbCasque.Controls.Add(this.lblEftsChplFr);
            this.tbCasque.Controls.Add(this.lblNomCrvlre);
            this.tbCasque.Controls.Add(this.lblPdsCrvlre);
            this.tbCasque.Controls.Add(this.nudCrvlre);
            this.tbCasque.Controls.Add(this.lblEftsCrvlre);
            this.tbCasque.Controls.Add(this.lblNomMrn);
            this.tbCasque.Controls.Add(this.lblPdsMrn);
            this.tbCasque.Controls.Add(this.nudMrn);
            this.tbCasque.Controls.Add(this.lblEftsMrn);
            this.tbCasque.Controls.Add(this.lblNomCfeMle);
            this.tbCasque.Controls.Add(this.lblPdsCfeMle);
            this.tbCasque.Controls.Add(this.nudCfeMle);
            this.tbCasque.Controls.Add(this.lblEftsCfeMle);
            this.tbCasque.Controls.Add(this.lblNomSpghlm);
            this.tbCasque.Controls.Add(this.lblPdsSpghlm);
            this.tbCasque.Controls.Add(this.nudSpghlm);
            this.tbCasque.Controls.Add(this.lblEftsSpghlm);
            this.tbCasque.Controls.Add(this.lblNomCasques);
            this.tbCasque.Controls.Add(this.lblPdsCasques);
            this.tbCasque.Controls.Add(this.lblNbCasques);
            this.tbCasque.Controls.Add(this.lblEftCasques);
            this.tbCasque.Location = new System.Drawing.Point(4, 22);
            this.tbCasque.Name = "tbCasque";
            this.tbCasque.Padding = new System.Windows.Forms.Padding(3);
            this.tbCasque.Size = new System.Drawing.Size(689, 220);
            this.tbCasque.TabIndex = 0;
            this.tbCasque.Text = "Casques";
            this.tbCasque.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteCsqueBrbre
            // 
            this.lblPrpieteCsqueBrbre.AutoSize = true;
            this.lblPrpieteCsqueBrbre.Location = new System.Drawing.Point(475, 152);
            this.lblPrpieteCsqueBrbre.Name = "lblPrpieteCsqueBrbre";
            this.lblPrpieteCsqueBrbre.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCsqueBrbre.TabIndex = 146;
            this.lblPrpieteCsqueBrbre.Text = "Aucune";
            // 
            // lblPrpieteChplFr
            // 
            this.lblPrpieteChplFr.AutoSize = true;
            this.lblPrpieteChplFr.Location = new System.Drawing.Point(475, 127);
            this.lblPrpieteChplFr.Name = "lblPrpieteChplFr";
            this.lblPrpieteChplFr.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteChplFr.TabIndex = 145;
            this.lblPrpieteChplFr.Text = "Aucune";
            // 
            // lblPrpieteCrvlre
            // 
            this.lblPrpieteCrvlre.AutoSize = true;
            this.lblPrpieteCrvlre.Location = new System.Drawing.Point(475, 102);
            this.lblPrpieteCrvlre.Name = "lblPrpieteCrvlre";
            this.lblPrpieteCrvlre.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCrvlre.TabIndex = 144;
            this.lblPrpieteCrvlre.Text = "Aucune";
            // 
            // lblPrpieteMrn
            // 
            this.lblPrpieteMrn.AutoSize = true;
            this.lblPrpieteMrn.Location = new System.Drawing.Point(475, 77);
            this.lblPrpieteMrn.Name = "lblPrpieteMrn";
            this.lblPrpieteMrn.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteMrn.TabIndex = 143;
            this.lblPrpieteMrn.Text = "Aucune";
            // 
            // lblPrpieteCfeMle
            // 
            this.lblPrpieteCfeMle.AutoSize = true;
            this.lblPrpieteCfeMle.Location = new System.Drawing.Point(475, 52);
            this.lblPrpieteCfeMle.Name = "lblPrpieteCfeMle";
            this.lblPrpieteCfeMle.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCfeMle.TabIndex = 142;
            this.lblPrpieteCfeMle.Text = "Aucune";
            // 
            // lblPrpieteSpghlm
            // 
            this.lblPrpieteSpghlm.AutoSize = true;
            this.lblPrpieteSpghlm.Location = new System.Drawing.Point(475, 27);
            this.lblPrpieteSpghlm.Name = "lblPrpieteSpghlm";
            this.lblPrpieteSpghlm.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteSpghlm.TabIndex = 141;
            this.lblPrpieteSpghlm.Text = "Aucune";
            // 
            // lblPrpieteCasques
            // 
            this.lblPrpieteCasques.AutoSize = true;
            this.lblPrpieteCasques.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteCasques.Location = new System.Drawing.Point(475, 3);
            this.lblPrpieteCasques.Name = "lblPrpieteCasques";
            this.lblPrpieteCasques.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteCasques.TabIndex = 140;
            this.lblPrpieteCasques.Text = "Propriété";
            // 
            // lblDescDeuxCasques
            // 
            this.lblDescDeuxCasques.AutoSize = true;
            this.lblDescDeuxCasques.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescDeuxCasques.Location = new System.Drawing.Point(10, 213);
            this.lblDescDeuxCasques.Name = "lblDescDeuxCasques";
            this.lblDescDeuxCasques.Size = new System.Drawing.Size(212, 13);
            this.lblDescDeuxCasques.TabIndex = 139;
            this.lblDescDeuxCasques.Text = "P-T : Protection Tout; P-R : Protection Rien";
            // 
            // lblDescCasques
            // 
            this.lblDescCasques.AutoSize = true;
            this.lblDescCasques.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescCasques.Location = new System.Drawing.Point(10, 194);
            this.lblDescCasques.Name = "lblDescCasques";
            this.lblDescCasques.Size = new System.Drawing.Size(556, 13);
            this.lblDescCasques.TabIndex = 138;
            this.lblDescCasques.Text = "P-AT : Protection Attaque Tranchante; P-AC : Protection Attaque Contondante; P-AP" +
    " : Protection Attaque Perforante";
            // 
            // lblVleurCsqueBrbre
            // 
            this.lblVleurCsqueBrbre.AutoSize = true;
            this.lblVleurCsqueBrbre.Location = new System.Drawing.Point(375, 152);
            this.lblVleurCsqueBrbre.Name = "lblVleurCsqueBrbre";
            this.lblVleurCsqueBrbre.Size = new System.Drawing.Size(55, 13);
            this.lblVleurCsqueBrbre.TabIndex = 137;
            this.lblVleurCsqueBrbre.Text = "3 po, 5 pa";
            // 
            // lblVleurChplFr
            // 
            this.lblVleurChplFr.AutoSize = true;
            this.lblVleurChplFr.Location = new System.Drawing.Point(375, 127);
            this.lblVleurChplFr.Name = "lblVleurChplFr";
            this.lblVleurChplFr.Size = new System.Drawing.Size(82, 13);
            this.lblVleurChplFr.TabIndex = 136;
            this.lblVleurChplFr.Text = "2 po, 5 pa, 6 pc";
            // 
            // lblVleurMrn
            // 
            this.lblVleurMrn.AutoSize = true;
            this.lblVleurMrn.Location = new System.Drawing.Point(375, 77);
            this.lblVleurMrn.Name = "lblVleurMrn";
            this.lblVleurMrn.Size = new System.Drawing.Size(82, 13);
            this.lblVleurMrn.TabIndex = 135;
            this.lblVleurMrn.Text = "2 po, 5 pa, 6 pc";
            // 
            // lblVleurCrvlre
            // 
            this.lblVleurCrvlre.AutoSize = true;
            this.lblVleurCrvlre.Location = new System.Drawing.Point(375, 102);
            this.lblVleurCrvlre.Name = "lblVleurCrvlre";
            this.lblVleurCrvlre.Size = new System.Drawing.Size(82, 13);
            this.lblVleurCrvlre.TabIndex = 134;
            this.lblVleurCrvlre.Text = "2 po, 4 pa, 4 pc";
            // 
            // lblVleurCfeMle
            // 
            this.lblVleurCfeMle.AutoSize = true;
            this.lblVleurCfeMle.Location = new System.Drawing.Point(375, 52);
            this.lblVleurCfeMle.Name = "lblVleurCfeMle";
            this.lblVleurCfeMle.Size = new System.Drawing.Size(82, 13);
            this.lblVleurCfeMle.TabIndex = 133;
            this.lblVleurCfeMle.Text = "2 po, 8 pa, 4 pc";
            // 
            // lblVleurSpghlm
            // 
            this.lblVleurSpghlm.AutoSize = true;
            this.lblVleurSpghlm.Location = new System.Drawing.Point(375, 27);
            this.lblVleurSpghlm.Name = "lblVleurSpghlm";
            this.lblVleurSpghlm.Size = new System.Drawing.Size(82, 13);
            this.lblVleurSpghlm.TabIndex = 132;
            this.lblVleurSpghlm.Text = "3 po, 7 pa, 6 pc";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(375, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 131;
            this.label5.Text = "Valeur";
            // 
            // chkCsqueBrbre
            // 
            this.chkCsqueBrbre.AutoSize = true;
            this.chkCsqueBrbre.Location = new System.Drawing.Point(13, 152);
            this.chkCsqueBrbre.Name = "chkCsqueBrbre";
            this.chkCsqueBrbre.Size = new System.Drawing.Size(15, 14);
            this.chkCsqueBrbre.TabIndex = 91;
            this.chkCsqueBrbre.UseVisualStyleBackColor = true;
            this.chkCsqueBrbre.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkChplFr
            // 
            this.chkChplFr.AutoSize = true;
            this.chkChplFr.Location = new System.Drawing.Point(13, 127);
            this.chkChplFr.Name = "chkChplFr";
            this.chkChplFr.Size = new System.Drawing.Size(15, 14);
            this.chkChplFr.TabIndex = 90;
            this.chkChplFr.UseVisualStyleBackColor = true;
            this.chkChplFr.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkCrvlre
            // 
            this.chkCrvlre.AutoSize = true;
            this.chkCrvlre.Location = new System.Drawing.Point(13, 102);
            this.chkCrvlre.Name = "chkCrvlre";
            this.chkCrvlre.Size = new System.Drawing.Size(15, 14);
            this.chkCrvlre.TabIndex = 89;
            this.chkCrvlre.UseVisualStyleBackColor = true;
            this.chkCrvlre.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkMrn
            // 
            this.chkMrn.AutoSize = true;
            this.chkMrn.Location = new System.Drawing.Point(13, 77);
            this.chkMrn.Name = "chkMrn";
            this.chkMrn.Size = new System.Drawing.Size(15, 14);
            this.chkMrn.TabIndex = 88;
            this.chkMrn.UseVisualStyleBackColor = true;
            this.chkMrn.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkCfeMle
            // 
            this.chkCfeMle.AutoSize = true;
            this.chkCfeMle.Location = new System.Drawing.Point(13, 52);
            this.chkCfeMle.Name = "chkCfeMle";
            this.chkCfeMle.Size = new System.Drawing.Size(15, 14);
            this.chkCfeMle.TabIndex = 87;
            this.chkCfeMle.UseVisualStyleBackColor = true;
            this.chkCfeMle.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkSpghlm
            // 
            this.chkSpghlm.AutoSize = true;
            this.chkSpghlm.Location = new System.Drawing.Point(13, 27);
            this.chkSpghlm.Name = "chkSpghlm";
            this.chkSpghlm.Size = new System.Drawing.Size(15, 14);
            this.chkSpghlm.TabIndex = 86;
            this.chkSpghlm.UseVisualStyleBackColor = true;
            this.chkSpghlm.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomCsqueBrbre
            // 
            this.lblNomCsqueBrbre.AutoSize = true;
            this.lblNomCsqueBrbre.Location = new System.Drawing.Point(34, 152);
            this.lblNomCsqueBrbre.Name = "lblNomCsqueBrbre";
            this.lblNomCsqueBrbre.Size = new System.Drawing.Size(82, 13);
            this.lblNomCsqueBrbre.TabIndex = 81;
            this.lblNomCsqueBrbre.Text = "Casque barbare";
            // 
            // lblPdsCsqueBrbre
            // 
            this.lblPdsCsqueBrbre.AutoSize = true;
            this.lblPdsCsqueBrbre.Location = new System.Drawing.Point(128, 152);
            this.lblPdsCsqueBrbre.Name = "lblPdsCsqueBrbre";
            this.lblPdsCsqueBrbre.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCsqueBrbre.TabIndex = 82;
            this.lblPdsCsqueBrbre.Text = "1,8kg";
            // 
            // nudCsqueBrbre
            // 
            this.nudCsqueBrbre.Location = new System.Drawing.Point(200, 150);
            this.nudCsqueBrbre.Name = "nudCsqueBrbre";
            this.nudCsqueBrbre.Size = new System.Drawing.Size(41, 20);
            this.nudCsqueBrbre.TabIndex = 83;
            this.nudCsqueBrbre.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCsqueBrbre.ValueChanged += new System.EventHandler(this.nudCsqueBrbre_ValueChanged);
            // 
            // lblEftsCsqueBrbre
            // 
            this.lblEftsCsqueBrbre.AutoSize = true;
            this.lblEftsCsqueBrbre.Location = new System.Drawing.Point(266, 152);
            this.lblEftsCsqueBrbre.Name = "lblEftsCsqueBrbre";
            this.lblEftsCsqueBrbre.Size = new System.Drawing.Size(48, 13);
            this.lblEftsCsqueBrbre.TabIndex = 84;
            this.lblEftsCsqueBrbre.Text = "P-T — +2";
            // 
            // lblNomChplFr
            // 
            this.lblNomChplFr.AutoSize = true;
            this.lblNomChplFr.Location = new System.Drawing.Point(34, 127);
            this.lblNomChplFr.Name = "lblNomChplFr";
            this.lblNomChplFr.Size = new System.Drawing.Size(70, 13);
            this.lblNomChplFr.TabIndex = 77;
            this.lblNomChplFr.Text = "Chapel de fer";
            // 
            // lblPdsChplFr
            // 
            this.lblPdsChplFr.AutoSize = true;
            this.lblPdsChplFr.Location = new System.Drawing.Point(128, 127);
            this.lblPdsChplFr.Name = "lblPdsChplFr";
            this.lblPdsChplFr.Size = new System.Drawing.Size(34, 13);
            this.lblPdsChplFr.TabIndex = 78;
            this.lblPdsChplFr.Text = "1,9kg";
            // 
            // nudChplFr
            // 
            this.nudChplFr.Location = new System.Drawing.Point(200, 125);
            this.nudChplFr.Name = "nudChplFr";
            this.nudChplFr.Size = new System.Drawing.Size(41, 20);
            this.nudChplFr.TabIndex = 79;
            this.nudChplFr.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudChplFr.ValueChanged += new System.EventHandler(this.nudChplFr_ValueChanged);
            // 
            // lblEftsChplFr
            // 
            this.lblEftsChplFr.AutoSize = true;
            this.lblEftsChplFr.Location = new System.Drawing.Point(266, 127);
            this.lblEftsChplFr.Name = "lblEftsChplFr";
            this.lblEftsChplFr.Size = new System.Drawing.Size(55, 13);
            this.lblEftsChplFr.TabIndex = 80;
            this.lblEftsChplFr.Text = "P-AC — +2";
            // 
            // lblNomCrvlre
            // 
            this.lblNomCrvlre.AutoSize = true;
            this.lblNomCrvlre.Location = new System.Drawing.Point(34, 102);
            this.lblNomCrvlre.Name = "lblNomCrvlre";
            this.lblNomCrvlre.Size = new System.Drawing.Size(54, 13);
            this.lblNomCrvlre.TabIndex = 73;
            this.lblNomCrvlre.Text = "Cervelière";
            // 
            // lblPdsCrvlre
            // 
            this.lblPdsCrvlre.AutoSize = true;
            this.lblPdsCrvlre.Location = new System.Drawing.Point(128, 102);
            this.lblPdsCrvlre.Name = "lblPdsCrvlre";
            this.lblPdsCrvlre.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCrvlre.TabIndex = 74;
            this.lblPdsCrvlre.Text = "1,6kg";
            // 
            // nudCrvlre
            // 
            this.nudCrvlre.Location = new System.Drawing.Point(200, 100);
            this.nudCrvlre.Name = "nudCrvlre";
            this.nudCrvlre.Size = new System.Drawing.Size(41, 20);
            this.nudCrvlre.TabIndex = 75;
            this.nudCrvlre.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCrvlre.ValueChanged += new System.EventHandler(this.nudCrvlre_ValueChanged);
            // 
            // lblEftsCrvlre
            // 
            this.lblEftsCrvlre.AutoSize = true;
            this.lblEftsCrvlre.Location = new System.Drawing.Point(266, 102);
            this.lblEftsCrvlre.Name = "lblEftsCrvlre";
            this.lblEftsCrvlre.Size = new System.Drawing.Size(55, 13);
            this.lblEftsCrvlre.TabIndex = 76;
            this.lblEftsCrvlre.Text = "P-AP — +2";
            // 
            // lblNomMrn
            // 
            this.lblNomMrn.AutoSize = true;
            this.lblNomMrn.Location = new System.Drawing.Point(34, 77);
            this.lblNomMrn.Name = "lblNomMrn";
            this.lblNomMrn.Size = new System.Drawing.Size(39, 13);
            this.lblNomMrn.TabIndex = 69;
            this.lblNomMrn.Text = "Morion";
            // 
            // lblPdsMrn
            // 
            this.lblPdsMrn.AutoSize = true;
            this.lblPdsMrn.Location = new System.Drawing.Point(128, 77);
            this.lblPdsMrn.Name = "lblPdsMrn";
            this.lblPdsMrn.Size = new System.Drawing.Size(34, 13);
            this.lblPdsMrn.TabIndex = 70;
            this.lblPdsMrn.Text = "1,7kg";
            // 
            // nudMrn
            // 
            this.nudMrn.Location = new System.Drawing.Point(200, 75);
            this.nudMrn.Name = "nudMrn";
            this.nudMrn.Size = new System.Drawing.Size(41, 20);
            this.nudMrn.TabIndex = 71;
            this.nudMrn.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudMrn.ValueChanged += new System.EventHandler(this.nudMrn_ValueChanged);
            // 
            // lblEftsMrn
            // 
            this.lblEftsMrn.AutoSize = true;
            this.lblEftsMrn.Location = new System.Drawing.Point(266, 77);
            this.lblEftsMrn.Name = "lblEftsMrn";
            this.lblEftsMrn.Size = new System.Drawing.Size(85, 13);
            this.lblEftsMrn.TabIndex = 72;
            this.lblEftsMrn.Text = "P-AC, P-AP — +1";
            // 
            // lblNomCfeMle
            // 
            this.lblNomCfeMle.AutoSize = true;
            this.lblNomCfeMle.Location = new System.Drawing.Point(34, 52);
            this.lblNomCfeMle.Name = "lblNomCfeMle";
            this.lblNomCfeMle.Size = new System.Drawing.Size(83, 13);
            this.lblNomCfeMle.TabIndex = 65;
            this.lblNomCfeMle.Text = "Coiffe de mailles";
            // 
            // lblPdsCfeMle
            // 
            this.lblPdsCfeMle.AutoSize = true;
            this.lblPdsCfeMle.Location = new System.Drawing.Point(128, 52);
            this.lblPdsCfeMle.Name = "lblPdsCfeMle";
            this.lblPdsCfeMle.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCfeMle.TabIndex = 66;
            this.lblPdsCfeMle.Text = "2,5kg";
            // 
            // nudCfeMle
            // 
            this.nudCfeMle.Location = new System.Drawing.Point(200, 50);
            this.nudCfeMle.Name = "nudCfeMle";
            this.nudCfeMle.Size = new System.Drawing.Size(41, 20);
            this.nudCfeMle.TabIndex = 67;
            this.nudCfeMle.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCfeMle.ValueChanged += new System.EventHandler(this.nudCfeMle_ValueChanged);
            // 
            // lblEftsCfeMle
            // 
            this.lblEftsCfeMle.AutoSize = true;
            this.lblEftsCfeMle.Location = new System.Drawing.Point(266, 52);
            this.lblEftsCfeMle.Name = "lblEftsCfeMle";
            this.lblEftsCfeMle.Size = new System.Drawing.Size(55, 13);
            this.lblEftsCfeMle.TabIndex = 68;
            this.lblEftsCfeMle.Text = "P-AT — +3";
            // 
            // lblNomSpghlm
            // 
            this.lblNomSpghlm.AutoSize = true;
            this.lblNomSpghlm.Location = new System.Drawing.Point(34, 27);
            this.lblNomSpghlm.Name = "lblNomSpghlm";
            this.lblNomSpghlm.Size = new System.Drawing.Size(72, 13);
            this.lblNomSpghlm.TabIndex = 61;
            this.lblNomSpghlm.Text = "Spangenhelm";
            // 
            // lblPdsSpghlm
            // 
            this.lblPdsSpghlm.AutoSize = true;
            this.lblPdsSpghlm.Location = new System.Drawing.Point(128, 27);
            this.lblPdsSpghlm.Name = "lblPdsSpghlm";
            this.lblPdsSpghlm.Size = new System.Drawing.Size(34, 13);
            this.lblPdsSpghlm.TabIndex = 62;
            this.lblPdsSpghlm.Text = "4,0kg";
            // 
            // nudSpghlm
            // 
            this.nudSpghlm.Location = new System.Drawing.Point(200, 25);
            this.nudSpghlm.Name = "nudSpghlm";
            this.nudSpghlm.Size = new System.Drawing.Size(41, 20);
            this.nudSpghlm.TabIndex = 63;
            this.nudSpghlm.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSpghlm.ValueChanged += new System.EventHandler(this.nudSpghlm_ValueChanged);
            // 
            // lblEftsSpghlm
            // 
            this.lblEftsSpghlm.AutoSize = true;
            this.lblEftsSpghlm.Location = new System.Drawing.Point(266, 27);
            this.lblEftsSpghlm.Name = "lblEftsSpghlm";
            this.lblEftsSpghlm.Size = new System.Drawing.Size(48, 13);
            this.lblEftsSpghlm.TabIndex = 64;
            this.lblEftsSpghlm.Text = "P-T — +4";
            // 
            // lblNomCasques
            // 
            this.lblNomCasques.AutoSize = true;
            this.lblNomCasques.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomCasques.Location = new System.Drawing.Point(34, 3);
            this.lblNomCasques.Name = "lblNomCasques";
            this.lblNomCasques.Size = new System.Drawing.Size(29, 13);
            this.lblNomCasques.TabIndex = 18;
            this.lblNomCasques.Text = "Nom";
            // 
            // lblPdsCasques
            // 
            this.lblPdsCasques.AutoSize = true;
            this.lblPdsCasques.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsCasques.Location = new System.Drawing.Point(128, 3);
            this.lblPdsCasques.Name = "lblPdsCasques";
            this.lblPdsCasques.Size = new System.Drawing.Size(33, 13);
            this.lblPdsCasques.TabIndex = 20;
            this.lblPdsCasques.Text = "Poids";
            // 
            // lblNbCasques
            // 
            this.lblNbCasques.AutoSize = true;
            this.lblNbCasques.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbCasques.Location = new System.Drawing.Point(200, 3);
            this.lblNbCasques.Name = "lblNbCasques";
            this.lblNbCasques.Size = new System.Drawing.Size(44, 13);
            this.lblNbCasques.TabIndex = 21;
            this.lblNbCasques.Text = "Nombre";
            // 
            // lblEftCasques
            // 
            this.lblEftCasques.AutoSize = true;
            this.lblEftCasques.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEftCasques.Location = new System.Drawing.Point(266, 3);
            this.lblEftCasques.Name = "lblEftCasques";
            this.lblEftCasques.Size = new System.Drawing.Size(34, 13);
            this.lblEftCasques.TabIndex = 23;
            this.lblEftCasques.Text = "Effets";
            // 
            // tpBuste
            // 
            this.tpBuste.AutoScroll = true;
            this.tpBuste.Controls.Add(this.lblPrpieteCrsBze);
            this.tpBuste.Controls.Add(this.lblPrpieteRbeCuir);
            this.tpBuste.Controls.Add(this.lblPrpieteCrsFr);
            this.tpBuste.Controls.Add(this.lblPrpieteCtphrcte);
            this.tpBuste.Controls.Add(this.lblPrpieteBrgne);
            this.tpBuste.Controls.Add(this.lblPrpieteVtments);
            this.tpBuste.Controls.Add(this.lblPrpieteBuste);
            this.tpBuste.Controls.Add(this.lblVleurCrsBze);
            this.tpBuste.Controls.Add(this.lblVleurRbeCuir);
            this.tpBuste.Controls.Add(this.lblDescDeuxBuste);
            this.tpBuste.Controls.Add(this.lblDescBuste);
            this.tpBuste.Controls.Add(this.lblVleurCrsFr);
            this.tpBuste.Controls.Add(this.lblVleurCtphrcte);
            this.tpBuste.Controls.Add(this.lblVleurBrgne);
            this.tpBuste.Controls.Add(this.lblVleurVtments);
            this.tpBuste.Controls.Add(this.lblVleurBuste);
            this.tpBuste.Controls.Add(this.chkCrsBze);
            this.tpBuste.Controls.Add(this.chkRbeCuir);
            this.tpBuste.Controls.Add(this.chkCrsFr);
            this.tpBuste.Controls.Add(this.chkCtphrcte);
            this.tpBuste.Controls.Add(this.chkBrgne);
            this.tpBuste.Controls.Add(this.chkVtments);
            this.tpBuste.Controls.Add(this.lblNomCrsBze);
            this.tpBuste.Controls.Add(this.lblPdsCrsBze);
            this.tpBuste.Controls.Add(this.nudCrsBze);
            this.tpBuste.Controls.Add(this.lblEftsCrsBze);
            this.tpBuste.Controls.Add(this.lblNomRbeCuir);
            this.tpBuste.Controls.Add(this.lblPdsRbeCuir);
            this.tpBuste.Controls.Add(this.nudRbeCuir);
            this.tpBuste.Controls.Add(this.lblEftsRbeCuir);
            this.tpBuste.Controls.Add(this.lblNomCrsFr);
            this.tpBuste.Controls.Add(this.lblPdsCrsFr);
            this.tpBuste.Controls.Add(this.nudCrsFr);
            this.tpBuste.Controls.Add(this.lblEftsCrsFr);
            this.tpBuste.Controls.Add(this.lblNomCtphrcte);
            this.tpBuste.Controls.Add(this.lblPdsCtphrcte);
            this.tpBuste.Controls.Add(this.nudCtphrcte);
            this.tpBuste.Controls.Add(this.lblEftsCtphrcte);
            this.tpBuste.Controls.Add(this.lblNomBrgne);
            this.tpBuste.Controls.Add(this.lblPdsBrgne);
            this.tpBuste.Controls.Add(this.nudBrgne);
            this.tpBuste.Controls.Add(this.lblEftsBrgne);
            this.tpBuste.Controls.Add(this.lblNomVtments);
            this.tpBuste.Controls.Add(this.lblPdsVtments);
            this.tpBuste.Controls.Add(this.nudVtments);
            this.tpBuste.Controls.Add(this.lblEftsVtments);
            this.tpBuste.Controls.Add(this.lblNomBuste);
            this.tpBuste.Controls.Add(this.lblPdsBuste);
            this.tpBuste.Controls.Add(this.lblNbBuste);
            this.tpBuste.Controls.Add(this.lblEftBuste);
            this.tpBuste.Location = new System.Drawing.Point(4, 22);
            this.tpBuste.Name = "tpBuste";
            this.tpBuste.Padding = new System.Windows.Forms.Padding(3);
            this.tpBuste.Size = new System.Drawing.Size(689, 220);
            this.tpBuste.TabIndex = 1;
            this.tpBuste.Text = "Buste";
            this.tpBuste.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteCrsBze
            // 
            this.lblPrpieteCrsBze.AutoSize = true;
            this.lblPrpieteCrsBze.Location = new System.Drawing.Point(475, 152);
            this.lblPrpieteCrsBze.Name = "lblPrpieteCrsBze";
            this.lblPrpieteCrsBze.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCrsBze.TabIndex = 153;
            this.lblPrpieteCrsBze.Text = "Aucune";
            // 
            // lblPrpieteRbeCuir
            // 
            this.lblPrpieteRbeCuir.AutoSize = true;
            this.lblPrpieteRbeCuir.Location = new System.Drawing.Point(475, 127);
            this.lblPrpieteRbeCuir.Name = "lblPrpieteRbeCuir";
            this.lblPrpieteRbeCuir.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteRbeCuir.TabIndex = 152;
            this.lblPrpieteRbeCuir.Text = "Aucune";
            // 
            // lblPrpieteCrsFr
            // 
            this.lblPrpieteCrsFr.AutoSize = true;
            this.lblPrpieteCrsFr.Location = new System.Drawing.Point(475, 102);
            this.lblPrpieteCrsFr.Name = "lblPrpieteCrsFr";
            this.lblPrpieteCrsFr.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCrsFr.TabIndex = 151;
            this.lblPrpieteCrsFr.Text = "Aucune";
            // 
            // lblPrpieteCtphrcte
            // 
            this.lblPrpieteCtphrcte.AutoSize = true;
            this.lblPrpieteCtphrcte.Location = new System.Drawing.Point(475, 77);
            this.lblPrpieteCtphrcte.Name = "lblPrpieteCtphrcte";
            this.lblPrpieteCtphrcte.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCtphrcte.TabIndex = 150;
            this.lblPrpieteCtphrcte.Text = "ArmCav";
            // 
            // lblPrpieteBrgne
            // 
            this.lblPrpieteBrgne.AutoSize = true;
            this.lblPrpieteBrgne.Location = new System.Drawing.Point(475, 52);
            this.lblPrpieteBrgne.Name = "lblPrpieteBrgne";
            this.lblPrpieteBrgne.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteBrgne.TabIndex = 149;
            this.lblPrpieteBrgne.Text = "Aucune";
            // 
            // lblPrpieteVtments
            // 
            this.lblPrpieteVtments.AutoSize = true;
            this.lblPrpieteVtments.Location = new System.Drawing.Point(475, 27);
            this.lblPrpieteVtments.Name = "lblPrpieteVtments";
            this.lblPrpieteVtments.Size = new System.Drawing.Size(99, 13);
            this.lblPrpieteVtments.TabIndex = 148;
            this.lblPrpieteVtments.Text = "On est bien dedans";
            // 
            // lblPrpieteBuste
            // 
            this.lblPrpieteBuste.AutoSize = true;
            this.lblPrpieteBuste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteBuste.Location = new System.Drawing.Point(475, 3);
            this.lblPrpieteBuste.Name = "lblPrpieteBuste";
            this.lblPrpieteBuste.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteBuste.TabIndex = 147;
            this.lblPrpieteBuste.Text = "Propriété";
            // 
            // lblVleurCrsBze
            // 
            this.lblVleurCrsBze.AutoSize = true;
            this.lblVleurCrsBze.Location = new System.Drawing.Point(375, 152);
            this.lblVleurCrsBze.Name = "lblVleurCrsBze";
            this.lblVleurCrsBze.Size = new System.Drawing.Size(82, 13);
            this.lblVleurCrsBze.TabIndex = 146;
            this.lblVleurCrsBze.Text = "5 po, 5 pa, 5 pc";
            // 
            // lblVleurRbeCuir
            // 
            this.lblVleurRbeCuir.AutoSize = true;
            this.lblVleurRbeCuir.Location = new System.Drawing.Point(375, 127);
            this.lblVleurRbeCuir.Name = "lblVleurRbeCuir";
            this.lblVleurRbeCuir.Size = new System.Drawing.Size(82, 13);
            this.lblVleurRbeCuir.TabIndex = 145;
            this.lblVleurRbeCuir.Text = "3 po, 3 pa, 6 pc";
            // 
            // lblDescDeuxBuste
            // 
            this.lblDescDeuxBuste.AutoSize = true;
            this.lblDescDeuxBuste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescDeuxBuste.Location = new System.Drawing.Point(10, 213);
            this.lblDescDeuxBuste.Name = "lblDescDeuxBuste";
            this.lblDescDeuxBuste.Size = new System.Drawing.Size(359, 13);
            this.lblDescDeuxBuste.TabIndex = 144;
            this.lblDescDeuxBuste.Text = "P-T : Protection Tout; P-R : Protection Rien; ArmCav : Armure de Cavalerie";
            // 
            // lblDescBuste
            // 
            this.lblDescBuste.AutoSize = true;
            this.lblDescBuste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescBuste.Location = new System.Drawing.Point(10, 194);
            this.lblDescBuste.Name = "lblDescBuste";
            this.lblDescBuste.Size = new System.Drawing.Size(556, 13);
            this.lblDescBuste.TabIndex = 143;
            this.lblDescBuste.Text = "P-AT : Protection Attaque Tranchante; P-AC : Protection Attaque Contondante; P-AP" +
    " : Protection Attaque Perforante";
            // 
            // lblVleurCrsFr
            // 
            this.lblVleurCrsFr.AutoSize = true;
            this.lblVleurCrsFr.Location = new System.Drawing.Point(375, 102);
            this.lblVleurCrsFr.Name = "lblVleurCrsFr";
            this.lblVleurCrsFr.Size = new System.Drawing.Size(82, 13);
            this.lblVleurCrsFr.TabIndex = 142;
            this.lblVleurCrsFr.Text = "9 po, 3 pa, 2 pc";
            // 
            // lblVleurCtphrcte
            // 
            this.lblVleurCtphrcte.AutoSize = true;
            this.lblVleurCtphrcte.Location = new System.Drawing.Point(375, 77);
            this.lblVleurCtphrcte.Name = "lblVleurCtphrcte";
            this.lblVleurCtphrcte.Size = new System.Drawing.Size(61, 13);
            this.lblVleurCtphrcte.TabIndex = 141;
            this.lblVleurCtphrcte.Text = "33 po, 7 pc";
            // 
            // lblVleurBrgne
            // 
            this.lblVleurBrgne.AutoSize = true;
            this.lblVleurBrgne.Location = new System.Drawing.Point(375, 52);
            this.lblVleurBrgne.Name = "lblVleurBrgne";
            this.lblVleurBrgne.Size = new System.Drawing.Size(88, 13);
            this.lblVleurBrgne.TabIndex = 140;
            this.lblVleurBrgne.Text = "13 po, 9 pa, 5 pc";
            // 
            // lblVleurVtments
            // 
            this.lblVleurVtments.AutoSize = true;
            this.lblVleurVtments.Location = new System.Drawing.Point(375, 27);
            this.lblVleurVtments.Name = "lblVleurVtments";
            this.lblVleurVtments.Size = new System.Drawing.Size(55, 13);
            this.lblVleurVtments.TabIndex = 139;
            this.lblVleurVtments.Text = "1 po, 3 pa";
            // 
            // lblVleurBuste
            // 
            this.lblVleurBuste.AutoSize = true;
            this.lblVleurBuste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurBuste.Location = new System.Drawing.Point(375, 3);
            this.lblVleurBuste.Name = "lblVleurBuste";
            this.lblVleurBuste.Size = new System.Drawing.Size(37, 13);
            this.lblVleurBuste.TabIndex = 138;
            this.lblVleurBuste.Text = "Valeur";
            // 
            // chkCrsBze
            // 
            this.chkCrsBze.AutoSize = true;
            this.chkCrsBze.Location = new System.Drawing.Point(13, 152);
            this.chkCrsBze.Name = "chkCrsBze";
            this.chkCrsBze.Size = new System.Drawing.Size(15, 14);
            this.chkCrsBze.TabIndex = 102;
            this.chkCrsBze.UseVisualStyleBackColor = true;
            this.chkCrsBze.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkRbeCuir
            // 
            this.chkRbeCuir.AutoSize = true;
            this.chkRbeCuir.Location = new System.Drawing.Point(13, 127);
            this.chkRbeCuir.Name = "chkRbeCuir";
            this.chkRbeCuir.Size = new System.Drawing.Size(15, 14);
            this.chkRbeCuir.TabIndex = 101;
            this.chkRbeCuir.UseVisualStyleBackColor = true;
            this.chkRbeCuir.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkCrsFr
            // 
            this.chkCrsFr.AutoSize = true;
            this.chkCrsFr.Location = new System.Drawing.Point(13, 102);
            this.chkCrsFr.Name = "chkCrsFr";
            this.chkCrsFr.Size = new System.Drawing.Size(15, 14);
            this.chkCrsFr.TabIndex = 100;
            this.chkCrsFr.UseVisualStyleBackColor = true;
            this.chkCrsFr.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkCtphrcte
            // 
            this.chkCtphrcte.AutoSize = true;
            this.chkCtphrcte.Location = new System.Drawing.Point(13, 77);
            this.chkCtphrcte.Name = "chkCtphrcte";
            this.chkCtphrcte.Size = new System.Drawing.Size(15, 14);
            this.chkCtphrcte.TabIndex = 99;
            this.chkCtphrcte.UseVisualStyleBackColor = true;
            this.chkCtphrcte.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkBrgne
            // 
            this.chkBrgne.AutoSize = true;
            this.chkBrgne.Location = new System.Drawing.Point(13, 52);
            this.chkBrgne.Name = "chkBrgne";
            this.chkBrgne.Size = new System.Drawing.Size(15, 14);
            this.chkBrgne.TabIndex = 98;
            this.chkBrgne.UseVisualStyleBackColor = true;
            this.chkBrgne.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkVtments
            // 
            this.chkVtments.AutoSize = true;
            this.chkVtments.Location = new System.Drawing.Point(13, 27);
            this.chkVtments.Name = "chkVtments";
            this.chkVtments.Size = new System.Drawing.Size(15, 14);
            this.chkVtments.TabIndex = 97;
            this.chkVtments.UseVisualStyleBackColor = true;
            this.chkVtments.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomCrsBze
            // 
            this.lblNomCrsBze.AutoSize = true;
            this.lblNomCrsBze.Location = new System.Drawing.Point(34, 152);
            this.lblNomCrsBze.Name = "lblNomCrsBze";
            this.lblNomCrsBze.Size = new System.Drawing.Size(82, 13);
            this.lblNomCrsBze.TabIndex = 93;
            this.lblNomCrsBze.Text = "Cuirasse bronze";
            // 
            // lblPdsCrsBze
            // 
            this.lblPdsCrsBze.AutoSize = true;
            this.lblPdsCrsBze.Location = new System.Drawing.Point(128, 152);
            this.lblPdsCrsBze.Name = "lblPdsCrsBze";
            this.lblPdsCrsBze.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCrsBze.TabIndex = 94;
            this.lblPdsCrsBze.Text = "3,0kg";
            // 
            // nudCrsBze
            // 
            this.nudCrsBze.Location = new System.Drawing.Point(200, 150);
            this.nudCrsBze.Name = "nudCrsBze";
            this.nudCrsBze.Size = new System.Drawing.Size(41, 20);
            this.nudCrsBze.TabIndex = 95;
            this.nudCrsBze.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCrsBze.ValueChanged += new System.EventHandler(this.nudCrsBze_ValueChanged);
            // 
            // lblEftsCrsBze
            // 
            this.lblEftsCrsBze.AutoSize = true;
            this.lblEftsCrsBze.Location = new System.Drawing.Point(266, 152);
            this.lblEftsCrsBze.Name = "lblEftsCrsBze";
            this.lblEftsCrsBze.Size = new System.Drawing.Size(48, 13);
            this.lblEftsCrsBze.TabIndex = 96;
            this.lblEftsCrsBze.Text = "P-T — +1";
            // 
            // lblNomRbeCuir
            // 
            this.lblNomRbeCuir.AutoSize = true;
            this.lblNomRbeCuir.Location = new System.Drawing.Point(34, 127);
            this.lblNomRbeCuir.Name = "lblNomRbeCuir";
            this.lblNomRbeCuir.Size = new System.Drawing.Size(68, 13);
            this.lblNomRbeCuir.TabIndex = 89;
            this.lblNomRbeCuir.Text = "Robe de cuir";
            // 
            // lblPdsRbeCuir
            // 
            this.lblPdsRbeCuir.AutoSize = true;
            this.lblPdsRbeCuir.Location = new System.Drawing.Point(128, 127);
            this.lblPdsRbeCuir.Name = "lblPdsRbeCuir";
            this.lblPdsRbeCuir.Size = new System.Drawing.Size(34, 13);
            this.lblPdsRbeCuir.TabIndex = 90;
            this.lblPdsRbeCuir.Text = "1,0kg";
            // 
            // nudRbeCuir
            // 
            this.nudRbeCuir.Location = new System.Drawing.Point(200, 125);
            this.nudRbeCuir.Name = "nudRbeCuir";
            this.nudRbeCuir.Size = new System.Drawing.Size(41, 20);
            this.nudRbeCuir.TabIndex = 91;
            this.nudRbeCuir.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRbeCuir.ValueChanged += new System.EventHandler(this.nudRbeCuir_ValueChanged);
            // 
            // lblEftsRbeCuir
            // 
            this.lblEftsRbeCuir.AutoSize = true;
            this.lblEftsRbeCuir.Location = new System.Drawing.Point(266, 127);
            this.lblEftsRbeCuir.Name = "lblEftsRbeCuir";
            this.lblEftsRbeCuir.Size = new System.Drawing.Size(55, 13);
            this.lblEftsRbeCuir.TabIndex = 92;
            this.lblEftsRbeCuir.Text = "P-AC — +1";
            // 
            // lblNomCrsFr
            // 
            this.lblNomCrsFr.AutoSize = true;
            this.lblNomCrsFr.Location = new System.Drawing.Point(34, 102);
            this.lblNomCrsFr.Name = "lblNomCrsFr";
            this.lblNomCrsFr.Size = new System.Drawing.Size(62, 13);
            this.lblNomCrsFr.TabIndex = 85;
            this.lblNomCrsFr.Text = "Cuirasse fer";
            // 
            // lblPdsCrsFr
            // 
            this.lblPdsCrsFr.AutoSize = true;
            this.lblPdsCrsFr.Location = new System.Drawing.Point(128, 102);
            this.lblPdsCrsFr.Name = "lblPdsCrsFr";
            this.lblPdsCrsFr.Size = new System.Drawing.Size(40, 13);
            this.lblPdsCrsFr.TabIndex = 86;
            this.lblPdsCrsFr.Text = "15,0kg";
            // 
            // nudCrsFr
            // 
            this.nudCrsFr.Location = new System.Drawing.Point(200, 100);
            this.nudCrsFr.Name = "nudCrsFr";
            this.nudCrsFr.Size = new System.Drawing.Size(41, 20);
            this.nudCrsFr.TabIndex = 87;
            this.nudCrsFr.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCrsFr.ValueChanged += new System.EventHandler(this.nudCrsFr_ValueChanged);
            // 
            // lblEftsCrsFr
            // 
            this.lblEftsCrsFr.AutoSize = true;
            this.lblEftsCrsFr.Location = new System.Drawing.Point(266, 102);
            this.lblEftsCrsFr.Name = "lblEftsCrsFr";
            this.lblEftsCrsFr.Size = new System.Drawing.Size(48, 13);
            this.lblEftsCrsFr.TabIndex = 88;
            this.lblEftsCrsFr.Text = "P-T — +3";
            // 
            // lblNomCtphrcte
            // 
            this.lblNomCtphrcte.AutoSize = true;
            this.lblNomCtphrcte.Location = new System.Drawing.Point(34, 77);
            this.lblNomCtphrcte.Name = "lblNomCtphrcte";
            this.lblNomCtphrcte.Size = new System.Drawing.Size(65, 13);
            this.lblNomCtphrcte.TabIndex = 81;
            this.lblNomCtphrcte.Text = "Cataphracte";
            // 
            // lblPdsCtphrcte
            // 
            this.lblPdsCtphrcte.AutoSize = true;
            this.lblPdsCtphrcte.Location = new System.Drawing.Point(128, 77);
            this.lblPdsCtphrcte.Name = "lblPdsCtphrcte";
            this.lblPdsCtphrcte.Size = new System.Drawing.Size(40, 13);
            this.lblPdsCtphrcte.TabIndex = 82;
            this.lblPdsCtphrcte.Text = "40,0kg";
            // 
            // nudCtphrcte
            // 
            this.nudCtphrcte.Location = new System.Drawing.Point(200, 75);
            this.nudCtphrcte.Name = "nudCtphrcte";
            this.nudCtphrcte.Size = new System.Drawing.Size(41, 20);
            this.nudCtphrcte.TabIndex = 83;
            this.nudCtphrcte.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCtphrcte.ValueChanged += new System.EventHandler(this.nudCtphrcte_ValueChanged);
            // 
            // lblEftsCtphrcte
            // 
            this.lblEftsCtphrcte.AutoSize = true;
            this.lblEftsCtphrcte.Location = new System.Drawing.Point(266, 77);
            this.lblEftsCtphrcte.Name = "lblEftsCtphrcte";
            this.lblEftsCtphrcte.Size = new System.Drawing.Size(48, 13);
            this.lblEftsCtphrcte.TabIndex = 84;
            this.lblEftsCtphrcte.Text = "P-T — +7";
            // 
            // lblNomBrgne
            // 
            this.lblNomBrgne.AutoSize = true;
            this.lblNomBrgne.Location = new System.Drawing.Point(34, 52);
            this.lblNomBrgne.Name = "lblNomBrgne";
            this.lblNomBrgne.Size = new System.Drawing.Size(43, 13);
            this.lblNomBrgne.TabIndex = 69;
            this.lblNomBrgne.Text = "Broigne";
            // 
            // lblPdsBrgne
            // 
            this.lblPdsBrgne.AutoSize = true;
            this.lblPdsBrgne.Location = new System.Drawing.Point(128, 52);
            this.lblPdsBrgne.Name = "lblPdsBrgne";
            this.lblPdsBrgne.Size = new System.Drawing.Size(40, 13);
            this.lblPdsBrgne.TabIndex = 70;
            this.lblPdsBrgne.Text = "20,0kg";
            // 
            // nudBrgne
            // 
            this.nudBrgne.Location = new System.Drawing.Point(200, 50);
            this.nudBrgne.Name = "nudBrgne";
            this.nudBrgne.Size = new System.Drawing.Size(41, 20);
            this.nudBrgne.TabIndex = 71;
            this.nudBrgne.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBrgne.ValueChanged += new System.EventHandler(this.nudBrgne_ValueChanged);
            // 
            // lblEftsBrgne
            // 
            this.lblEftsBrgne.AutoSize = true;
            this.lblEftsBrgne.Location = new System.Drawing.Point(266, 52);
            this.lblEftsBrgne.Name = "lblEftsBrgne";
            this.lblEftsBrgne.Size = new System.Drawing.Size(55, 13);
            this.lblEftsBrgne.TabIndex = 72;
            this.lblEftsBrgne.Text = "P-AT — +6";
            // 
            // lblNomVtments
            // 
            this.lblNomVtments.AutoSize = true;
            this.lblNomVtments.Location = new System.Drawing.Point(34, 27);
            this.lblNomVtments.Name = "lblNomVtments";
            this.lblNomVtments.Size = new System.Drawing.Size(57, 13);
            this.lblNomVtments.TabIndex = 57;
            this.lblNomVtments.Text = "Vêtements";
            // 
            // lblPdsVtments
            // 
            this.lblPdsVtments.AutoSize = true;
            this.lblPdsVtments.Location = new System.Drawing.Point(128, 27);
            this.lblPdsVtments.Name = "lblPdsVtments";
            this.lblPdsVtments.Size = new System.Drawing.Size(34, 13);
            this.lblPdsVtments.TabIndex = 58;
            this.lblPdsVtments.Text = "0,2kg";
            // 
            // nudVtments
            // 
            this.nudVtments.Location = new System.Drawing.Point(200, 25);
            this.nudVtments.Name = "nudVtments";
            this.nudVtments.Size = new System.Drawing.Size(41, 20);
            this.nudVtments.TabIndex = 59;
            this.nudVtments.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudVtments.ValueChanged += new System.EventHandler(this.nudVtments_ValueChanged);
            // 
            // lblEftsVtments
            // 
            this.lblEftsVtments.AutoSize = true;
            this.lblEftsVtments.Location = new System.Drawing.Point(266, 27);
            this.lblEftsVtments.Name = "lblEftsVtments";
            this.lblEftsVtments.Size = new System.Drawing.Size(25, 13);
            this.lblEftsVtments.TabIndex = 60;
            this.lblEftsVtments.Text = "P-R";
            // 
            // lblNomBuste
            // 
            this.lblNomBuste.AutoSize = true;
            this.lblNomBuste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomBuste.Location = new System.Drawing.Point(34, 3);
            this.lblNomBuste.Name = "lblNomBuste";
            this.lblNomBuste.Size = new System.Drawing.Size(29, 13);
            this.lblNomBuste.TabIndex = 24;
            this.lblNomBuste.Text = "Nom";
            // 
            // lblPdsBuste
            // 
            this.lblPdsBuste.AutoSize = true;
            this.lblPdsBuste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsBuste.Location = new System.Drawing.Point(128, 3);
            this.lblPdsBuste.Name = "lblPdsBuste";
            this.lblPdsBuste.Size = new System.Drawing.Size(33, 13);
            this.lblPdsBuste.TabIndex = 25;
            this.lblPdsBuste.Text = "Poids";
            // 
            // lblNbBuste
            // 
            this.lblNbBuste.AutoSize = true;
            this.lblNbBuste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbBuste.Location = new System.Drawing.Point(200, 3);
            this.lblNbBuste.Name = "lblNbBuste";
            this.lblNbBuste.Size = new System.Drawing.Size(44, 13);
            this.lblNbBuste.TabIndex = 26;
            this.lblNbBuste.Text = "Nombre";
            // 
            // lblEftBuste
            // 
            this.lblEftBuste.AutoSize = true;
            this.lblEftBuste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEftBuste.Location = new System.Drawing.Point(266, 3);
            this.lblEftBuste.Name = "lblEftBuste";
            this.lblEftBuste.Size = new System.Drawing.Size(34, 13);
            this.lblEftBuste.TabIndex = 27;
            this.lblEftBuste.Text = "Effets";
            // 
            // tpGants
            // 
            this.tpGants.AutoScroll = true;
            this.tpGants.Controls.Add(this.lblPrpieteMton);
            this.tpGants.Controls.Add(this.lblPrpieteMitne);
            this.tpGants.Controls.Add(this.lblPrpieteGntlet);
            this.tpGants.Controls.Add(this.lblPrpieteGntMles);
            this.tpGants.Controls.Add(this.lblPrpieteGants);
            this.tpGants.Controls.Add(this.lblVleurMton);
            this.tpGants.Controls.Add(this.lblVleurMitne);
            this.tpGants.Controls.Add(this.lblVleurGntlet);
            this.tpGants.Controls.Add(this.lblVleurGntMles);
            this.tpGants.Controls.Add(this.lblVleurGants);
            this.tpGants.Controls.Add(this.lblVleurlblDescDeuxGants);
            this.tpGants.Controls.Add(this.lblVleurlblDescGants);
            this.tpGants.Controls.Add(this.chkMton);
            this.tpGants.Controls.Add(this.chkMitne);
            this.tpGants.Controls.Add(this.chkGntlet);
            this.tpGants.Controls.Add(this.chkGntMles);
            this.tpGants.Controls.Add(this.lblNomMton);
            this.tpGants.Controls.Add(this.lblPdsMton);
            this.tpGants.Controls.Add(this.nudMton);
            this.tpGants.Controls.Add(this.lblEftsMton);
            this.tpGants.Controls.Add(this.lblNomMitne);
            this.tpGants.Controls.Add(this.lblPdsMitne);
            this.tpGants.Controls.Add(this.nudMitne);
            this.tpGants.Controls.Add(this.lblEftsMitne);
            this.tpGants.Controls.Add(this.lblNomGntlet);
            this.tpGants.Controls.Add(this.lblPdsGntlet);
            this.tpGants.Controls.Add(this.nudGntlet);
            this.tpGants.Controls.Add(this.lblEftsGntlet);
            this.tpGants.Controls.Add(this.lblNomGntMles);
            this.tpGants.Controls.Add(this.lblPdsGntMles);
            this.tpGants.Controls.Add(this.nudGntMles);
            this.tpGants.Controls.Add(this.lblEftsGntMles);
            this.tpGants.Controls.Add(this.lblNomGants);
            this.tpGants.Controls.Add(this.lblPdsGants);
            this.tpGants.Controls.Add(this.lblNbGants);
            this.tpGants.Controls.Add(this.lblEftGants);
            this.tpGants.Location = new System.Drawing.Point(4, 22);
            this.tpGants.Name = "tpGants";
            this.tpGants.Size = new System.Drawing.Size(689, 220);
            this.tpGants.TabIndex = 2;
            this.tpGants.Text = "Gants";
            this.tpGants.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteMton
            // 
            this.lblPrpieteMton.AutoSize = true;
            this.lblPrpieteMton.Location = new System.Drawing.Point(475, 102);
            this.lblPrpieteMton.Name = "lblPrpieteMton";
            this.lblPrpieteMton.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteMton.TabIndex = 156;
            this.lblPrpieteMton.Text = "Aucune";
            // 
            // lblPrpieteMitne
            // 
            this.lblPrpieteMitne.AutoSize = true;
            this.lblPrpieteMitne.Location = new System.Drawing.Point(475, 77);
            this.lblPrpieteMitne.Name = "lblPrpieteMitne";
            this.lblPrpieteMitne.Size = new System.Drawing.Size(72, 13);
            this.lblPrpieteMitne.TabIndex = 155;
            this.lblPrpieteMitne.Text = "+1% Dextérité";
            // 
            // lblPrpieteGntlet
            // 
            this.lblPrpieteGntlet.AutoSize = true;
            this.lblPrpieteGntlet.Location = new System.Drawing.Point(475, 52);
            this.lblPrpieteGntlet.Name = "lblPrpieteGntlet";
            this.lblPrpieteGntlet.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteGntlet.TabIndex = 154;
            this.lblPrpieteGntlet.Text = "Aucune";
            // 
            // lblPrpieteGntMles
            // 
            this.lblPrpieteGntMles.AutoSize = true;
            this.lblPrpieteGntMles.Location = new System.Drawing.Point(475, 27);
            this.lblPrpieteGntMles.Name = "lblPrpieteGntMles";
            this.lblPrpieteGntMles.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteGntMles.TabIndex = 153;
            this.lblPrpieteGntMles.Text = "Aucune";
            // 
            // lblPrpieteGants
            // 
            this.lblPrpieteGants.AutoSize = true;
            this.lblPrpieteGants.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteGants.Location = new System.Drawing.Point(475, 3);
            this.lblPrpieteGants.Name = "lblPrpieteGants";
            this.lblPrpieteGants.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteGants.TabIndex = 152;
            this.lblPrpieteGants.Text = "Propriété";
            // 
            // lblVleurMton
            // 
            this.lblVleurMton.AutoSize = true;
            this.lblVleurMton.Location = new System.Drawing.Point(375, 102);
            this.lblVleurMton.Name = "lblVleurMton";
            this.lblVleurMton.Size = new System.Drawing.Size(55, 13);
            this.lblVleurMton.TabIndex = 151;
            this.lblVleurMton.Text = "3 po, 5 pc";
            // 
            // lblVleurMitne
            // 
            this.lblVleurMitne.AutoSize = true;
            this.lblVleurMitne.Location = new System.Drawing.Point(375, 77);
            this.lblVleurMitne.Name = "lblVleurMitne";
            this.lblVleurMitne.Size = new System.Drawing.Size(82, 13);
            this.lblVleurMitne.TabIndex = 150;
            this.lblVleurMitne.Text = "2 po, 6 pa, 8 pc";
            // 
            // lblVleurGntlet
            // 
            this.lblVleurGntlet.AutoSize = true;
            this.lblVleurGntlet.Location = new System.Drawing.Point(375, 52);
            this.lblVleurGntlet.Name = "lblVleurGntlet";
            this.lblVleurGntlet.Size = new System.Drawing.Size(28, 13);
            this.lblVleurGntlet.TabIndex = 149;
            this.lblVleurGntlet.Text = "5 po";
            // 
            // lblVleurGntMles
            // 
            this.lblVleurGntMles.AutoSize = true;
            this.lblVleurGntMles.Location = new System.Drawing.Point(375, 27);
            this.lblVleurGntMles.Name = "lblVleurGntMles";
            this.lblVleurGntMles.Size = new System.Drawing.Size(82, 13);
            this.lblVleurGntMles.TabIndex = 148;
            this.lblVleurGntMles.Text = "1 po, 6 pa, 8 pc";
            // 
            // lblVleurGants
            // 
            this.lblVleurGants.AutoSize = true;
            this.lblVleurGants.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurGants.Location = new System.Drawing.Point(375, 3);
            this.lblVleurGants.Name = "lblVleurGants";
            this.lblVleurGants.Size = new System.Drawing.Size(37, 13);
            this.lblVleurGants.TabIndex = 147;
            this.lblVleurGants.Text = "Valeur";
            // 
            // lblVleurlblDescDeuxGants
            // 
            this.lblVleurlblDescDeuxGants.AutoSize = true;
            this.lblVleurlblDescDeuxGants.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurlblDescDeuxGants.Location = new System.Drawing.Point(10, 153);
            this.lblVleurlblDescDeuxGants.Name = "lblVleurlblDescDeuxGants";
            this.lblVleurlblDescDeuxGants.Size = new System.Drawing.Size(212, 13);
            this.lblVleurlblDescDeuxGants.TabIndex = 146;
            this.lblVleurlblDescDeuxGants.Text = "P-T : Protection Tout; P-R : Protection Rien";
            // 
            // lblVleurlblDescGants
            // 
            this.lblVleurlblDescGants.AutoSize = true;
            this.lblVleurlblDescGants.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurlblDescGants.Location = new System.Drawing.Point(10, 138);
            this.lblVleurlblDescGants.Name = "lblVleurlblDescGants";
            this.lblVleurlblDescGants.Size = new System.Drawing.Size(556, 13);
            this.lblVleurlblDescGants.TabIndex = 145;
            this.lblVleurlblDescGants.Text = "P-AT : Protection Attaque Tranchante; P-AC : Protection Attaque Contondante; P-AP" +
    " : Protection Attaque Perforante";
            // 
            // chkMton
            // 
            this.chkMton.AutoSize = true;
            this.chkMton.Location = new System.Drawing.Point(13, 102);
            this.chkMton.Name = "chkMton";
            this.chkMton.Size = new System.Drawing.Size(15, 14);
            this.chkMton.TabIndex = 101;
            this.chkMton.UseVisualStyleBackColor = true;
            this.chkMton.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkMitne
            // 
            this.chkMitne.AutoSize = true;
            this.chkMitne.Location = new System.Drawing.Point(13, 77);
            this.chkMitne.Name = "chkMitne";
            this.chkMitne.Size = new System.Drawing.Size(15, 14);
            this.chkMitne.TabIndex = 100;
            this.chkMitne.UseVisualStyleBackColor = true;
            this.chkMitne.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkGntlet
            // 
            this.chkGntlet.AutoSize = true;
            this.chkGntlet.Location = new System.Drawing.Point(13, 52);
            this.chkGntlet.Name = "chkGntlet";
            this.chkGntlet.Size = new System.Drawing.Size(15, 14);
            this.chkGntlet.TabIndex = 99;
            this.chkGntlet.UseVisualStyleBackColor = true;
            this.chkGntlet.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkGntMles
            // 
            this.chkGntMles.AutoSize = true;
            this.chkGntMles.Location = new System.Drawing.Point(13, 27);
            this.chkGntMles.Name = "chkGntMles";
            this.chkGntMles.Size = new System.Drawing.Size(15, 14);
            this.chkGntMles.TabIndex = 98;
            this.chkGntMles.UseVisualStyleBackColor = true;
            this.chkGntMles.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomMton
            // 
            this.lblNomMton.AutoSize = true;
            this.lblNomMton.Location = new System.Drawing.Point(34, 102);
            this.lblNomMton.Name = "lblNomMton";
            this.lblNomMton.Size = new System.Drawing.Size(38, 13);
            this.lblNomMton.TabIndex = 89;
            this.lblNomMton.Text = "Mitons";
            // 
            // lblPdsMton
            // 
            this.lblPdsMton.AutoSize = true;
            this.lblPdsMton.Location = new System.Drawing.Point(128, 102);
            this.lblPdsMton.Name = "lblPdsMton";
            this.lblPdsMton.Size = new System.Drawing.Size(34, 13);
            this.lblPdsMton.TabIndex = 90;
            this.lblPdsMton.Text = "2,0kg";
            // 
            // nudMton
            // 
            this.nudMton.Location = new System.Drawing.Point(200, 100);
            this.nudMton.Name = "nudMton";
            this.nudMton.Size = new System.Drawing.Size(41, 20);
            this.nudMton.TabIndex = 91;
            this.nudMton.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudMton.ValueChanged += new System.EventHandler(this.nudMton_ValueChanged);
            // 
            // lblEftsMton
            // 
            this.lblEftsMton.AutoSize = true;
            this.lblEftsMton.Location = new System.Drawing.Point(266, 102);
            this.lblEftsMton.Name = "lblEftsMton";
            this.lblEftsMton.Size = new System.Drawing.Size(48, 13);
            this.lblEftsMton.TabIndex = 92;
            this.lblEftsMton.Text = "P-T — +1";
            // 
            // lblNomMitne
            // 
            this.lblNomMitne.AutoSize = true;
            this.lblNomMitne.Location = new System.Drawing.Point(34, 77);
            this.lblNomMitne.Name = "lblNomMitne";
            this.lblNomMitne.Size = new System.Drawing.Size(46, 13);
            this.lblNomMitne.TabIndex = 85;
            this.lblNomMitne.Text = "Mitaines";
            // 
            // lblPdsMitne
            // 
            this.lblPdsMitne.AutoSize = true;
            this.lblPdsMitne.Location = new System.Drawing.Point(128, 77);
            this.lblPdsMitne.Name = "lblPdsMitne";
            this.lblPdsMitne.Size = new System.Drawing.Size(34, 13);
            this.lblPdsMitne.TabIndex = 86;
            this.lblPdsMitne.Text = "0,6kg";
            // 
            // nudMitne
            // 
            this.nudMitne.Location = new System.Drawing.Point(200, 75);
            this.nudMitne.Name = "nudMitne";
            this.nudMitne.Size = new System.Drawing.Size(41, 20);
            this.nudMitne.TabIndex = 87;
            this.nudMitne.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudMitne.ValueChanged += new System.EventHandler(this.nudMitne_ValueChanged);
            // 
            // lblEftsMitne
            // 
            this.lblEftsMitne.AutoSize = true;
            this.lblEftsMitne.Location = new System.Drawing.Point(266, 77);
            this.lblEftsMitne.Name = "lblEftsMitne";
            this.lblEftsMitne.Size = new System.Drawing.Size(25, 13);
            this.lblEftsMitne.TabIndex = 88;
            this.lblEftsMitne.Text = "P-R";
            // 
            // lblNomGntlet
            // 
            this.lblNomGntlet.AutoSize = true;
            this.lblNomGntlet.Location = new System.Drawing.Point(34, 52);
            this.lblNomGntlet.Name = "lblNomGntlet";
            this.lblNomGntlet.Size = new System.Drawing.Size(52, 13);
            this.lblNomGntlet.TabIndex = 77;
            this.lblNomGntlet.Text = "Gantelets";
            // 
            // lblPdsGntlet
            // 
            this.lblPdsGntlet.AutoSize = true;
            this.lblPdsGntlet.Location = new System.Drawing.Point(128, 52);
            this.lblPdsGntlet.Name = "lblPdsGntlet";
            this.lblPdsGntlet.Size = new System.Drawing.Size(34, 13);
            this.lblPdsGntlet.TabIndex = 78;
            this.lblPdsGntlet.Text = "1,6kg";
            // 
            // nudGntlet
            // 
            this.nudGntlet.Location = new System.Drawing.Point(200, 50);
            this.nudGntlet.Name = "nudGntlet";
            this.nudGntlet.Size = new System.Drawing.Size(41, 20);
            this.nudGntlet.TabIndex = 79;
            this.nudGntlet.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudGntlet.ValueChanged += new System.EventHandler(this.nudGntlet_ValueChanged);
            // 
            // lblEftsGntlet
            // 
            this.lblEftsGntlet.AutoSize = true;
            this.lblEftsGntlet.Location = new System.Drawing.Point(266, 52);
            this.lblEftsGntlet.Name = "lblEftsGntlet";
            this.lblEftsGntlet.Size = new System.Drawing.Size(85, 13);
            this.lblEftsGntlet.TabIndex = 80;
            this.lblEftsGntlet.Text = "P-AC, P-AP — +1";
            // 
            // lblNomGntMles
            // 
            this.lblNomGntMles.AutoSize = true;
            this.lblNomGntMles.Location = new System.Drawing.Point(34, 27);
            this.lblNomGntMles.Name = "lblNomGntMles";
            this.lblNomGntMles.Size = new System.Drawing.Size(84, 13);
            this.lblNomGntMles.TabIndex = 73;
            this.lblNomGntMles.Text = "Gants de mailles";
            // 
            // lblPdsGntMles
            // 
            this.lblPdsGntMles.AutoSize = true;
            this.lblPdsGntMles.Location = new System.Drawing.Point(128, 27);
            this.lblPdsGntMles.Name = "lblPdsGntMles";
            this.lblPdsGntMles.Size = new System.Drawing.Size(34, 13);
            this.lblPdsGntMles.TabIndex = 74;
            this.lblPdsGntMles.Text = "0,8kg";
            // 
            // nudGntMles
            // 
            this.nudGntMles.Location = new System.Drawing.Point(200, 25);
            this.nudGntMles.Name = "nudGntMles";
            this.nudGntMles.Size = new System.Drawing.Size(41, 20);
            this.nudGntMles.TabIndex = 75;
            this.nudGntMles.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudGntMles.ValueChanged += new System.EventHandler(this.nudGntMles_ValueChanged);
            // 
            // lblEftsGntMles
            // 
            this.lblEftsGntMles.AutoSize = true;
            this.lblEftsGntMles.Location = new System.Drawing.Point(266, 27);
            this.lblEftsGntMles.Name = "lblEftsGntMles";
            this.lblEftsGntMles.Size = new System.Drawing.Size(55, 13);
            this.lblEftsGntMles.TabIndex = 76;
            this.lblEftsGntMles.Text = "P-AT — +1";
            // 
            // lblNomGants
            // 
            this.lblNomGants.AutoSize = true;
            this.lblNomGants.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomGants.Location = new System.Drawing.Point(34, 3);
            this.lblNomGants.Name = "lblNomGants";
            this.lblNomGants.Size = new System.Drawing.Size(29, 13);
            this.lblNomGants.TabIndex = 28;
            this.lblNomGants.Text = "Nom";
            // 
            // lblPdsGants
            // 
            this.lblPdsGants.AutoSize = true;
            this.lblPdsGants.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsGants.Location = new System.Drawing.Point(128, 3);
            this.lblPdsGants.Name = "lblPdsGants";
            this.lblPdsGants.Size = new System.Drawing.Size(33, 13);
            this.lblPdsGants.TabIndex = 29;
            this.lblPdsGants.Text = "Poids";
            // 
            // lblNbGants
            // 
            this.lblNbGants.AutoSize = true;
            this.lblNbGants.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbGants.Location = new System.Drawing.Point(200, 3);
            this.lblNbGants.Name = "lblNbGants";
            this.lblNbGants.Size = new System.Drawing.Size(44, 13);
            this.lblNbGants.TabIndex = 30;
            this.lblNbGants.Text = "Nombre";
            // 
            // lblEftGants
            // 
            this.lblEftGants.AutoSize = true;
            this.lblEftGants.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEftGants.Location = new System.Drawing.Point(266, 3);
            this.lblEftGants.Name = "lblEftGants";
            this.lblEftGants.Size = new System.Drawing.Size(34, 13);
            this.lblEftGants.TabIndex = 31;
            this.lblEftGants.Text = "Effets";
            // 
            // tpGenouillere
            // 
            this.tpGenouillere.AutoScroll = true;
            this.tpGenouillere.Controls.Add(this.lblPrpieteCmide);
            this.tpGenouillere.Controls.Add(this.lblPrpietePntlonTle);
            this.tpGenouillere.Controls.Add(this.lblPrpieteCuissrd);
            this.tpGenouillere.Controls.Add(this.lblPrpieteGenouilleres);
            this.tpGenouillere.Controls.Add(this.lblVleurCmide);
            this.tpGenouillere.Controls.Add(this.lblVleurPntlonTle);
            this.tpGenouillere.Controls.Add(this.lblVleurCuissrd);
            this.tpGenouillere.Controls.Add(this.lblVleurGenouilleres);
            this.tpGenouillere.Controls.Add(this.lblDescDeuxGenouilleres);
            this.tpGenouillere.Controls.Add(this.lblDescGenouilleres);
            this.tpGenouillere.Controls.Add(this.chkCmide);
            this.tpGenouillere.Controls.Add(this.chkPntlonTle);
            this.tpGenouillere.Controls.Add(this.chkCuissrd);
            this.tpGenouillere.Controls.Add(this.lblNomCmide);
            this.tpGenouillere.Controls.Add(this.lblPdsCmide);
            this.tpGenouillere.Controls.Add(this.nudCmide);
            this.tpGenouillere.Controls.Add(this.lblEftsCmide);
            this.tpGenouillere.Controls.Add(this.lblNomPntlonTle);
            this.tpGenouillere.Controls.Add(this.lblPdsPntlonTle);
            this.tpGenouillere.Controls.Add(this.nudPntlonTle);
            this.tpGenouillere.Controls.Add(this.lblEftsPntlonTle);
            this.tpGenouillere.Controls.Add(this.lblNomCuissrd);
            this.tpGenouillere.Controls.Add(this.lblPdsCuissrd);
            this.tpGenouillere.Controls.Add(this.nudCuissrd);
            this.tpGenouillere.Controls.Add(this.lblEftsCuissrd);
            this.tpGenouillere.Controls.Add(this.lblNomGenouilleres);
            this.tpGenouillere.Controls.Add(this.lblPdsGenouilleres);
            this.tpGenouillere.Controls.Add(this.lblNbGenouilleres);
            this.tpGenouillere.Controls.Add(this.lblEftGenouilleres);
            this.tpGenouillere.Location = new System.Drawing.Point(4, 22);
            this.tpGenouillere.Name = "tpGenouillere";
            this.tpGenouillere.Size = new System.Drawing.Size(689, 220);
            this.tpGenouillere.TabIndex = 3;
            this.tpGenouillere.Text = "Genouillères";
            this.tpGenouillere.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteCmide
            // 
            this.lblPrpieteCmide.AutoSize = true;
            this.lblPrpieteCmide.Location = new System.Drawing.Point(475, 77);
            this.lblPrpieteCmide.Name = "lblPrpieteCmide";
            this.lblPrpieteCmide.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCmide.TabIndex = 159;
            this.lblPrpieteCmide.Text = "Aucune";
            // 
            // lblPrpietePntlonTle
            // 
            this.lblPrpietePntlonTle.AutoSize = true;
            this.lblPrpietePntlonTle.Location = new System.Drawing.Point(475, 52);
            this.lblPrpietePntlonTle.Name = "lblPrpietePntlonTle";
            this.lblPrpietePntlonTle.Size = new System.Drawing.Size(44, 13);
            this.lblPrpietePntlonTle.TabIndex = 158;
            this.lblPrpietePntlonTle.Text = "Aucune";
            // 
            // lblPrpieteCuissrd
            // 
            this.lblPrpieteCuissrd.AutoSize = true;
            this.lblPrpieteCuissrd.Location = new System.Drawing.Point(475, 27);
            this.lblPrpieteCuissrd.Name = "lblPrpieteCuissrd";
            this.lblPrpieteCuissrd.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteCuissrd.TabIndex = 157;
            this.lblPrpieteCuissrd.Text = "Aucune";
            // 
            // lblPrpieteGenouilleres
            // 
            this.lblPrpieteGenouilleres.AutoSize = true;
            this.lblPrpieteGenouilleres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteGenouilleres.Location = new System.Drawing.Point(475, 3);
            this.lblPrpieteGenouilleres.Name = "lblPrpieteGenouilleres";
            this.lblPrpieteGenouilleres.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteGenouilleres.TabIndex = 156;
            this.lblPrpieteGenouilleres.Text = "Propriété";
            // 
            // lblVleurCmide
            // 
            this.lblVleurCmide.AutoSize = true;
            this.lblVleurCmide.Location = new System.Drawing.Point(375, 77);
            this.lblVleurCmide.Name = "lblVleurCmide";
            this.lblVleurCmide.Size = new System.Drawing.Size(82, 13);
            this.lblVleurCmide.TabIndex = 155;
            this.lblVleurCmide.Text = "3 po, 1 pa, 5 pc";
            // 
            // lblVleurPntlonTle
            // 
            this.lblVleurPntlonTle.AutoSize = true;
            this.lblVleurPntlonTle.Location = new System.Drawing.Point(375, 52);
            this.lblVleurPntlonTle.Name = "lblVleurPntlonTle";
            this.lblVleurPntlonTle.Size = new System.Drawing.Size(55, 13);
            this.lblVleurPntlonTle.TabIndex = 154;
            this.lblVleurPntlonTle.Text = "8 pa, 5 pc";
            // 
            // lblVleurCuissrd
            // 
            this.lblVleurCuissrd.AutoSize = true;
            this.lblVleurCuissrd.Location = new System.Drawing.Point(375, 27);
            this.lblVleurCuissrd.Name = "lblVleurCuissrd";
            this.lblVleurCuissrd.Size = new System.Drawing.Size(82, 13);
            this.lblVleurCuissrd.TabIndex = 153;
            this.lblVleurCuissrd.Text = "5 po, 2 pa, 8 pc";
            // 
            // lblVleurGenouilleres
            // 
            this.lblVleurGenouilleres.AutoSize = true;
            this.lblVleurGenouilleres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurGenouilleres.Location = new System.Drawing.Point(375, 3);
            this.lblVleurGenouilleres.Name = "lblVleurGenouilleres";
            this.lblVleurGenouilleres.Size = new System.Drawing.Size(37, 13);
            this.lblVleurGenouilleres.TabIndex = 152;
            this.lblVleurGenouilleres.Text = "Valeur";
            // 
            // lblDescDeuxGenouilleres
            // 
            this.lblDescDeuxGenouilleres.AutoSize = true;
            this.lblDescDeuxGenouilleres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescDeuxGenouilleres.Location = new System.Drawing.Point(10, 140);
            this.lblDescDeuxGenouilleres.Name = "lblDescDeuxGenouilleres";
            this.lblDescDeuxGenouilleres.Size = new System.Drawing.Size(212, 13);
            this.lblDescDeuxGenouilleres.TabIndex = 148;
            this.lblDescDeuxGenouilleres.Text = "P-T : Protection Tout; P-R : Protection Rien";
            // 
            // lblDescGenouilleres
            // 
            this.lblDescGenouilleres.AutoSize = true;
            this.lblDescGenouilleres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescGenouilleres.Location = new System.Drawing.Point(10, 125);
            this.lblDescGenouilleres.Name = "lblDescGenouilleres";
            this.lblDescGenouilleres.Size = new System.Drawing.Size(556, 13);
            this.lblDescGenouilleres.TabIndex = 147;
            this.lblDescGenouilleres.Text = "P-AT : Protection Attaque Tranchante; P-AC : Protection Attaque Contondante; P-AP" +
    " : Protection Attaque Perforante";
            // 
            // chkCmide
            // 
            this.chkCmide.AutoSize = true;
            this.chkCmide.Location = new System.Drawing.Point(13, 77);
            this.chkCmide.Name = "chkCmide";
            this.chkCmide.Size = new System.Drawing.Size(15, 14);
            this.chkCmide.TabIndex = 101;
            this.chkCmide.UseVisualStyleBackColor = true;
            this.chkCmide.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkPntlonTle
            // 
            this.chkPntlonTle.AutoSize = true;
            this.chkPntlonTle.Location = new System.Drawing.Point(13, 52);
            this.chkPntlonTle.Name = "chkPntlonTle";
            this.chkPntlonTle.Size = new System.Drawing.Size(15, 14);
            this.chkPntlonTle.TabIndex = 100;
            this.chkPntlonTle.UseVisualStyleBackColor = true;
            this.chkPntlonTle.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkCuissrd
            // 
            this.chkCuissrd.AutoSize = true;
            this.chkCuissrd.Location = new System.Drawing.Point(13, 27);
            this.chkCuissrd.Name = "chkCuissrd";
            this.chkCuissrd.Size = new System.Drawing.Size(15, 14);
            this.chkCuissrd.TabIndex = 99;
            this.chkCuissrd.UseVisualStyleBackColor = true;
            this.chkCuissrd.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomCmide
            // 
            this.lblNomCmide.AutoSize = true;
            this.lblNomCmide.Location = new System.Drawing.Point(34, 77);
            this.lblNomCmide.Name = "lblNomCmide";
            this.lblNomCmide.Size = new System.Drawing.Size(48, 13);
            this.lblNomCmide.TabIndex = 89;
            this.lblNomCmide.Text = "Cnémide";
            // 
            // lblPdsCmide
            // 
            this.lblPdsCmide.AutoSize = true;
            this.lblPdsCmide.Location = new System.Drawing.Point(128, 77);
            this.lblPdsCmide.Name = "lblPdsCmide";
            this.lblPdsCmide.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCmide.TabIndex = 90;
            this.lblPdsCmide.Text = "1,2kg";
            // 
            // nudCmide
            // 
            this.nudCmide.Location = new System.Drawing.Point(200, 75);
            this.nudCmide.Name = "nudCmide";
            this.nudCmide.Size = new System.Drawing.Size(41, 20);
            this.nudCmide.TabIndex = 91;
            this.nudCmide.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCmide.ValueChanged += new System.EventHandler(this.nudCmide_ValueChanged);
            // 
            // lblEftsCmide
            // 
            this.lblEftsCmide.AutoSize = true;
            this.lblEftsCmide.Location = new System.Drawing.Point(266, 77);
            this.lblEftsCmide.Name = "lblEftsCmide";
            this.lblEftsCmide.Size = new System.Drawing.Size(48, 13);
            this.lblEftsCmide.TabIndex = 92;
            this.lblEftsCmide.Text = "P-T — +1";
            // 
            // lblNomPntlonTle
            // 
            this.lblNomPntlonTle.AutoSize = true;
            this.lblNomPntlonTle.Location = new System.Drawing.Point(34, 52);
            this.lblNomPntlonTle.Name = "lblNomPntlonTle";
            this.lblNomPntlonTle.Size = new System.Drawing.Size(86, 13);
            this.lblNomPntlonTle.TabIndex = 85;
            this.lblNomPntlonTle.Text = "Pantalon de toile";
            // 
            // lblPdsPntlonTle
            // 
            this.lblPdsPntlonTle.AutoSize = true;
            this.lblPdsPntlonTle.Location = new System.Drawing.Point(128, 52);
            this.lblPdsPntlonTle.Name = "lblPdsPntlonTle";
            this.lblPdsPntlonTle.Size = new System.Drawing.Size(34, 13);
            this.lblPdsPntlonTle.TabIndex = 86;
            this.lblPdsPntlonTle.Text = "0,5kg";
            // 
            // nudPntlonTle
            // 
            this.nudPntlonTle.Location = new System.Drawing.Point(200, 50);
            this.nudPntlonTle.Name = "nudPntlonTle";
            this.nudPntlonTle.Size = new System.Drawing.Size(41, 20);
            this.nudPntlonTle.TabIndex = 87;
            this.nudPntlonTle.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudPntlonTle.ValueChanged += new System.EventHandler(this.nudPntlonTle_ValueChanged);
            // 
            // lblEftsPntlonTle
            // 
            this.lblEftsPntlonTle.AutoSize = true;
            this.lblEftsPntlonTle.Location = new System.Drawing.Point(266, 52);
            this.lblEftsPntlonTle.Name = "lblEftsPntlonTle";
            this.lblEftsPntlonTle.Size = new System.Drawing.Size(25, 13);
            this.lblEftsPntlonTle.TabIndex = 88;
            this.lblEftsPntlonTle.Text = "P-R";
            // 
            // lblNomCuissrd
            // 
            this.lblNomCuissrd.AutoSize = true;
            this.lblNomCuissrd.Location = new System.Drawing.Point(34, 27);
            this.lblNomCuissrd.Name = "lblNomCuissrd";
            this.lblNomCuissrd.Size = new System.Drawing.Size(88, 13);
            this.lblNomCuissrd.TabIndex = 81;
            this.lblNomCuissrd.Text = "Cuissardes de fer";
            // 
            // lblPdsCuissrd
            // 
            this.lblPdsCuissrd.AutoSize = true;
            this.lblPdsCuissrd.Location = new System.Drawing.Point(128, 27);
            this.lblPdsCuissrd.Name = "lblPdsCuissrd";
            this.lblPdsCuissrd.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCuissrd.TabIndex = 82;
            this.lblPdsCuissrd.Text = "8,0kg";
            // 
            // nudCuissrd
            // 
            this.nudCuissrd.Location = new System.Drawing.Point(200, 25);
            this.nudCuissrd.Name = "nudCuissrd";
            this.nudCuissrd.Size = new System.Drawing.Size(41, 20);
            this.nudCuissrd.TabIndex = 83;
            this.nudCuissrd.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCuissrd.ValueChanged += new System.EventHandler(this.nudCuissrd_ValueChanged);
            // 
            // lblEftsCuissrd
            // 
            this.lblEftsCuissrd.AutoSize = true;
            this.lblEftsCuissrd.Location = new System.Drawing.Point(266, 27);
            this.lblEftsCuissrd.Name = "lblEftsCuissrd";
            this.lblEftsCuissrd.Size = new System.Drawing.Size(48, 13);
            this.lblEftsCuissrd.TabIndex = 84;
            this.lblEftsCuissrd.Text = "P-T — +2";
            // 
            // lblNomGenouilleres
            // 
            this.lblNomGenouilleres.AutoSize = true;
            this.lblNomGenouilleres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomGenouilleres.Location = new System.Drawing.Point(34, 3);
            this.lblNomGenouilleres.Name = "lblNomGenouilleres";
            this.lblNomGenouilleres.Size = new System.Drawing.Size(29, 13);
            this.lblNomGenouilleres.TabIndex = 77;
            this.lblNomGenouilleres.Text = "Nom";
            // 
            // lblPdsGenouilleres
            // 
            this.lblPdsGenouilleres.AutoSize = true;
            this.lblPdsGenouilleres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsGenouilleres.Location = new System.Drawing.Point(128, 3);
            this.lblPdsGenouilleres.Name = "lblPdsGenouilleres";
            this.lblPdsGenouilleres.Size = new System.Drawing.Size(33, 13);
            this.lblPdsGenouilleres.TabIndex = 78;
            this.lblPdsGenouilleres.Text = "Poids";
            // 
            // lblNbGenouilleres
            // 
            this.lblNbGenouilleres.AutoSize = true;
            this.lblNbGenouilleres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbGenouilleres.Location = new System.Drawing.Point(200, 3);
            this.lblNbGenouilleres.Name = "lblNbGenouilleres";
            this.lblNbGenouilleres.Size = new System.Drawing.Size(44, 13);
            this.lblNbGenouilleres.TabIndex = 79;
            this.lblNbGenouilleres.Text = "Nombre";
            // 
            // lblEftGenouilleres
            // 
            this.lblEftGenouilleres.AutoSize = true;
            this.lblEftGenouilleres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEftGenouilleres.Location = new System.Drawing.Point(266, 3);
            this.lblEftGenouilleres.Name = "lblEftGenouilleres";
            this.lblEftGenouilleres.Size = new System.Drawing.Size(34, 13);
            this.lblEftGenouilleres.TabIndex = 80;
            this.lblEftGenouilleres.Text = "Effets";
            // 
            // tpChaussures
            // 
            this.tpChaussures.AutoScroll = true;
            this.tpChaussures.Controls.Add(this.lblPrpieteSbton);
            this.tpChaussures.Controls.Add(this.lblVleurSbton);
            this.tpChaussures.Controls.Add(this.chkSbton);
            this.tpChaussures.Controls.Add(this.lblNomSbton);
            this.tpChaussures.Controls.Add(this.lblPdsSbton);
            this.tpChaussures.Controls.Add(this.nudSbton);
            this.tpChaussures.Controls.Add(this.lblEftsSbton);
            this.tpChaussures.Controls.Add(this.lblPrpieteChssuresCuir);
            this.tpChaussures.Controls.Add(this.lblPrpieteSndles);
            this.tpChaussures.Controls.Add(this.lblPrpieteChaussures);
            this.tpChaussures.Controls.Add(this.lblDescDeuxChaussures);
            this.tpChaussures.Controls.Add(this.lblDescChaussures);
            this.tpChaussures.Controls.Add(this.lblVleurChssuresCuir);
            this.tpChaussures.Controls.Add(this.lblVleurSndles);
            this.tpChaussures.Controls.Add(this.lblVleurChaussures);
            this.tpChaussures.Controls.Add(this.chkChssuresCuir);
            this.tpChaussures.Controls.Add(this.chkSndles);
            this.tpChaussures.Controls.Add(this.lblNomChssuresCuir);
            this.tpChaussures.Controls.Add(this.lblPdsChssuresCuir);
            this.tpChaussures.Controls.Add(this.nudChssuresCuir);
            this.tpChaussures.Controls.Add(this.lblEftsChssuresCuir);
            this.tpChaussures.Controls.Add(this.lblNomSndles);
            this.tpChaussures.Controls.Add(this.lblPdsSndles);
            this.tpChaussures.Controls.Add(this.nudSndles);
            this.tpChaussures.Controls.Add(this.lblEftsSndles);
            this.tpChaussures.Controls.Add(this.lblNomChssures);
            this.tpChaussures.Controls.Add(this.lblPdsChssures);
            this.tpChaussures.Controls.Add(this.lblNbChssures);
            this.tpChaussures.Controls.Add(this.lblEftsChssures);
            this.tpChaussures.Location = new System.Drawing.Point(4, 22);
            this.tpChaussures.Name = "tpChaussures";
            this.tpChaussures.Size = new System.Drawing.Size(689, 220);
            this.tpChaussures.TabIndex = 4;
            this.tpChaussures.Text = "Chaussures";
            this.tpChaussures.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteSbton
            // 
            this.lblPrpieteSbton.AutoSize = true;
            this.lblPrpieteSbton.Location = new System.Drawing.Point(475, 77);
            this.lblPrpieteSbton.Name = "lblPrpieteSbton";
            this.lblPrpieteSbton.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteSbton.TabIndex = 170;
            this.lblPrpieteSbton.Text = "Aucune";
            // 
            // lblVleurSbton
            // 
            this.lblVleurSbton.AutoSize = true;
            this.lblVleurSbton.Location = new System.Drawing.Point(375, 77);
            this.lblVleurSbton.Name = "lblVleurSbton";
            this.lblVleurSbton.Size = new System.Drawing.Size(55, 13);
            this.lblVleurSbton.TabIndex = 169;
            this.lblVleurSbton.Text = "2 po, 5 pa";
            // 
            // chkSbton
            // 
            this.chkSbton.AutoSize = true;
            this.chkSbton.Location = new System.Drawing.Point(13, 77);
            this.chkSbton.Name = "chkSbton";
            this.chkSbton.Size = new System.Drawing.Size(15, 14);
            this.chkSbton.TabIndex = 168;
            this.chkSbton.UseVisualStyleBackColor = true;
            this.chkSbton.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomSbton
            // 
            this.lblNomSbton.AutoSize = true;
            this.lblNomSbton.Location = new System.Drawing.Point(34, 77);
            this.lblNomSbton.Name = "lblNomSbton";
            this.lblNomSbton.Size = new System.Drawing.Size(52, 13);
            this.lblNomSbton.TabIndex = 164;
            this.lblNomSbton.Text = "Sabatons";
            // 
            // lblPdsSbton
            // 
            this.lblPdsSbton.AutoSize = true;
            this.lblPdsSbton.Location = new System.Drawing.Point(128, 77);
            this.lblPdsSbton.Name = "lblPdsSbton";
            this.lblPdsSbton.Size = new System.Drawing.Size(34, 13);
            this.lblPdsSbton.TabIndex = 165;
            this.lblPdsSbton.Text = "1,2kg";
            // 
            // nudSbton
            // 
            this.nudSbton.Location = new System.Drawing.Point(200, 77);
            this.nudSbton.Name = "nudSbton";
            this.nudSbton.Size = new System.Drawing.Size(41, 20);
            this.nudSbton.TabIndex = 166;
            this.nudSbton.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSbton.ValueChanged += new System.EventHandler(this.nudSbton_ValueChanged);
            // 
            // lblEftsSbton
            // 
            this.lblEftsSbton.AutoSize = true;
            this.lblEftsSbton.Location = new System.Drawing.Point(266, 77);
            this.lblEftsSbton.Name = "lblEftsSbton";
            this.lblEftsSbton.Size = new System.Drawing.Size(85, 13);
            this.lblEftsSbton.TabIndex = 167;
            this.lblEftsSbton.Text = "P-AT, P-AP — +2";
            // 
            // lblPrpieteChssuresCuir
            // 
            this.lblPrpieteChssuresCuir.AutoSize = true;
            this.lblPrpieteChssuresCuir.Location = new System.Drawing.Point(475, 52);
            this.lblPrpieteChssuresCuir.Name = "lblPrpieteChssuresCuir";
            this.lblPrpieteChssuresCuir.Size = new System.Drawing.Size(111, 13);
            this.lblPrpieteChssuresCuir.TabIndex = 163;
            this.lblPrpieteChssuresCuir.Text = "On est à l\'aise dedans";
            // 
            // lblPrpieteSndles
            // 
            this.lblPrpieteSndles.AutoSize = true;
            this.lblPrpieteSndles.Location = new System.Drawing.Point(475, 27);
            this.lblPrpieteSndles.Name = "lblPrpieteSndles";
            this.lblPrpieteSndles.Size = new System.Drawing.Size(216, 13);
            this.lblPrpieteSndles.TabIndex = 162;
            this.lblPrpieteSndles.Text = "Peuvent se casser si elles prennent un coup";
            // 
            // lblPrpieteChaussures
            // 
            this.lblPrpieteChaussures.AutoSize = true;
            this.lblPrpieteChaussures.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteChaussures.Location = new System.Drawing.Point(475, 3);
            this.lblPrpieteChaussures.Name = "lblPrpieteChaussures";
            this.lblPrpieteChaussures.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteChaussures.TabIndex = 161;
            this.lblPrpieteChaussures.Text = "Propriété";
            // 
            // lblDescDeuxChaussures
            // 
            this.lblDescDeuxChaussures.AutoSize = true;
            this.lblDescDeuxChaussures.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescDeuxChaussures.Location = new System.Drawing.Point(10, 125);
            this.lblDescDeuxChaussures.Name = "lblDescDeuxChaussures";
            this.lblDescDeuxChaussures.Size = new System.Drawing.Size(212, 13);
            this.lblDescDeuxChaussures.TabIndex = 160;
            this.lblDescDeuxChaussures.Text = "P-T : Protection Tout; P-R : Protection Rien";
            // 
            // lblDescChaussures
            // 
            this.lblDescChaussures.AutoSize = true;
            this.lblDescChaussures.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescChaussures.Location = new System.Drawing.Point(10, 110);
            this.lblDescChaussures.Name = "lblDescChaussures";
            this.lblDescChaussures.Size = new System.Drawing.Size(556, 13);
            this.lblDescChaussures.TabIndex = 159;
            this.lblDescChaussures.Text = "P-AT : Protection Attaque Tranchante; P-AC : Protection Attaque Contondante; P-AP" +
    " : Protection Attaque Perforante";
            // 
            // lblVleurChssuresCuir
            // 
            this.lblVleurChssuresCuir.AutoSize = true;
            this.lblVleurChssuresCuir.Location = new System.Drawing.Point(375, 52);
            this.lblVleurChssuresCuir.Name = "lblVleurChssuresCuir";
            this.lblVleurChssuresCuir.Size = new System.Drawing.Size(28, 13);
            this.lblVleurChssuresCuir.TabIndex = 158;
            this.lblVleurChssuresCuir.Text = "5 pa";
            // 
            // lblVleurSndles
            // 
            this.lblVleurSndles.AutoSize = true;
            this.lblVleurSndles.Location = new System.Drawing.Point(375, 27);
            this.lblVleurSndles.Name = "lblVleurSndles";
            this.lblVleurSndles.Size = new System.Drawing.Size(55, 13);
            this.lblVleurSndles.TabIndex = 157;
            this.lblVleurSndles.Text = "4 pa, 5 pc";
            // 
            // lblVleurChaussures
            // 
            this.lblVleurChaussures.AutoSize = true;
            this.lblVleurChaussures.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurChaussures.Location = new System.Drawing.Point(375, 3);
            this.lblVleurChaussures.Name = "lblVleurChaussures";
            this.lblVleurChaussures.Size = new System.Drawing.Size(37, 13);
            this.lblVleurChaussures.TabIndex = 156;
            this.lblVleurChaussures.Text = "Valeur";
            // 
            // chkChssuresCuir
            // 
            this.chkChssuresCuir.AutoSize = true;
            this.chkChssuresCuir.Location = new System.Drawing.Point(13, 52);
            this.chkChssuresCuir.Name = "chkChssuresCuir";
            this.chkChssuresCuir.Size = new System.Drawing.Size(15, 14);
            this.chkChssuresCuir.TabIndex = 101;
            this.chkChssuresCuir.UseVisualStyleBackColor = true;
            this.chkChssuresCuir.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkSndles
            // 
            this.chkSndles.AutoSize = true;
            this.chkSndles.Location = new System.Drawing.Point(13, 27);
            this.chkSndles.Name = "chkSndles";
            this.chkSndles.Size = new System.Drawing.Size(15, 14);
            this.chkSndles.TabIndex = 100;
            this.chkSndles.UseVisualStyleBackColor = true;
            this.chkSndles.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomChssuresCuir
            // 
            this.lblNomChssuresCuir.AutoSize = true;
            this.lblNomChssuresCuir.Location = new System.Drawing.Point(34, 52);
            this.lblNomChssuresCuir.Name = "lblNomChssuresCuir";
            this.lblNomChssuresCuir.Size = new System.Drawing.Size(97, 13);
            this.lblNomChssuresCuir.TabIndex = 93;
            this.lblNomChssuresCuir.Text = "Chaussures de cuir";
            // 
            // lblPdsChssuresCuir
            // 
            this.lblPdsChssuresCuir.AutoSize = true;
            this.lblPdsChssuresCuir.Location = new System.Drawing.Point(128, 52);
            this.lblPdsChssuresCuir.Name = "lblPdsChssuresCuir";
            this.lblPdsChssuresCuir.Size = new System.Drawing.Size(34, 13);
            this.lblPdsChssuresCuir.TabIndex = 94;
            this.lblPdsChssuresCuir.Text = "1,0kg";
            // 
            // nudChssuresCuir
            // 
            this.nudChssuresCuir.Location = new System.Drawing.Point(200, 50);
            this.nudChssuresCuir.Name = "nudChssuresCuir";
            this.nudChssuresCuir.Size = new System.Drawing.Size(41, 20);
            this.nudChssuresCuir.TabIndex = 95;
            this.nudChssuresCuir.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudChssuresCuir.ValueChanged += new System.EventHandler(this.nudChssuresCuir_ValueChanged);
            // 
            // lblEftsChssuresCuir
            // 
            this.lblEftsChssuresCuir.AutoSize = true;
            this.lblEftsChssuresCuir.Location = new System.Drawing.Point(266, 52);
            this.lblEftsChssuresCuir.Name = "lblEftsChssuresCuir";
            this.lblEftsChssuresCuir.Size = new System.Drawing.Size(25, 13);
            this.lblEftsChssuresCuir.TabIndex = 96;
            this.lblEftsChssuresCuir.Text = "P-R";
            // 
            // lblNomSndles
            // 
            this.lblNomSndles.AutoSize = true;
            this.lblNomSndles.Location = new System.Drawing.Point(34, 27);
            this.lblNomSndles.Name = "lblNomSndles";
            this.lblNomSndles.Size = new System.Drawing.Size(51, 13);
            this.lblNomSndles.TabIndex = 89;
            this.lblNomSndles.Text = "Sandales";
            // 
            // lblPdsSndles
            // 
            this.lblPdsSndles.AutoSize = true;
            this.lblPdsSndles.Location = new System.Drawing.Point(128, 27);
            this.lblPdsSndles.Name = "lblPdsSndles";
            this.lblPdsSndles.Size = new System.Drawing.Size(40, 13);
            this.lblPdsSndles.TabIndex = 90;
            this.lblPdsSndles.Text = "0,26kg";
            // 
            // nudSndles
            // 
            this.nudSndles.Location = new System.Drawing.Point(200, 25);
            this.nudSndles.Name = "nudSndles";
            this.nudSndles.Size = new System.Drawing.Size(41, 20);
            this.nudSndles.TabIndex = 91;
            this.nudSndles.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSndles.ValueChanged += new System.EventHandler(this.nudSndles_ValueChanged);
            // 
            // lblEftsSndles
            // 
            this.lblEftsSndles.AutoSize = true;
            this.lblEftsSndles.Location = new System.Drawing.Point(266, 27);
            this.lblEftsSndles.Name = "lblEftsSndles";
            this.lblEftsSndles.Size = new System.Drawing.Size(25, 13);
            this.lblEftsSndles.TabIndex = 92;
            this.lblEftsSndles.Text = "P-R";
            // 
            // lblNomChssures
            // 
            this.lblNomChssures.AutoSize = true;
            this.lblNomChssures.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomChssures.Location = new System.Drawing.Point(34, 3);
            this.lblNomChssures.Name = "lblNomChssures";
            this.lblNomChssures.Size = new System.Drawing.Size(29, 13);
            this.lblNomChssures.TabIndex = 85;
            this.lblNomChssures.Text = "Nom";
            // 
            // lblPdsChssures
            // 
            this.lblPdsChssures.AutoSize = true;
            this.lblPdsChssures.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsChssures.Location = new System.Drawing.Point(128, 3);
            this.lblPdsChssures.Name = "lblPdsChssures";
            this.lblPdsChssures.Size = new System.Drawing.Size(33, 13);
            this.lblPdsChssures.TabIndex = 86;
            this.lblPdsChssures.Text = "Poids";
            // 
            // lblNbChssures
            // 
            this.lblNbChssures.AutoSize = true;
            this.lblNbChssures.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbChssures.Location = new System.Drawing.Point(200, 3);
            this.lblNbChssures.Name = "lblNbChssures";
            this.lblNbChssures.Size = new System.Drawing.Size(44, 13);
            this.lblNbChssures.TabIndex = 87;
            this.lblNbChssures.Text = "Nombre";
            // 
            // lblEftsChssures
            // 
            this.lblEftsChssures.AutoSize = true;
            this.lblEftsChssures.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEftsChssures.Location = new System.Drawing.Point(266, 3);
            this.lblEftsChssures.Name = "lblEftsChssures";
            this.lblEftsChssures.Size = new System.Drawing.Size(34, 13);
            this.lblEftsChssures.TabIndex = 88;
            this.lblEftsChssures.Text = "Effets";
            // 
            // tpBouclier
            // 
            this.tpBouclier.AutoScroll = true;
            this.tpBouclier.Controls.Add(this.lblPrpieteCpeElfique);
            this.tpBouclier.Controls.Add(this.lblVleurCpeElfique);
            this.tpBouclier.Controls.Add(this.chkCpeElfique);
            this.tpBouclier.Controls.Add(this.lblNomCpeElfique);
            this.tpBouclier.Controls.Add(this.lblPdsCpeElfique);
            this.tpBouclier.Controls.Add(this.nudCpeElfique);
            this.tpBouclier.Controls.Add(this.lblEftsCpeElfique);
            this.tpBouclier.Controls.Add(this.lblPrpietePlta);
            this.tpBouclier.Controls.Add(this.lblPrpieteBclrBze);
            this.tpBouclier.Controls.Add(this.lblPrpieteBclrAmde);
            this.tpBouclier.Controls.Add(this.lblPrpietePvois);
            this.tpBouclier.Controls.Add(this.lblPrpieteEcu);
            this.tpBouclier.Controls.Add(this.lblPrpieteBoucliers);
            this.tpBouclier.Controls.Add(this.lblVleurPlta);
            this.tpBouclier.Controls.Add(this.lblVleurBclrBze);
            this.tpBouclier.Controls.Add(this.lblVleurBclrAmde);
            this.tpBouclier.Controls.Add(this.lblVleurPvois);
            this.tpBouclier.Controls.Add(this.lblVleurEcu);
            this.tpBouclier.Controls.Add(this.lblVleurBouclier);
            this.tpBouclier.Controls.Add(this.lblDescDeuxBoucliers);
            this.tpBouclier.Controls.Add(this.chkPlta);
            this.tpBouclier.Controls.Add(this.chkBclrBze);
            this.tpBouclier.Controls.Add(this.chkBclrAmde);
            this.tpBouclier.Controls.Add(this.chkPvois);
            this.tpBouclier.Controls.Add(this.chkEcu);
            this.tpBouclier.Controls.Add(this.lblNomPlta);
            this.tpBouclier.Controls.Add(this.lblPdsPlta);
            this.tpBouclier.Controls.Add(this.nudPlta);
            this.tpBouclier.Controls.Add(this.lblEftsPlta);
            this.tpBouclier.Controls.Add(this.lblNomBclrBze);
            this.tpBouclier.Controls.Add(this.lblPdsBclrBze);
            this.tpBouclier.Controls.Add(this.nudBclrBze);
            this.tpBouclier.Controls.Add(this.lblEftsBclrBze);
            this.tpBouclier.Controls.Add(this.lblNomBclrAmde);
            this.tpBouclier.Controls.Add(this.lblPdsBclrAmde);
            this.tpBouclier.Controls.Add(this.nudBclrAmde);
            this.tpBouclier.Controls.Add(this.lblEftsBclrAmde);
            this.tpBouclier.Controls.Add(this.lblNomPvois);
            this.tpBouclier.Controls.Add(this.lblPdsPvois);
            this.tpBouclier.Controls.Add(this.nudPvois);
            this.tpBouclier.Controls.Add(this.lblEftsPvois);
            this.tpBouclier.Controls.Add(this.lblNomEcu);
            this.tpBouclier.Controls.Add(this.lblPdsEcu);
            this.tpBouclier.Controls.Add(this.nudEcu);
            this.tpBouclier.Controls.Add(this.lblEftsEcu);
            this.tpBouclier.Controls.Add(this.lblNomBoucliers);
            this.tpBouclier.Controls.Add(this.lblPdsBoucliers);
            this.tpBouclier.Controls.Add(this.lblNbBoucliers);
            this.tpBouclier.Controls.Add(this.lblEftsBoucliers);
            this.tpBouclier.Location = new System.Drawing.Point(4, 22);
            this.tpBouclier.Name = "tpBouclier";
            this.tpBouclier.Size = new System.Drawing.Size(689, 220);
            this.tpBouclier.TabIndex = 5;
            this.tpBouclier.Text = "Bouclier";
            this.tpBouclier.UseVisualStyleBackColor = true;
            // 
            // lblPrpieteCpeElfique
            // 
            this.lblPrpieteCpeElfique.AutoSize = true;
            this.lblPrpieteCpeElfique.Location = new System.Drawing.Point(542, 153);
            this.lblPrpieteCpeElfique.Name = "lblPrpieteCpeElfique";
            this.lblPrpieteCpeElfique.Size = new System.Drawing.Size(208, 13);
            this.lblPrpieteCpeElfique.TabIndex = 181;
            this.lblPrpieteCpeElfique.Text = "Cape enchantée par des runes, très légère";
            // 
            // lblVleurCpeElfique
            // 
            this.lblVleurCpeElfique.AutoSize = true;
            this.lblVleurCpeElfique.Location = new System.Drawing.Point(425, 153);
            this.lblVleurCpeElfique.Name = "lblVleurCpeElfique";
            this.lblVleurCpeElfique.Size = new System.Drawing.Size(61, 13);
            this.lblVleurCpeElfique.TabIndex = 180;
            this.lblVleurCpeElfique.Text = "21 po, 9 pa";
            // 
            // chkCpeElfique
            // 
            this.chkCpeElfique.AutoSize = true;
            this.chkCpeElfique.Location = new System.Drawing.Point(13, 153);
            this.chkCpeElfique.Name = "chkCpeElfique";
            this.chkCpeElfique.Size = new System.Drawing.Size(15, 14);
            this.chkCpeElfique.TabIndex = 179;
            this.chkCpeElfique.UseVisualStyleBackColor = true;
            this.chkCpeElfique.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomCpeElfique
            // 
            this.lblNomCpeElfique.AutoSize = true;
            this.lblNomCpeElfique.Location = new System.Drawing.Point(34, 154);
            this.lblNomCpeElfique.Name = "lblNomCpeElfique";
            this.lblNomCpeElfique.Size = new System.Drawing.Size(66, 13);
            this.lblNomCpeElfique.TabIndex = 175;
            this.lblNomCpeElfique.Text = "Cape elfique";
            // 
            // lblPdsCpeElfique
            // 
            this.lblPdsCpeElfique.AutoSize = true;
            this.lblPdsCpeElfique.Location = new System.Drawing.Point(156, 153);
            this.lblPdsCpeElfique.Name = "lblPdsCpeElfique";
            this.lblPdsCpeElfique.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCpeElfique.TabIndex = 176;
            this.lblPdsCpeElfique.Text = "0.2kg";
            // 
            // nudCpeElfique
            // 
            this.nudCpeElfique.Location = new System.Drawing.Point(266, 151);
            this.nudCpeElfique.Name = "nudCpeElfique";
            this.nudCpeElfique.Size = new System.Drawing.Size(41, 20);
            this.nudCpeElfique.TabIndex = 177;
            this.nudCpeElfique.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCpeElfique.ValueChanged += new System.EventHandler(this.nudCpeElfique_ValueChanged);
            // 
            // lblEftsCpeElfique
            // 
            this.lblEftsCpeElfique.AutoSize = true;
            this.lblEftsCpeElfique.Location = new System.Drawing.Point(325, 153);
            this.lblEftsCpeElfique.Name = "lblEftsCpeElfique";
            this.lblEftsCpeElfique.Size = new System.Drawing.Size(80, 13);
            this.lblEftsCpeElfique.TabIndex = 178;
            this.lblEftsCpeElfique.Text = "Suprt — 7 dégât";
            // 
            // lblPrpietePlta
            // 
            this.lblPrpietePlta.AutoSize = true;
            this.lblPrpietePlta.Location = new System.Drawing.Point(542, 127);
            this.lblPrpietePlta.Name = "lblPrpietePlta";
            this.lblPrpietePlta.Size = new System.Drawing.Size(44, 13);
            this.lblPrpietePlta.TabIndex = 174;
            this.lblPrpietePlta.Text = "Aucune";
            // 
            // lblPrpieteBclrBze
            // 
            this.lblPrpieteBclrBze.AutoSize = true;
            this.lblPrpieteBclrBze.Location = new System.Drawing.Point(542, 102);
            this.lblPrpieteBclrBze.Name = "lblPrpieteBclrBze";
            this.lblPrpieteBclrBze.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteBclrBze.TabIndex = 173;
            this.lblPrpieteBclrBze.Text = "Aucune";
            // 
            // lblPrpieteBclrAmde
            // 
            this.lblPrpieteBclrAmde.AutoSize = true;
            this.lblPrpieteBclrAmde.Location = new System.Drawing.Point(542, 77);
            this.lblPrpieteBclrAmde.Name = "lblPrpieteBclrAmde";
            this.lblPrpieteBclrAmde.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteBclrAmde.TabIndex = 172;
            this.lblPrpieteBclrAmde.Text = "Aucune";
            // 
            // lblPrpietePvois
            // 
            this.lblPrpietePvois.AutoSize = true;
            this.lblPrpietePvois.Location = new System.Drawing.Point(542, 52);
            this.lblPrpietePvois.Name = "lblPrpietePvois";
            this.lblPrpietePvois.Size = new System.Drawing.Size(146, 13);
            this.lblPrpietePvois.TabIndex = 171;
            this.lblPrpietePvois.Text = "Impossible de bouger si utilisé";
            // 
            // lblPrpieteEcu
            // 
            this.lblPrpieteEcu.AutoSize = true;
            this.lblPrpieteEcu.Location = new System.Drawing.Point(542, 27);
            this.lblPrpieteEcu.Name = "lblPrpieteEcu";
            this.lblPrpieteEcu.Size = new System.Drawing.Size(44, 13);
            this.lblPrpieteEcu.TabIndex = 170;
            this.lblPrpieteEcu.Text = "Aucune";
            // 
            // lblPrpieteBoucliers
            // 
            this.lblPrpieteBoucliers.AutoSize = true;
            this.lblPrpieteBoucliers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrpieteBoucliers.Location = new System.Drawing.Point(542, 3);
            this.lblPrpieteBoucliers.Name = "lblPrpieteBoucliers";
            this.lblPrpieteBoucliers.Size = new System.Drawing.Size(49, 13);
            this.lblPrpieteBoucliers.TabIndex = 169;
            this.lblPrpieteBoucliers.Text = "Propriété";
            // 
            // lblVleurPlta
            // 
            this.lblVleurPlta.AutoSize = true;
            this.lblVleurPlta.Location = new System.Drawing.Point(425, 127);
            this.lblVleurPlta.Name = "lblVleurPlta";
            this.lblVleurPlta.Size = new System.Drawing.Size(55, 13);
            this.lblVleurPlta.TabIndex = 168;
            this.lblVleurPlta.Text = "2 po, 2 pa";
            // 
            // lblVleurBclrBze
            // 
            this.lblVleurBclrBze.AutoSize = true;
            this.lblVleurBclrBze.Location = new System.Drawing.Point(425, 102);
            this.lblVleurBclrBze.Name = "lblVleurBclrBze";
            this.lblVleurBclrBze.Size = new System.Drawing.Size(82, 13);
            this.lblVleurBclrBze.TabIndex = 167;
            this.lblVleurBclrBze.Text = "3 po, 1 pa, 5 pc";
            // 
            // lblVleurBclrAmde
            // 
            this.lblVleurBclrAmde.AutoSize = true;
            this.lblVleurBclrAmde.Location = new System.Drawing.Point(425, 77);
            this.lblVleurBclrAmde.Name = "lblVleurBclrAmde";
            this.lblVleurBclrAmde.Size = new System.Drawing.Size(82, 13);
            this.lblVleurBclrAmde.TabIndex = 166;
            this.lblVleurBclrAmde.Text = "2 po, 6 pa, 4 pc";
            // 
            // lblVleurPvois
            // 
            this.lblVleurPvois.AutoSize = true;
            this.lblVleurPvois.Location = new System.Drawing.Point(425, 52);
            this.lblVleurPvois.Name = "lblVleurPvois";
            this.lblVleurPvois.Size = new System.Drawing.Size(82, 13);
            this.lblVleurPvois.TabIndex = 165;
            this.lblVleurPvois.Text = "6 po, 6 pa, 8 pc";
            // 
            // lblVleurEcu
            // 
            this.lblVleurEcu.AutoSize = true;
            this.lblVleurEcu.Location = new System.Drawing.Point(425, 27);
            this.lblVleurEcu.Name = "lblVleurEcu";
            this.lblVleurEcu.Size = new System.Drawing.Size(55, 13);
            this.lblVleurEcu.TabIndex = 164;
            this.lblVleurEcu.Text = "2 po, 4 pa";
            // 
            // lblVleurBouclier
            // 
            this.lblVleurBouclier.AutoSize = true;
            this.lblVleurBouclier.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurBouclier.Location = new System.Drawing.Point(425, 3);
            this.lblVleurBouclier.Name = "lblVleurBouclier";
            this.lblVleurBouclier.Size = new System.Drawing.Size(37, 13);
            this.lblVleurBouclier.TabIndex = 163;
            this.lblVleurBouclier.Text = "Valeur";
            // 
            // lblDescDeuxBoucliers
            // 
            this.lblDescDeuxBoucliers.AutoSize = true;
            this.lblDescDeuxBoucliers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescDeuxBoucliers.Location = new System.Drawing.Point(9, 176);
            this.lblDescDeuxBoucliers.Name = "lblDescDeuxBoucliers";
            this.lblDescDeuxBoucliers.Size = new System.Drawing.Size(120, 13);
            this.lblDescDeuxBoucliers.TabIndex = 162;
            this.lblDescDeuxBoucliers.Text = "Suprt : Supporte jusqu\'à";
            // 
            // chkPlta
            // 
            this.chkPlta.AutoSize = true;
            this.chkPlta.Location = new System.Drawing.Point(13, 127);
            this.chkPlta.Name = "chkPlta";
            this.chkPlta.Size = new System.Drawing.Size(15, 14);
            this.chkPlta.TabIndex = 109;
            this.chkPlta.UseVisualStyleBackColor = true;
            this.chkPlta.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkBclrBze
            // 
            this.chkBclrBze.AutoSize = true;
            this.chkBclrBze.Location = new System.Drawing.Point(13, 102);
            this.chkBclrBze.Name = "chkBclrBze";
            this.chkBclrBze.Size = new System.Drawing.Size(15, 14);
            this.chkBclrBze.TabIndex = 108;
            this.chkBclrBze.UseVisualStyleBackColor = true;
            this.chkBclrBze.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkBclrAmde
            // 
            this.chkBclrAmde.AutoSize = true;
            this.chkBclrAmde.Location = new System.Drawing.Point(13, 77);
            this.chkBclrAmde.Name = "chkBclrAmde";
            this.chkBclrAmde.Size = new System.Drawing.Size(15, 14);
            this.chkBclrAmde.TabIndex = 107;
            this.chkBclrAmde.UseVisualStyleBackColor = true;
            this.chkBclrAmde.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkPvois
            // 
            this.chkPvois.AutoSize = true;
            this.chkPvois.Location = new System.Drawing.Point(13, 52);
            this.chkPvois.Name = "chkPvois";
            this.chkPvois.Size = new System.Drawing.Size(15, 14);
            this.chkPvois.TabIndex = 106;
            this.chkPvois.UseVisualStyleBackColor = true;
            this.chkPvois.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkEcu
            // 
            this.chkEcu.AutoSize = true;
            this.chkEcu.Location = new System.Drawing.Point(13, 27);
            this.chkEcu.Name = "chkEcu";
            this.chkEcu.Size = new System.Drawing.Size(15, 14);
            this.chkEcu.TabIndex = 105;
            this.chkEcu.UseVisualStyleBackColor = true;
            this.chkEcu.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblNomPlta
            // 
            this.lblNomPlta.AutoSize = true;
            this.lblNomPlta.Location = new System.Drawing.Point(34, 128);
            this.lblNomPlta.Name = "lblNomPlta";
            this.lblNomPlta.Size = new System.Drawing.Size(31, 13);
            this.lblNomPlta.TabIndex = 101;
            this.lblNomPlta.Text = "Pelta";
            // 
            // lblPdsPlta
            // 
            this.lblPdsPlta.AutoSize = true;
            this.lblPdsPlta.Location = new System.Drawing.Point(156, 127);
            this.lblPdsPlta.Name = "lblPdsPlta";
            this.lblPdsPlta.Size = new System.Drawing.Size(34, 13);
            this.lblPdsPlta.TabIndex = 102;
            this.lblPdsPlta.Text = "1,4kg";
            // 
            // nudPlta
            // 
            this.nudPlta.Location = new System.Drawing.Point(266, 125);
            this.nudPlta.Name = "nudPlta";
            this.nudPlta.Size = new System.Drawing.Size(41, 20);
            this.nudPlta.TabIndex = 103;
            this.nudPlta.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudPlta.ValueChanged += new System.EventHandler(this.nudPlta_ValueChanged);
            // 
            // lblEftsPlta
            // 
            this.lblEftsPlta.AutoSize = true;
            this.lblEftsPlta.Location = new System.Drawing.Point(325, 127);
            this.lblEftsPlta.Name = "lblEftsPlta";
            this.lblEftsPlta.Size = new System.Drawing.Size(80, 13);
            this.lblEftsPlta.TabIndex = 104;
            this.lblEftsPlta.Text = "Suprt — 1 dégât";
            // 
            // lblNomBclrBze
            // 
            this.lblNomBclrBze.AutoSize = true;
            this.lblNomBclrBze.Location = new System.Drawing.Point(34, 102);
            this.lblNomBclrBze.Name = "lblNomBclrBze";
            this.lblNomBclrBze.Size = new System.Drawing.Size(95, 13);
            this.lblNomBclrBze.TabIndex = 97;
            this.lblNomBclrBze.Text = "Bouclier de bronze";
            // 
            // lblPdsBclrBze
            // 
            this.lblPdsBclrBze.AutoSize = true;
            this.lblPdsBclrBze.Location = new System.Drawing.Point(156, 102);
            this.lblPdsBclrBze.Name = "lblPdsBclrBze";
            this.lblPdsBclrBze.Size = new System.Drawing.Size(34, 13);
            this.lblPdsBclrBze.TabIndex = 98;
            this.lblPdsBclrBze.Text = "1,9kg";
            // 
            // nudBclrBze
            // 
            this.nudBclrBze.Location = new System.Drawing.Point(266, 100);
            this.nudBclrBze.Name = "nudBclrBze";
            this.nudBclrBze.Size = new System.Drawing.Size(41, 20);
            this.nudBclrBze.TabIndex = 99;
            this.nudBclrBze.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBclrBze.ValueChanged += new System.EventHandler(this.nudBclrBze_ValueChanged);
            // 
            // lblEftsBclrBze
            // 
            this.lblEftsBclrBze.AutoSize = true;
            this.lblEftsBclrBze.Location = new System.Drawing.Point(325, 102);
            this.lblEftsBclrBze.Name = "lblEftsBclrBze";
            this.lblEftsBclrBze.Size = new System.Drawing.Size(85, 13);
            this.lblEftsBclrBze.TabIndex = 100;
            this.lblEftsBclrBze.Text = "Suprt — 4 dégâts";
            // 
            // lblNomBclrAmde
            // 
            this.lblNomBclrAmde.AutoSize = true;
            this.lblNomBclrAmde.Location = new System.Drawing.Point(34, 77);
            this.lblNomBclrAmde.Name = "lblNomBclrAmde";
            this.lblNomBclrAmde.Size = new System.Drawing.Size(101, 13);
            this.lblNomBclrAmde.TabIndex = 93;
            this.lblNomBclrAmde.Text = "Bouclier en amande";
            // 
            // lblPdsBclrAmde
            // 
            this.lblPdsBclrAmde.AutoSize = true;
            this.lblPdsBclrAmde.Location = new System.Drawing.Point(156, 77);
            this.lblPdsBclrAmde.Name = "lblPdsBclrAmde";
            this.lblPdsBclrAmde.Size = new System.Drawing.Size(34, 13);
            this.lblPdsBclrAmde.TabIndex = 94;
            this.lblPdsBclrAmde.Text = "2,1kg";
            // 
            // nudBclrAmde
            // 
            this.nudBclrAmde.Location = new System.Drawing.Point(266, 75);
            this.nudBclrAmde.Name = "nudBclrAmde";
            this.nudBclrAmde.Size = new System.Drawing.Size(41, 20);
            this.nudBclrAmde.TabIndex = 95;
            this.nudBclrAmde.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBclrAmde.ValueChanged += new System.EventHandler(this.nudBclrAmde_ValueChanged);
            // 
            // lblEftsBclrAmde
            // 
            this.lblEftsBclrAmde.AutoSize = true;
            this.lblEftsBclrAmde.Location = new System.Drawing.Point(325, 77);
            this.lblEftsBclrAmde.Name = "lblEftsBclrAmde";
            this.lblEftsBclrAmde.Size = new System.Drawing.Size(85, 13);
            this.lblEftsBclrAmde.TabIndex = 96;
            this.lblEftsBclrAmde.Text = "Suprt — 5 dégâts";
            // 
            // lblNomPvois
            // 
            this.lblNomPvois.AutoSize = true;
            this.lblNomPvois.Location = new System.Drawing.Point(34, 52);
            this.lblNomPvois.Name = "lblNomPvois";
            this.lblNomPvois.Size = new System.Drawing.Size(39, 13);
            this.lblNomPvois.TabIndex = 89;
            this.lblNomPvois.Text = "Pavois";
            // 
            // lblPdsPvois
            // 
            this.lblPdsPvois.AutoSize = true;
            this.lblPdsPvois.Location = new System.Drawing.Point(156, 52);
            this.lblPdsPvois.Name = "lblPdsPvois";
            this.lblPdsPvois.Size = new System.Drawing.Size(40, 13);
            this.lblPdsPvois.TabIndex = 90;
            this.lblPdsPvois.Text = "11,2kg";
            // 
            // nudPvois
            // 
            this.nudPvois.Location = new System.Drawing.Point(266, 50);
            this.nudPvois.Name = "nudPvois";
            this.nudPvois.Size = new System.Drawing.Size(41, 20);
            this.nudPvois.TabIndex = 91;
            this.nudPvois.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudPvois.ValueChanged += new System.EventHandler(this.nudPvois_ValueChanged);
            // 
            // lblEftsPvois
            // 
            this.lblEftsPvois.AutoSize = true;
            this.lblEftsPvois.Location = new System.Drawing.Point(325, 52);
            this.lblEftsPvois.Name = "lblEftsPvois";
            this.lblEftsPvois.Size = new System.Drawing.Size(91, 13);
            this.lblEftsPvois.TabIndex = 92;
            this.lblEftsPvois.Text = "Suprt — 15 dégâts";
            // 
            // lblNomEcu
            // 
            this.lblNomEcu.AutoSize = true;
            this.lblNomEcu.Location = new System.Drawing.Point(34, 27);
            this.lblNomEcu.Name = "lblNomEcu";
            this.lblNomEcu.Size = new System.Drawing.Size(26, 13);
            this.lblNomEcu.TabIndex = 85;
            this.lblNomEcu.Text = "Écu";
            // 
            // lblPdsEcu
            // 
            this.lblPdsEcu.AutoSize = true;
            this.lblPdsEcu.Location = new System.Drawing.Point(156, 27);
            this.lblPdsEcu.Name = "lblPdsEcu";
            this.lblPdsEcu.Size = new System.Drawing.Size(34, 13);
            this.lblPdsEcu.TabIndex = 86;
            this.lblPdsEcu.Text = "1,7kg";
            // 
            // nudEcu
            // 
            this.nudEcu.Location = new System.Drawing.Point(266, 25);
            this.nudEcu.Name = "nudEcu";
            this.nudEcu.Size = new System.Drawing.Size(41, 20);
            this.nudEcu.TabIndex = 87;
            this.nudEcu.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudEcu.ValueChanged += new System.EventHandler(this.nudEcu_ValueChanged);
            // 
            // lblEftsEcu
            // 
            this.lblEftsEcu.AutoSize = true;
            this.lblEftsEcu.Location = new System.Drawing.Point(325, 27);
            this.lblEftsEcu.Name = "lblEftsEcu";
            this.lblEftsEcu.Size = new System.Drawing.Size(85, 13);
            this.lblEftsEcu.TabIndex = 88;
            this.lblEftsEcu.Text = "Suprt — 3 dégâts";
            // 
            // lblNomBoucliers
            // 
            this.lblNomBoucliers.AutoSize = true;
            this.lblNomBoucliers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomBoucliers.Location = new System.Drawing.Point(34, 3);
            this.lblNomBoucliers.Name = "lblNomBoucliers";
            this.lblNomBoucliers.Size = new System.Drawing.Size(29, 13);
            this.lblNomBoucliers.TabIndex = 81;
            this.lblNomBoucliers.Text = "Nom";
            // 
            // lblPdsBoucliers
            // 
            this.lblPdsBoucliers.AutoSize = true;
            this.lblPdsBoucliers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsBoucliers.Location = new System.Drawing.Point(156, 3);
            this.lblPdsBoucliers.Name = "lblPdsBoucliers";
            this.lblPdsBoucliers.Size = new System.Drawing.Size(33, 13);
            this.lblPdsBoucliers.TabIndex = 82;
            this.lblPdsBoucliers.Text = "Poids";
            // 
            // lblNbBoucliers
            // 
            this.lblNbBoucliers.AutoSize = true;
            this.lblNbBoucliers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbBoucliers.Location = new System.Drawing.Point(266, 3);
            this.lblNbBoucliers.Name = "lblNbBoucliers";
            this.lblNbBoucliers.Size = new System.Drawing.Size(44, 13);
            this.lblNbBoucliers.TabIndex = 83;
            this.lblNbBoucliers.Text = "Nombre";
            // 
            // lblEftsBoucliers
            // 
            this.lblEftsBoucliers.AutoSize = true;
            this.lblEftsBoucliers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEftsBoucliers.Location = new System.Drawing.Point(325, 3);
            this.lblEftsBoucliers.Name = "lblEftsBoucliers";
            this.lblEftsBoucliers.Size = new System.Drawing.Size(34, 13);
            this.lblEftsBoucliers.TabIndex = 84;
            this.lblEftsBoucliers.Text = "Effets";
            // 
            // tpObjets
            // 
            this.tpObjets.AutoScroll = true;
            this.tpObjets.Controls.Add(this.label4);
            this.tpObjets.Controls.Add(this.chkPrre);
            this.tpObjets.Controls.Add(this.lblTllePrre);
            this.tpObjets.Controls.Add(this.lblNomPrre);
            this.tpObjets.Controls.Add(this.lblPdsPrre);
            this.tpObjets.Controls.Add(this.nudPrre);
            this.tpObjets.Controls.Add(this.lblEftsPrre);
            this.tpObjets.Controls.Add(this.lblVleurCrauFr);
            this.tpObjets.Controls.Add(this.chkCrauFr);
            this.tpObjets.Controls.Add(this.lblTlleCrauFr);
            this.tpObjets.Controls.Add(this.lblNomCrauFr);
            this.tpObjets.Controls.Add(this.lblPdsCrauFr);
            this.tpObjets.Controls.Add(this.nudCrauFr);
            this.tpObjets.Controls.Add(this.lblEftsCrauFr);
            this.tpObjets.Controls.Add(this.label2);
            this.tpObjets.Controls.Add(this.chkCrauBois);
            this.tpObjets.Controls.Add(this.lblTlleCrauBois);
            this.tpObjets.Controls.Add(this.lblNomCrauBois);
            this.tpObjets.Controls.Add(this.lblPdsCrauBois);
            this.tpObjets.Controls.Add(this.nudCrauBois);
            this.tpObjets.Controls.Add(this.lblEftsCrauBois);
            this.tpObjets.Controls.Add(this.lblVleurFlcheArgent);
            this.tpObjets.Controls.Add(this.chkFlcheArgent);
            this.tpObjets.Controls.Add(this.lblTlleFlcheArgent);
            this.tpObjets.Controls.Add(this.lblnomFlcheArgent);
            this.tpObjets.Controls.Add(this.lblPdsFlcheArgent);
            this.tpObjets.Controls.Add(this.nudFlcheArgent);
            this.tpObjets.Controls.Add(this.lblEftsFlcheArgent);
            this.tpObjets.Controls.Add(this.lblVleurFlcheFr);
            this.tpObjets.Controls.Add(this.chkFlcheFr);
            this.tpObjets.Controls.Add(this.lblTlleFlcheFr);
            this.tpObjets.Controls.Add(this.lblNomFlcheFr);
            this.tpObjets.Controls.Add(this.lblPdsFlcheFr);
            this.tpObjets.Controls.Add(this.nudFlcheFr);
            this.tpObjets.Controls.Add(this.lblDgtsFlcheFr);
            this.tpObjets.Controls.Add(this.lblVleurFlcheBois);
            this.tpObjets.Controls.Add(this.chkFlcheBois);
            this.tpObjets.Controls.Add(this.lblTlleFlcheBois);
            this.tpObjets.Controls.Add(this.lblNomFlcheBois);
            this.tpObjets.Controls.Add(this.lblPdsFlcheBois);
            this.tpObjets.Controls.Add(this.nudFlcheBois);
            this.tpObjets.Controls.Add(this.lblEftsFlcheBois);
            this.tpObjets.Controls.Add(this.lblVleurCntrePson);
            this.tpObjets.Controls.Add(this.chkCntrePson);
            this.tpObjets.Controls.Add(this.lblTlleCntrePson);
            this.tpObjets.Controls.Add(this.lblNomCntrePson);
            this.tpObjets.Controls.Add(this.lblPdsCntrePson);
            this.tpObjets.Controls.Add(this.nudCntrePson);
            this.tpObjets.Controls.Add(this.lblEftsCntrePson);
            this.tpObjets.Controls.Add(this.lblVleurPlnteMcnale);
            this.tpObjets.Controls.Add(this.chkPlnteMcnale);
            this.tpObjets.Controls.Add(this.lblTllePlnteMcnale);
            this.tpObjets.Controls.Add(this.lblNomPlnteMcnale);
            this.tpObjets.Controls.Add(this.lblPdsPlnteMcnale);
            this.tpObjets.Controls.Add(this.nudPlnteMcnale);
            this.tpObjets.Controls.Add(this.lblEftsPlnteMcnale);
            this.tpObjets.Controls.Add(this.lblVleurCvture);
            this.tpObjets.Controls.Add(this.chkCvture);
            this.tpObjets.Controls.Add(this.lblTlleCvture);
            this.tpObjets.Controls.Add(this.lblNomCvture);
            this.tpObjets.Controls.Add(this.lblPdsCvture);
            this.tpObjets.Controls.Add(this.nudCvture);
            this.tpObjets.Controls.Add(this.lblEftsCvture);
            this.tpObjets.Controls.Add(this.lblVleurMhoir);
            this.tpObjets.Controls.Add(this.chkMhoir);
            this.tpObjets.Controls.Add(this.lblTlleMhoir);
            this.tpObjets.Controls.Add(this.lblNomMhoir);
            this.tpObjets.Controls.Add(this.lblPdsMhoir);
            this.tpObjets.Controls.Add(this.nudMhoir);
            this.tpObjets.Controls.Add(this.lblEftsMhoir);
            this.tpObjets.Controls.Add(this.lblVleurTnte);
            this.tpObjets.Controls.Add(this.lblVleurSc);
            this.tpObjets.Controls.Add(this.lblVleurOte);
            this.tpObjets.Controls.Add(this.label7);
            this.tpObjets.Controls.Add(this.lblVleurTrche);
            this.tpObjets.Controls.Add(this.lblVleurObjets);
            this.tpObjets.Controls.Add(this.chkTnte);
            this.tpObjets.Controls.Add(this.chkSc);
            this.tpObjets.Controls.Add(this.chkOte);
            this.tpObjets.Controls.Add(this.chkCrde);
            this.tpObjets.Controls.Add(this.chkTrche);
            this.tpObjets.Controls.Add(this.lblTlleTnte);
            this.tpObjets.Controls.Add(this.lblNomTnte);
            this.tpObjets.Controls.Add(this.lblPdsTnte);
            this.tpObjets.Controls.Add(this.nudTnte);
            this.tpObjets.Controls.Add(this.lblEftsTnte);
            this.tpObjets.Controls.Add(this.lblTlleSc);
            this.tpObjets.Controls.Add(this.lblNomSc);
            this.tpObjets.Controls.Add(this.lblPdsSc);
            this.tpObjets.Controls.Add(this.nudSc);
            this.tpObjets.Controls.Add(this.lblEftsSc);
            this.tpObjets.Controls.Add(this.lblTlleOte);
            this.tpObjets.Controls.Add(this.lblNomOte);
            this.tpObjets.Controls.Add(this.lblPdsOte);
            this.tpObjets.Controls.Add(this.nudOte);
            this.tpObjets.Controls.Add(this.lblEftsOte);
            this.tpObjets.Controls.Add(this.lblTlleCrde);
            this.tpObjets.Controls.Add(this.lblTlleTrche);
            this.tpObjets.Controls.Add(this.lblTlleObjets);
            this.tpObjets.Controls.Add(this.lblNomCrde);
            this.tpObjets.Controls.Add(this.lblPdsCrde);
            this.tpObjets.Controls.Add(this.nudCrde);
            this.tpObjets.Controls.Add(this.lblEftsCrde);
            this.tpObjets.Controls.Add(this.lblNomTrche);
            this.tpObjets.Controls.Add(this.lblPdsTrche);
            this.tpObjets.Controls.Add(this.nudTrche);
            this.tpObjets.Controls.Add(this.lblEftsTrche);
            this.tpObjets.Controls.Add(this.lblNomObjts);
            this.tpObjets.Controls.Add(this.lblPdsObjts);
            this.tpObjets.Controls.Add(this.lblNbObjts);
            this.tpObjets.Controls.Add(this.lblEftsObjts);
            this.tpObjets.Location = new System.Drawing.Point(4, 22);
            this.tpObjets.Name = "tpObjets";
            this.tpObjets.Size = new System.Drawing.Size(703, 252);
            this.tpObjets.TabIndex = 2;
            this.tpObjets.Text = "Objets";
            this.tpObjets.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(505, 375);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 240;
            this.label4.Text = "1 pc";
            // 
            // chkPrre
            // 
            this.chkPrre.AutoSize = true;
            this.chkPrre.Location = new System.Drawing.Point(13, 377);
            this.chkPrre.Name = "chkPrre";
            this.chkPrre.Size = new System.Drawing.Size(15, 14);
            this.chkPrre.TabIndex = 239;
            this.chkPrre.UseVisualStyleBackColor = true;
            this.chkPrre.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTllePrre
            // 
            this.lblTllePrre.AutoSize = true;
            this.lblTllePrre.Location = new System.Drawing.Point(200, 377);
            this.lblTllePrre.Name = "lblTllePrre";
            this.lblTllePrre.Size = new System.Drawing.Size(36, 13);
            this.lblTllePrre.TabIndex = 238;
            this.lblTllePrre.Text = "35 cm";
            // 
            // lblNomPrre
            // 
            this.lblNomPrre.AutoSize = true;
            this.lblNomPrre.Location = new System.Drawing.Point(34, 377);
            this.lblNomPrre.Name = "lblNomPrre";
            this.lblNomPrre.Size = new System.Drawing.Size(34, 13);
            this.lblNomPrre.TabIndex = 234;
            this.lblNomPrre.Text = "Pierre";
            // 
            // lblPdsPrre
            // 
            this.lblPdsPrre.AutoSize = true;
            this.lblPdsPrre.Location = new System.Drawing.Point(128, 377);
            this.lblPdsPrre.Name = "lblPdsPrre";
            this.lblPdsPrre.Size = new System.Drawing.Size(40, 13);
            this.lblPdsPrre.TabIndex = 235;
            this.lblPdsPrre.Text = "0,75kg";
            // 
            // nudPrre
            // 
            this.nudPrre.Location = new System.Drawing.Point(266, 375);
            this.nudPrre.Name = "nudPrre";
            this.nudPrre.Size = new System.Drawing.Size(41, 20);
            this.nudPrre.TabIndex = 236;
            this.nudPrre.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudPrre.ValueChanged += new System.EventHandler(this.nudPrre_ValueChanged);
            // 
            // lblEftsPrre
            // 
            this.lblEftsPrre.AutoSize = true;
            this.lblEftsPrre.Location = new System.Drawing.Point(325, 377);
            this.lblEftsPrre.Name = "lblEftsPrre";
            this.lblEftsPrre.Size = new System.Drawing.Size(56, 13);
            this.lblEftsPrre.TabIndex = 237;
            this.lblEftsPrre.Text = "Dégâts : 1";
            // 
            // lblVleurCrauFr
            // 
            this.lblVleurCrauFr.AutoSize = true;
            this.lblVleurCrauFr.Location = new System.Drawing.Point(505, 352);
            this.lblVleurCrauFr.Name = "lblVleurCrauFr";
            this.lblVleurCrauFr.Size = new System.Drawing.Size(82, 13);
            this.lblVleurCrauFr.TabIndex = 233;
            this.lblVleurCrauFr.Text = "1 po, 2 pa, 4 pc";
            // 
            // chkCrauFr
            // 
            this.chkCrauFr.AutoSize = true;
            this.chkCrauFr.Location = new System.Drawing.Point(13, 352);
            this.chkCrauFr.Name = "chkCrauFr";
            this.chkCrauFr.Size = new System.Drawing.Size(15, 14);
            this.chkCrauFr.TabIndex = 232;
            this.chkCrauFr.UseVisualStyleBackColor = true;
            this.chkCrauFr.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTlleCrauFr
            // 
            this.lblTlleCrauFr.AutoSize = true;
            this.lblTlleCrauFr.Location = new System.Drawing.Point(200, 352);
            this.lblTlleCrauFr.Name = "lblTlleCrauFr";
            this.lblTlleCrauFr.Size = new System.Drawing.Size(36, 13);
            this.lblTlleCrauFr.TabIndex = 231;
            this.lblTlleCrauFr.Text = "60 cm";
            // 
            // lblNomCrauFr
            // 
            this.lblNomCrauFr.AutoSize = true;
            this.lblNomCrauFr.Location = new System.Drawing.Point(34, 352);
            this.lblNomCrauFr.Name = "lblNomCrauFr";
            this.lblNomCrauFr.Size = new System.Drawing.Size(74, 13);
            this.lblNomCrauFr.TabIndex = 227;
            this.lblNomCrauFr.Text = "Carreau de fer";
            // 
            // lblPdsCrauFr
            // 
            this.lblPdsCrauFr.AutoSize = true;
            this.lblPdsCrauFr.Location = new System.Drawing.Point(128, 352);
            this.lblPdsCrauFr.Name = "lblPdsCrauFr";
            this.lblPdsCrauFr.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCrauFr.TabIndex = 228;
            this.lblPdsCrauFr.Text = "2,5kg";
            // 
            // nudCrauFr
            // 
            this.nudCrauFr.Location = new System.Drawing.Point(266, 350);
            this.nudCrauFr.Name = "nudCrauFr";
            this.nudCrauFr.Size = new System.Drawing.Size(41, 20);
            this.nudCrauFr.TabIndex = 229;
            this.nudCrauFr.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCrauFr.ValueChanged += new System.EventHandler(this.nudCrauFr_ValueChanged);
            // 
            // lblEftsCrauFr
            // 
            this.lblEftsCrauFr.AutoSize = true;
            this.lblEftsCrauFr.Location = new System.Drawing.Point(325, 352);
            this.lblEftsCrauFr.Name = "lblEftsCrauFr";
            this.lblEftsCrauFr.Size = new System.Drawing.Size(56, 13);
            this.lblEftsCrauFr.TabIndex = 230;
            this.lblEftsCrauFr.Text = "Dégâts : 5";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(505, 327);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 226;
            this.label2.Text = "6 pa, 4 pc";
            // 
            // chkCrauBois
            // 
            this.chkCrauBois.AutoSize = true;
            this.chkCrauBois.Location = new System.Drawing.Point(13, 327);
            this.chkCrauBois.Name = "chkCrauBois";
            this.chkCrauBois.Size = new System.Drawing.Size(15, 14);
            this.chkCrauBois.TabIndex = 225;
            this.chkCrauBois.UseVisualStyleBackColor = true;
            this.chkCrauBois.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTlleCrauBois
            // 
            this.lblTlleCrauBois.AutoSize = true;
            this.lblTlleCrauBois.Location = new System.Drawing.Point(200, 327);
            this.lblTlleCrauBois.Name = "lblTlleCrauBois";
            this.lblTlleCrauBois.Size = new System.Drawing.Size(36, 13);
            this.lblTlleCrauBois.TabIndex = 224;
            this.lblTlleCrauBois.Text = "60 cm";
            // 
            // lblNomCrauBois
            // 
            this.lblNomCrauBois.AutoSize = true;
            this.lblNomCrauBois.Location = new System.Drawing.Point(34, 327);
            this.lblNomCrauBois.Name = "lblNomCrauBois";
            this.lblNomCrauBois.Size = new System.Drawing.Size(81, 13);
            this.lblNomCrauBois.TabIndex = 220;
            this.lblNomCrauBois.Text = "Carreau de bois";
            // 
            // lblPdsCrauBois
            // 
            this.lblPdsCrauBois.AutoSize = true;
            this.lblPdsCrauBois.Location = new System.Drawing.Point(128, 327);
            this.lblPdsCrauBois.Name = "lblPdsCrauBois";
            this.lblPdsCrauBois.Size = new System.Drawing.Size(25, 13);
            this.lblPdsCrauBois.TabIndex = 221;
            this.lblPdsCrauBois.Text = "1kg";
            // 
            // nudCrauBois
            // 
            this.nudCrauBois.Location = new System.Drawing.Point(266, 325);
            this.nudCrauBois.Name = "nudCrauBois";
            this.nudCrauBois.Size = new System.Drawing.Size(41, 20);
            this.nudCrauBois.TabIndex = 222;
            this.nudCrauBois.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCrauBois.ValueChanged += new System.EventHandler(this.nudCrauBois_ValueChanged);
            // 
            // lblEftsCrauBois
            // 
            this.lblEftsCrauBois.AutoSize = true;
            this.lblEftsCrauBois.Location = new System.Drawing.Point(325, 327);
            this.lblEftsCrauBois.Name = "lblEftsCrauBois";
            this.lblEftsCrauBois.Size = new System.Drawing.Size(56, 13);
            this.lblEftsCrauBois.TabIndex = 223;
            this.lblEftsCrauBois.Text = "Dégâts : 2";
            // 
            // lblVleurFlcheArgent
            // 
            this.lblVleurFlcheArgent.AutoSize = true;
            this.lblVleurFlcheArgent.Location = new System.Drawing.Point(505, 301);
            this.lblVleurFlcheArgent.Name = "lblVleurFlcheArgent";
            this.lblVleurFlcheArgent.Size = new System.Drawing.Size(82, 13);
            this.lblVleurFlcheArgent.TabIndex = 219;
            this.lblVleurFlcheArgent.Text = "1 po, 2 pa, 9 pc";
            // 
            // chkFlcheArgent
            // 
            this.chkFlcheArgent.AutoSize = true;
            this.chkFlcheArgent.Location = new System.Drawing.Point(13, 302);
            this.chkFlcheArgent.Name = "chkFlcheArgent";
            this.chkFlcheArgent.Size = new System.Drawing.Size(15, 14);
            this.chkFlcheArgent.TabIndex = 218;
            this.chkFlcheArgent.UseVisualStyleBackColor = true;
            this.chkFlcheArgent.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTlleFlcheArgent
            // 
            this.lblTlleFlcheArgent.AutoSize = true;
            this.lblTlleFlcheArgent.Location = new System.Drawing.Point(200, 302);
            this.lblTlleFlcheArgent.Name = "lblTlleFlcheArgent";
            this.lblTlleFlcheArgent.Size = new System.Drawing.Size(36, 13);
            this.lblTlleFlcheArgent.TabIndex = 217;
            this.lblTlleFlcheArgent.Text = "68 cm";
            // 
            // lblnomFlcheArgent
            // 
            this.lblnomFlcheArgent.AutoSize = true;
            this.lblnomFlcheArgent.Location = new System.Drawing.Point(34, 302);
            this.lblnomFlcheArgent.Name = "lblnomFlcheArgent";
            this.lblnomFlcheArgent.Size = new System.Drawing.Size(85, 13);
            this.lblnomFlcheArgent.TabIndex = 213;
            this.lblnomFlcheArgent.Text = "Flèches d\'argent";
            // 
            // lblPdsFlcheArgent
            // 
            this.lblPdsFlcheArgent.AutoSize = true;
            this.lblPdsFlcheArgent.Location = new System.Drawing.Point(128, 302);
            this.lblPdsFlcheArgent.Name = "lblPdsFlcheArgent";
            this.lblPdsFlcheArgent.Size = new System.Drawing.Size(40, 13);
            this.lblPdsFlcheArgent.TabIndex = 214;
            this.lblPdsFlcheArgent.Text = "1,90kg";
            // 
            // nudFlcheArgent
            // 
            this.nudFlcheArgent.Location = new System.Drawing.Point(266, 300);
            this.nudFlcheArgent.Name = "nudFlcheArgent";
            this.nudFlcheArgent.Size = new System.Drawing.Size(41, 20);
            this.nudFlcheArgent.TabIndex = 215;
            this.nudFlcheArgent.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFlcheArgent.ValueChanged += new System.EventHandler(this.nudFlcheArgent_ValueChanged);
            // 
            // lblEftsFlcheArgent
            // 
            this.lblEftsFlcheArgent.AutoSize = true;
            this.lblEftsFlcheArgent.Location = new System.Drawing.Point(325, 302);
            this.lblEftsFlcheArgent.Name = "lblEftsFlcheArgent";
            this.lblEftsFlcheArgent.Size = new System.Drawing.Size(56, 13);
            this.lblEftsFlcheArgent.TabIndex = 216;
            this.lblEftsFlcheArgent.Text = "Dégâts : 8";
            // 
            // lblVleurFlcheFr
            // 
            this.lblVleurFlcheFr.AutoSize = true;
            this.lblVleurFlcheFr.Location = new System.Drawing.Point(505, 277);
            this.lblVleurFlcheFr.Name = "lblVleurFlcheFr";
            this.lblVleurFlcheFr.Size = new System.Drawing.Size(55, 13);
            this.lblVleurFlcheFr.TabIndex = 212;
            this.lblVleurFlcheFr.Text = "9 pa, 6 pc";
            // 
            // chkFlcheFr
            // 
            this.chkFlcheFr.AutoSize = true;
            this.chkFlcheFr.Location = new System.Drawing.Point(13, 277);
            this.chkFlcheFr.Name = "chkFlcheFr";
            this.chkFlcheFr.Size = new System.Drawing.Size(15, 14);
            this.chkFlcheFr.TabIndex = 211;
            this.chkFlcheFr.UseVisualStyleBackColor = true;
            this.chkFlcheFr.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTlleFlcheFr
            // 
            this.lblTlleFlcheFr.AutoSize = true;
            this.lblTlleFlcheFr.Location = new System.Drawing.Point(200, 277);
            this.lblTlleFlcheFr.Name = "lblTlleFlcheFr";
            this.lblTlleFlcheFr.Size = new System.Drawing.Size(36, 13);
            this.lblTlleFlcheFr.TabIndex = 210;
            this.lblTlleFlcheFr.Text = "65 cm";
            // 
            // lblNomFlcheFr
            // 
            this.lblNomFlcheFr.AutoSize = true;
            this.lblNomFlcheFr.Location = new System.Drawing.Point(34, 277);
            this.lblNomFlcheFr.Name = "lblNomFlcheFr";
            this.lblNomFlcheFr.Size = new System.Drawing.Size(74, 13);
            this.lblNomFlcheFr.TabIndex = 206;
            this.lblNomFlcheFr.Text = "Flèches de fer";
            // 
            // lblPdsFlcheFr
            // 
            this.lblPdsFlcheFr.AutoSize = true;
            this.lblPdsFlcheFr.Location = new System.Drawing.Point(128, 277);
            this.lblPdsFlcheFr.Name = "lblPdsFlcheFr";
            this.lblPdsFlcheFr.Size = new System.Drawing.Size(40, 13);
            this.lblPdsFlcheFr.TabIndex = 207;
            this.lblPdsFlcheFr.Text = "1,75kg";
            // 
            // nudFlcheFr
            // 
            this.nudFlcheFr.Location = new System.Drawing.Point(266, 275);
            this.nudFlcheFr.Name = "nudFlcheFr";
            this.nudFlcheFr.Size = new System.Drawing.Size(41, 20);
            this.nudFlcheFr.TabIndex = 208;
            this.nudFlcheFr.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFlcheFr.ValueChanged += new System.EventHandler(this.nudFlcheFr_ValueChanged);
            // 
            // lblDgtsFlcheFr
            // 
            this.lblDgtsFlcheFr.AutoSize = true;
            this.lblDgtsFlcheFr.Location = new System.Drawing.Point(325, 277);
            this.lblDgtsFlcheFr.Name = "lblDgtsFlcheFr";
            this.lblDgtsFlcheFr.Size = new System.Drawing.Size(56, 13);
            this.lblDgtsFlcheFr.TabIndex = 209;
            this.lblDgtsFlcheFr.Text = "Dégâts : 4";
            // 
            // lblVleurFlcheBois
            // 
            this.lblVleurFlcheBois.AutoSize = true;
            this.lblVleurFlcheBois.Location = new System.Drawing.Point(505, 252);
            this.lblVleurFlcheBois.Name = "lblVleurFlcheBois";
            this.lblVleurFlcheBois.Size = new System.Drawing.Size(55, 13);
            this.lblVleurFlcheBois.TabIndex = 205;
            this.lblVleurFlcheBois.Text = "5 pa, 6 pc";
            // 
            // chkFlcheBois
            // 
            this.chkFlcheBois.AutoSize = true;
            this.chkFlcheBois.Location = new System.Drawing.Point(13, 252);
            this.chkFlcheBois.Name = "chkFlcheBois";
            this.chkFlcheBois.Size = new System.Drawing.Size(15, 14);
            this.chkFlcheBois.TabIndex = 204;
            this.chkFlcheBois.UseVisualStyleBackColor = true;
            this.chkFlcheBois.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTlleFlcheBois
            // 
            this.lblTlleFlcheBois.AutoSize = true;
            this.lblTlleFlcheBois.Location = new System.Drawing.Point(200, 252);
            this.lblTlleFlcheBois.Name = "lblTlleFlcheBois";
            this.lblTlleFlcheBois.Size = new System.Drawing.Size(36, 13);
            this.lblTlleFlcheBois.TabIndex = 203;
            this.lblTlleFlcheBois.Text = "60 cm";
            // 
            // lblNomFlcheBois
            // 
            this.lblNomFlcheBois.AutoSize = true;
            this.lblNomFlcheBois.Location = new System.Drawing.Point(34, 252);
            this.lblNomFlcheBois.Name = "lblNomFlcheBois";
            this.lblNomFlcheBois.Size = new System.Drawing.Size(81, 13);
            this.lblNomFlcheBois.TabIndex = 199;
            this.lblNomFlcheBois.Text = "Flèches de bois";
            // 
            // lblPdsFlcheBois
            // 
            this.lblPdsFlcheBois.AutoSize = true;
            this.lblPdsFlcheBois.Location = new System.Drawing.Point(128, 252);
            this.lblPdsFlcheBois.Name = "lblPdsFlcheBois";
            this.lblPdsFlcheBois.Size = new System.Drawing.Size(34, 13);
            this.lblPdsFlcheBois.TabIndex = 200;
            this.lblPdsFlcheBois.Text = "0,8kg";
            // 
            // nudFlcheBois
            // 
            this.nudFlcheBois.Location = new System.Drawing.Point(266, 250);
            this.nudFlcheBois.Name = "nudFlcheBois";
            this.nudFlcheBois.Size = new System.Drawing.Size(41, 20);
            this.nudFlcheBois.TabIndex = 201;
            this.nudFlcheBois.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFlcheBois.ValueChanged += new System.EventHandler(this.nudFlcheBois_ValueChanged);
            // 
            // lblEftsFlcheBois
            // 
            this.lblEftsFlcheBois.AutoSize = true;
            this.lblEftsFlcheBois.Location = new System.Drawing.Point(325, 252);
            this.lblEftsFlcheBois.Name = "lblEftsFlcheBois";
            this.lblEftsFlcheBois.Size = new System.Drawing.Size(56, 13);
            this.lblEftsFlcheBois.TabIndex = 202;
            this.lblEftsFlcheBois.Text = "Dégâts : 2";
            // 
            // lblVleurCntrePson
            // 
            this.lblVleurCntrePson.AutoSize = true;
            this.lblVleurCntrePson.Location = new System.Drawing.Point(505, 227);
            this.lblVleurCntrePson.Name = "lblVleurCntrePson";
            this.lblVleurCntrePson.Size = new System.Drawing.Size(82, 13);
            this.lblVleurCntrePson.TabIndex = 198;
            this.lblVleurCntrePson.Text = "1 po, 5 pa, 5 pc";
            // 
            // chkCntrePson
            // 
            this.chkCntrePson.AutoSize = true;
            this.chkCntrePson.Location = new System.Drawing.Point(13, 227);
            this.chkCntrePson.Name = "chkCntrePson";
            this.chkCntrePson.Size = new System.Drawing.Size(15, 14);
            this.chkCntrePson.TabIndex = 197;
            this.chkCntrePson.UseVisualStyleBackColor = true;
            this.chkCntrePson.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTlleCntrePson
            // 
            this.lblTlleCntrePson.AutoSize = true;
            this.lblTlleCntrePson.Location = new System.Drawing.Point(200, 227);
            this.lblTlleCntrePson.Name = "lblTlleCntrePson";
            this.lblTlleCntrePson.Size = new System.Drawing.Size(36, 13);
            this.lblTlleCntrePson.TabIndex = 196;
            this.lblTlleCntrePson.Text = "25 cm";
            // 
            // lblNomCntrePson
            // 
            this.lblNomCntrePson.AutoSize = true;
            this.lblNomCntrePson.Location = new System.Drawing.Point(34, 227);
            this.lblNomCntrePson.Name = "lblNomCntrePson";
            this.lblNomCntrePson.Size = new System.Drawing.Size(72, 13);
            this.lblNomCntrePson.TabIndex = 192;
            this.lblNomCntrePson.Text = "Contre-poison";
            // 
            // lblPdsCntrePson
            // 
            this.lblPdsCntrePson.AutoSize = true;
            this.lblPdsCntrePson.Location = new System.Drawing.Point(128, 227);
            this.lblPdsCntrePson.Name = "lblPdsCntrePson";
            this.lblPdsCntrePson.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCntrePson.TabIndex = 193;
            this.lblPdsCntrePson.Text = "1,5kg";
            // 
            // nudCntrePson
            // 
            this.nudCntrePson.Location = new System.Drawing.Point(266, 225);
            this.nudCntrePson.Name = "nudCntrePson";
            this.nudCntrePson.Size = new System.Drawing.Size(41, 20);
            this.nudCntrePson.TabIndex = 194;
            this.nudCntrePson.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCntrePson.ValueChanged += new System.EventHandler(this.nudCntrePson_ValueChanged);
            // 
            // lblEftsCntrePson
            // 
            this.lblEftsCntrePson.AutoSize = true;
            this.lblEftsCntrePson.Location = new System.Drawing.Point(325, 227);
            this.lblEftsCntrePson.Name = "lblEftsCntrePson";
            this.lblEftsCntrePson.Size = new System.Drawing.Size(141, 13);
            this.lblEftsCntrePson.TabIndex = 195;
            this.lblEftsCntrePson.Text = "Permet de guérir d\'un poison";
            // 
            // lblVleurPlnteMcnale
            // 
            this.lblVleurPlnteMcnale.AutoSize = true;
            this.lblVleurPlnteMcnale.Location = new System.Drawing.Point(505, 202);
            this.lblVleurPlnteMcnale.Name = "lblVleurPlnteMcnale";
            this.lblVleurPlnteMcnale.Size = new System.Drawing.Size(28, 13);
            this.lblVleurPlnteMcnale.TabIndex = 191;
            this.lblVleurPlnteMcnale.Text = "6 pa";
            // 
            // chkPlnteMcnale
            // 
            this.chkPlnteMcnale.AutoSize = true;
            this.chkPlnteMcnale.Location = new System.Drawing.Point(13, 202);
            this.chkPlnteMcnale.Name = "chkPlnteMcnale";
            this.chkPlnteMcnale.Size = new System.Drawing.Size(15, 14);
            this.chkPlnteMcnale.TabIndex = 190;
            this.chkPlnteMcnale.UseVisualStyleBackColor = true;
            this.chkPlnteMcnale.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTllePlnteMcnale
            // 
            this.lblTllePlnteMcnale.AutoSize = true;
            this.lblTllePlnteMcnale.Location = new System.Drawing.Point(200, 202);
            this.lblTllePlnteMcnale.Name = "lblTllePlnteMcnale";
            this.lblTllePlnteMcnale.Size = new System.Drawing.Size(36, 13);
            this.lblTllePlnteMcnale.TabIndex = 189;
            this.lblTllePlnteMcnale.Text = "50 cm";
            // 
            // lblNomPlnteMcnale
            // 
            this.lblNomPlnteMcnale.AutoSize = true;
            this.lblNomPlnteMcnale.Location = new System.Drawing.Point(34, 202);
            this.lblNomPlnteMcnale.Name = "lblNomPlnteMcnale";
            this.lblNomPlnteMcnale.Size = new System.Drawing.Size(84, 13);
            this.lblNomPlnteMcnale.TabIndex = 185;
            this.lblNomPlnteMcnale.Text = "Plante médicinal";
            // 
            // lblPdsPlnteMcnale
            // 
            this.lblPdsPlnteMcnale.AutoSize = true;
            this.lblPdsPlnteMcnale.Location = new System.Drawing.Point(128, 202);
            this.lblPdsPlnteMcnale.Name = "lblPdsPlnteMcnale";
            this.lblPdsPlnteMcnale.Size = new System.Drawing.Size(25, 13);
            this.lblPdsPlnteMcnale.TabIndex = 186;
            this.lblPdsPlnteMcnale.Text = "1kg";
            // 
            // nudPlnteMcnale
            // 
            this.nudPlnteMcnale.Location = new System.Drawing.Point(266, 200);
            this.nudPlnteMcnale.Name = "nudPlnteMcnale";
            this.nudPlnteMcnale.Size = new System.Drawing.Size(41, 20);
            this.nudPlnteMcnale.TabIndex = 187;
            this.nudPlnteMcnale.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudPlnteMcnale.ValueChanged += new System.EventHandler(this.nudPlnteMcnale_ValueChanged);
            // 
            // lblEftsPlnteMcnale
            // 
            this.lblEftsPlnteMcnale.AutoSize = true;
            this.lblEftsPlnteMcnale.Location = new System.Drawing.Point(325, 202);
            this.lblEftsPlnteMcnale.Name = "lblEftsPlnteMcnale";
            this.lblEftsPlnteMcnale.Size = new System.Drawing.Size(96, 13);
            this.lblEftsPlnteMcnale.TabIndex = 188;
            this.lblEftsPlnteMcnale.Text = "Soigne 1 dé de vie";
            // 
            // lblVleurCvture
            // 
            this.lblVleurCvture.AutoSize = true;
            this.lblVleurCvture.Location = new System.Drawing.Point(505, 177);
            this.lblVleurCvture.Name = "lblVleurCvture";
            this.lblVleurCvture.Size = new System.Drawing.Size(55, 13);
            this.lblVleurCvture.TabIndex = 184;
            this.lblVleurCvture.Text = "9 pa, 5 pc";
            // 
            // chkCvture
            // 
            this.chkCvture.AutoSize = true;
            this.chkCvture.Location = new System.Drawing.Point(13, 177);
            this.chkCvture.Name = "chkCvture";
            this.chkCvture.Size = new System.Drawing.Size(15, 14);
            this.chkCvture.TabIndex = 183;
            this.chkCvture.UseVisualStyleBackColor = true;
            this.chkCvture.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTlleCvture
            // 
            this.lblTlleCvture.AutoSize = true;
            this.lblTlleCvture.Location = new System.Drawing.Point(200, 177);
            this.lblTlleCvture.Name = "lblTlleCvture";
            this.lblTlleCvture.Size = new System.Drawing.Size(24, 13);
            this.lblTlleCvture.TabIndex = 182;
            this.lblTlleCvture.Text = "1 m";
            // 
            // lblNomCvture
            // 
            this.lblNomCvture.AutoSize = true;
            this.lblNomCvture.Location = new System.Drawing.Point(34, 177);
            this.lblNomCvture.Name = "lblNomCvture";
            this.lblNomCvture.Size = new System.Drawing.Size(59, 13);
            this.lblNomCvture.TabIndex = 178;
            this.lblNomCvture.Text = "Couverture";
            // 
            // lblPdsCvture
            // 
            this.lblPdsCvture.AutoSize = true;
            this.lblPdsCvture.Location = new System.Drawing.Point(128, 177);
            this.lblPdsCvture.Name = "lblPdsCvture";
            this.lblPdsCvture.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCvture.TabIndex = 179;
            this.lblPdsCvture.Text = "0,1kg";
            // 
            // nudCvture
            // 
            this.nudCvture.Location = new System.Drawing.Point(266, 175);
            this.nudCvture.Name = "nudCvture";
            this.nudCvture.Size = new System.Drawing.Size(41, 20);
            this.nudCvture.TabIndex = 180;
            this.nudCvture.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCvture.ValueChanged += new System.EventHandler(this.nudCvture_ValueChanged);
            // 
            // lblEftsCvture
            // 
            this.lblEftsCvture.AutoSize = true;
            this.lblEftsCvture.Location = new System.Drawing.Point(325, 177);
            this.lblEftsCvture.Name = "lblEftsCvture";
            this.lblEftsCvture.Size = new System.Drawing.Size(144, 13);
            this.lblEftsCvture.TabIndex = 181;
            this.lblEftsCvture.Text = "Pour ne pas avoir froid la nuit";
            // 
            // lblVleurMhoir
            // 
            this.lblVleurMhoir.AutoSize = true;
            this.lblVleurMhoir.Location = new System.Drawing.Point(505, 152);
            this.lblVleurMhoir.Name = "lblVleurMhoir";
            this.lblVleurMhoir.Size = new System.Drawing.Size(28, 13);
            this.lblVleurMhoir.TabIndex = 177;
            this.lblVleurMhoir.Text = "3 pc";
            // 
            // chkMhoir
            // 
            this.chkMhoir.AutoSize = true;
            this.chkMhoir.Location = new System.Drawing.Point(13, 152);
            this.chkMhoir.Name = "chkMhoir";
            this.chkMhoir.Size = new System.Drawing.Size(15, 14);
            this.chkMhoir.TabIndex = 176;
            this.chkMhoir.UseVisualStyleBackColor = true;
            this.chkMhoir.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTlleMhoir
            // 
            this.lblTlleMhoir.AutoSize = true;
            this.lblTlleMhoir.Location = new System.Drawing.Point(200, 152);
            this.lblTlleMhoir.Name = "lblTlleMhoir";
            this.lblTlleMhoir.Size = new System.Drawing.Size(36, 13);
            this.lblTlleMhoir.TabIndex = 175;
            this.lblTlleMhoir.Text = "10 cm";
            // 
            // lblNomMhoir
            // 
            this.lblNomMhoir.AutoSize = true;
            this.lblNomMhoir.Location = new System.Drawing.Point(34, 152);
            this.lblNomMhoir.Name = "lblNomMhoir";
            this.lblNomMhoir.Size = new System.Drawing.Size(51, 13);
            this.lblNomMhoir.TabIndex = 171;
            this.lblNomMhoir.Text = "Mouchoir";
            // 
            // lblPdsMhoir
            // 
            this.lblPdsMhoir.AutoSize = true;
            this.lblPdsMhoir.Location = new System.Drawing.Point(128, 152);
            this.lblPdsMhoir.Name = "lblPdsMhoir";
            this.lblPdsMhoir.Size = new System.Drawing.Size(46, 13);
            this.lblPdsMhoir.TabIndex = 172;
            this.lblPdsMhoir.Text = "0,020kg";
            // 
            // nudMhoir
            // 
            this.nudMhoir.Location = new System.Drawing.Point(266, 150);
            this.nudMhoir.Name = "nudMhoir";
            this.nudMhoir.Size = new System.Drawing.Size(41, 20);
            this.nudMhoir.TabIndex = 173;
            this.nudMhoir.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudMhoir.ValueChanged += new System.EventHandler(this.nudMhoir_ValueChanged);
            // 
            // lblEftsMhoir
            // 
            this.lblEftsMhoir.AutoSize = true;
            this.lblEftsMhoir.Location = new System.Drawing.Point(325, 152);
            this.lblEftsMhoir.Name = "lblEftsMhoir";
            this.lblEftsMhoir.Size = new System.Drawing.Size(169, 13);
            this.lblEftsMhoir.TabIndex = 174;
            this.lblEftsMhoir.Text = "Essuyer ses larmes ou se moucher";
            // 
            // lblVleurTnte
            // 
            this.lblVleurTnte.AutoSize = true;
            this.lblVleurTnte.Location = new System.Drawing.Point(505, 127);
            this.lblVleurTnte.Name = "lblVleurTnte";
            this.lblVleurTnte.Size = new System.Drawing.Size(28, 13);
            this.lblVleurTnte.TabIndex = 170;
            this.lblVleurTnte.Text = "8 po";
            // 
            // lblVleurSc
            // 
            this.lblVleurSc.AutoSize = true;
            this.lblVleurSc.Location = new System.Drawing.Point(505, 102);
            this.lblVleurSc.Name = "lblVleurSc";
            this.lblVleurSc.Size = new System.Drawing.Size(55, 13);
            this.lblVleurSc.TabIndex = 169;
            this.lblVleurSc.Text = "1 pa, 5 pc";
            // 
            // lblVleurOte
            // 
            this.lblVleurOte.AutoSize = true;
            this.lblVleurOte.Location = new System.Drawing.Point(505, 77);
            this.lblVleurOte.Name = "lblVleurOte";
            this.lblVleurOte.Size = new System.Drawing.Size(55, 13);
            this.lblVleurOte.TabIndex = 168;
            this.lblVleurOte.Text = "1 po, 5 pc";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(505, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 13);
            this.label7.TabIndex = 167;
            this.label7.Text = "3 po, 8 pa, 5 pc";
            // 
            // lblVleurTrche
            // 
            this.lblVleurTrche.AutoSize = true;
            this.lblVleurTrche.Location = new System.Drawing.Point(505, 27);
            this.lblVleurTrche.Name = "lblVleurTrche";
            this.lblVleurTrche.Size = new System.Drawing.Size(55, 13);
            this.lblVleurTrche.TabIndex = 166;
            this.lblVleurTrche.Text = "4 pa, 2 pc";
            // 
            // lblVleurObjets
            // 
            this.lblVleurObjets.AutoSize = true;
            this.lblVleurObjets.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVleurObjets.ForeColor = System.Drawing.Color.Black;
            this.lblVleurObjets.Location = new System.Drawing.Point(505, 3);
            this.lblVleurObjets.Name = "lblVleurObjets";
            this.lblVleurObjets.Size = new System.Drawing.Size(37, 13);
            this.lblVleurObjets.TabIndex = 165;
            this.lblVleurObjets.Text = "Valeur";
            // 
            // chkTnte
            // 
            this.chkTnte.AutoSize = true;
            this.chkTnte.Location = new System.Drawing.Point(13, 127);
            this.chkTnte.Name = "chkTnte";
            this.chkTnte.Size = new System.Drawing.Size(15, 14);
            this.chkTnte.TabIndex = 123;
            this.chkTnte.UseVisualStyleBackColor = true;
            this.chkTnte.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkSc
            // 
            this.chkSc.AutoSize = true;
            this.chkSc.Location = new System.Drawing.Point(13, 102);
            this.chkSc.Name = "chkSc";
            this.chkSc.Size = new System.Drawing.Size(15, 14);
            this.chkSc.TabIndex = 122;
            this.chkSc.UseVisualStyleBackColor = true;
            this.chkSc.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkOte
            // 
            this.chkOte.AutoSize = true;
            this.chkOte.Location = new System.Drawing.Point(13, 77);
            this.chkOte.Name = "chkOte";
            this.chkOte.Size = new System.Drawing.Size(15, 14);
            this.chkOte.TabIndex = 121;
            this.chkOte.UseVisualStyleBackColor = true;
            this.chkOte.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkCrde
            // 
            this.chkCrde.AutoSize = true;
            this.chkCrde.Location = new System.Drawing.Point(13, 52);
            this.chkCrde.Name = "chkCrde";
            this.chkCrde.Size = new System.Drawing.Size(15, 14);
            this.chkCrde.TabIndex = 120;
            this.chkCrde.UseVisualStyleBackColor = true;
            this.chkCrde.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // chkTrche
            // 
            this.chkTrche.AutoSize = true;
            this.chkTrche.Location = new System.Drawing.Point(13, 27);
            this.chkTrche.Name = "chkTrche";
            this.chkTrche.Size = new System.Drawing.Size(15, 14);
            this.chkTrche.TabIndex = 119;
            this.chkTrche.UseVisualStyleBackColor = true;
            this.chkTrche.Click += new System.EventHandler(this.chkAddOrDeleteItem_click);
            // 
            // lblTlleTnte
            // 
            this.lblTlleTnte.AutoSize = true;
            this.lblTlleTnte.Location = new System.Drawing.Point(200, 127);
            this.lblTlleTnte.Name = "lblTlleTnte";
            this.lblTlleTnte.Size = new System.Drawing.Size(24, 13);
            this.lblTlleTnte.TabIndex = 118;
            this.lblTlleTnte.Text = "5 m";
            // 
            // lblNomTnte
            // 
            this.lblNomTnte.AutoSize = true;
            this.lblNomTnte.Location = new System.Drawing.Point(34, 127);
            this.lblNomTnte.Name = "lblNomTnte";
            this.lblNomTnte.Size = new System.Drawing.Size(35, 13);
            this.lblNomTnte.TabIndex = 114;
            this.lblNomTnte.Text = "Tente";
            // 
            // lblPdsTnte
            // 
            this.lblPdsTnte.AutoSize = true;
            this.lblPdsTnte.Location = new System.Drawing.Point(128, 127);
            this.lblPdsTnte.Name = "lblPdsTnte";
            this.lblPdsTnte.Size = new System.Drawing.Size(31, 13);
            this.lblPdsTnte.TabIndex = 115;
            this.lblPdsTnte.Text = "15kg";
            // 
            // nudTnte
            // 
            this.nudTnte.Location = new System.Drawing.Point(266, 125);
            this.nudTnte.Name = "nudTnte";
            this.nudTnte.Size = new System.Drawing.Size(41, 20);
            this.nudTnte.TabIndex = 116;
            this.nudTnte.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudTnte.ValueChanged += new System.EventHandler(this.nudTnte_ValueChanged);
            // 
            // lblEftsTnte
            // 
            this.lblEftsTnte.AutoSize = true;
            this.lblEftsTnte.Location = new System.Drawing.Point(325, 127);
            this.lblEftsTnte.Name = "lblEftsTnte";
            this.lblEftsTnte.Size = new System.Drawing.Size(140, 13);
            this.lblEftsTnte.TabIndex = 117;
            this.lblEftsTnte.Text = "Dormir à l\'abri dans la nature";
            // 
            // lblTlleSc
            // 
            this.lblTlleSc.AutoSize = true;
            this.lblTlleSc.Location = new System.Drawing.Point(200, 102);
            this.lblTlleSc.Name = "lblTlleSc";
            this.lblTlleSc.Size = new System.Drawing.Size(36, 13);
            this.lblTlleSc.TabIndex = 113;
            this.lblTlleSc.Text = "50 cm";
            // 
            // lblNomSc
            // 
            this.lblNomSc.AutoSize = true;
            this.lblNomSc.Location = new System.Drawing.Point(34, 102);
            this.lblNomSc.Name = "lblNomSc";
            this.lblNomSc.Size = new System.Drawing.Size(26, 13);
            this.lblNomSc.TabIndex = 109;
            this.lblNomSc.Text = "Sac";
            // 
            // lblPdsSc
            // 
            this.lblPdsSc.AutoSize = true;
            this.lblPdsSc.Location = new System.Drawing.Point(128, 102);
            this.lblPdsSc.Name = "lblPdsSc";
            this.lblPdsSc.Size = new System.Drawing.Size(40, 13);
            this.lblPdsSc.TabIndex = 110;
            this.lblPdsSc.Text = "0,10kg";
            // 
            // nudSc
            // 
            this.nudSc.Location = new System.Drawing.Point(266, 100);
            this.nudSc.Name = "nudSc";
            this.nudSc.Size = new System.Drawing.Size(41, 20);
            this.nudSc.TabIndex = 111;
            this.nudSc.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSc.ValueChanged += new System.EventHandler(this.nudSc_ValueChanged);
            // 
            // lblEftsSc
            // 
            this.lblEftsSc.AutoSize = true;
            this.lblEftsSc.Location = new System.Drawing.Point(325, 102);
            this.lblEftsSc.Name = "lblEftsSc";
            this.lblEftsSc.Size = new System.Drawing.Size(97, 13);
            this.lblEftsSc.TabIndex = 112;
            this.lblEftsSc.Text = "Contient des objets";
            // 
            // lblTlleOte
            // 
            this.lblTlleOte.AutoSize = true;
            this.lblTlleOte.Location = new System.Drawing.Point(200, 77);
            this.lblTlleOte.Name = "lblTlleOte";
            this.lblTlleOte.Size = new System.Drawing.Size(36, 13);
            this.lblTlleOte.TabIndex = 108;
            this.lblTlleOte.Text = "20 cm";
            // 
            // lblNomOte
            // 
            this.lblNomOte.AutoSize = true;
            this.lblNomOte.Location = new System.Drawing.Point(34, 77);
            this.lblNomOte.Name = "lblNomOte";
            this.lblNomOte.Size = new System.Drawing.Size(33, 13);
            this.lblNomOte.TabIndex = 104;
            this.lblNomOte.Text = "Outre";
            // 
            // lblPdsOte
            // 
            this.lblPdsOte.AutoSize = true;
            this.lblPdsOte.Location = new System.Drawing.Point(128, 77);
            this.lblPdsOte.Name = "lblPdsOte";
            this.lblPdsOte.Size = new System.Drawing.Size(25, 13);
            this.lblPdsOte.TabIndex = 105;
            this.lblPdsOte.Text = "1kg";
            // 
            // nudOte
            // 
            this.nudOte.Location = new System.Drawing.Point(266, 75);
            this.nudOte.Name = "nudOte";
            this.nudOte.Size = new System.Drawing.Size(41, 20);
            this.nudOte.TabIndex = 106;
            this.nudOte.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudOte.ValueChanged += new System.EventHandler(this.nudOte_ValueChanged);
            // 
            // lblEftsOte
            // 
            this.lblEftsOte.AutoSize = true;
            this.lblEftsOte.Location = new System.Drawing.Point(325, 77);
            this.lblEftsOte.Name = "lblEftsOte";
            this.lblEftsOte.Size = new System.Drawing.Size(104, 13);
            this.lblEftsOte.TabIndex = 107;
            this.lblEftsOte.Text = "Contient des liquides";
            // 
            // lblTlleCrde
            // 
            this.lblTlleCrde.AutoSize = true;
            this.lblTlleCrde.Location = new System.Drawing.Point(200, 52);
            this.lblTlleCrde.Name = "lblTlleCrde";
            this.lblTlleCrde.Size = new System.Drawing.Size(30, 13);
            this.lblTlleCrde.TabIndex = 103;
            this.lblTlleCrde.Text = "15 m";
            // 
            // lblTlleTrche
            // 
            this.lblTlleTrche.AutoSize = true;
            this.lblTlleTrche.Location = new System.Drawing.Point(200, 27);
            this.lblTlleTrche.Name = "lblTlleTrche";
            this.lblTlleTrche.Size = new System.Drawing.Size(36, 13);
            this.lblTlleTrche.TabIndex = 102;
            this.lblTlleTrche.Text = "35 cm";
            // 
            // lblTlleObjets
            // 
            this.lblTlleObjets.AutoSize = true;
            this.lblTlleObjets.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTlleObjets.Location = new System.Drawing.Point(200, 3);
            this.lblTlleObjets.Name = "lblTlleObjets";
            this.lblTlleObjets.Size = new System.Drawing.Size(32, 13);
            this.lblTlleObjets.TabIndex = 101;
            this.lblTlleObjets.Text = "Taille";
            // 
            // lblNomCrde
            // 
            this.lblNomCrde.AutoSize = true;
            this.lblNomCrde.Location = new System.Drawing.Point(34, 52);
            this.lblNomCrde.Name = "lblNomCrde";
            this.lblNomCrde.Size = new System.Drawing.Size(35, 13);
            this.lblNomCrde.TabIndex = 97;
            this.lblNomCrde.Text = "Corde";
            // 
            // lblPdsCrde
            // 
            this.lblPdsCrde.AutoSize = true;
            this.lblPdsCrde.Location = new System.Drawing.Point(128, 52);
            this.lblPdsCrde.Name = "lblPdsCrde";
            this.lblPdsCrde.Size = new System.Drawing.Size(34, 13);
            this.lblPdsCrde.TabIndex = 98;
            this.lblPdsCrde.Text = "0,4kg";
            // 
            // nudCrde
            // 
            this.nudCrde.Location = new System.Drawing.Point(266, 50);
            this.nudCrde.Name = "nudCrde";
            this.nudCrde.Size = new System.Drawing.Size(41, 20);
            this.nudCrde.TabIndex = 99;
            this.nudCrde.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCrde.ValueChanged += new System.EventHandler(this.nudCrde_ValueChanged);
            // 
            // lblEftsCrde
            // 
            this.lblEftsCrde.AutoSize = true;
            this.lblEftsCrde.Location = new System.Drawing.Point(325, 52);
            this.lblEftsCrde.Name = "lblEftsCrde";
            this.lblEftsCrde.Size = new System.Drawing.Size(158, 13);
            this.lblEftsCrde.TabIndex = 100;
            this.lblEftsCrde.Text = "Permet de descendre ou monter";
            // 
            // lblNomTrche
            // 
            this.lblNomTrche.AutoSize = true;
            this.lblNomTrche.Location = new System.Drawing.Point(34, 27);
            this.lblNomTrche.Name = "lblNomTrche";
            this.lblNomTrche.Size = new System.Drawing.Size(41, 13);
            this.lblNomTrche.TabIndex = 93;
            this.lblNomTrche.Text = "Torche";
            // 
            // lblPdsTrche
            // 
            this.lblPdsTrche.AutoSize = true;
            this.lblPdsTrche.Location = new System.Drawing.Point(128, 27);
            this.lblPdsTrche.Name = "lblPdsTrche";
            this.lblPdsTrche.Size = new System.Drawing.Size(34, 13);
            this.lblPdsTrche.TabIndex = 94;
            this.lblPdsTrche.Text = "0,5kg";
            // 
            // nudTrche
            // 
            this.nudTrche.Location = new System.Drawing.Point(266, 25);
            this.nudTrche.Name = "nudTrche";
            this.nudTrche.Size = new System.Drawing.Size(41, 20);
            this.nudTrche.TabIndex = 95;
            this.nudTrche.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudTrche.ValueChanged += new System.EventHandler(this.nudTrche_ValueChanged);
            // 
            // lblEftsTrche
            // 
            this.lblEftsTrche.AutoSize = true;
            this.lblEftsTrche.Location = new System.Drawing.Point(325, 27);
            this.lblEftsTrche.Name = "lblEftsTrche";
            this.lblEftsTrche.Size = new System.Drawing.Size(163, 13);
            this.lblEftsTrche.TabIndex = 96;
            this.lblEftsTrche.Text = "Éclaire 9 m autour du possesseur";
            // 
            // lblNomObjts
            // 
            this.lblNomObjts.AutoSize = true;
            this.lblNomObjts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomObjts.Location = new System.Drawing.Point(34, 3);
            this.lblNomObjts.Name = "lblNomObjts";
            this.lblNomObjts.Size = new System.Drawing.Size(29, 13);
            this.lblNomObjts.TabIndex = 89;
            this.lblNomObjts.Text = "Nom";
            // 
            // lblPdsObjts
            // 
            this.lblPdsObjts.AutoSize = true;
            this.lblPdsObjts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdsObjts.Location = new System.Drawing.Point(128, 3);
            this.lblPdsObjts.Name = "lblPdsObjts";
            this.lblPdsObjts.Size = new System.Drawing.Size(33, 13);
            this.lblPdsObjts.TabIndex = 90;
            this.lblPdsObjts.Text = "Poids";
            // 
            // lblNbObjts
            // 
            this.lblNbObjts.AutoSize = true;
            this.lblNbObjts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNbObjts.Location = new System.Drawing.Point(266, 3);
            this.lblNbObjts.Name = "lblNbObjts";
            this.lblNbObjts.Size = new System.Drawing.Size(44, 13);
            this.lblNbObjts.TabIndex = 91;
            this.lblNbObjts.Text = "Nombre";
            // 
            // lblEftsObjts
            // 
            this.lblEftsObjts.AutoSize = true;
            this.lblEftsObjts.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEftsObjts.Location = new System.Drawing.Point(325, 3);
            this.lblEftsObjts.Name = "lblEftsObjts";
            this.lblEftsObjts.Size = new System.Drawing.Size(34, 13);
            this.lblEftsObjts.TabIndex = 92;
            this.lblEftsObjts.Text = "Effets";
            // 
            // rchTxtIvtaires
            // 
            this.rchTxtIvtaires.Location = new System.Drawing.Point(12, 297);
            this.rchTxtIvtaires.Name = "rchTxtIvtaires";
            this.rchTxtIvtaires.Size = new System.Drawing.Size(707, 125);
            this.rchTxtIvtaires.TabIndex = 7;
            this.rchTxtIvtaires.Text = "";
            // 
            // tcSortilege
            // 
            this.tcSortilege.Controls.Add(this.tpAqua);
            this.tcSortilege.Controls.Add(this.tpIgnis);
            this.tcSortilege.Controls.Add(this.tpCeleste);
            this.tcSortilege.Controls.Add(this.tpTerrestre);
            this.tcSortilege.Controls.Add(this.tpNature);
            this.tcSortilege.Controls.Add(this.tpDivine);
            this.tcSortilege.Controls.Add(this.tpDemoniaque);
            this.tcSortilege.Controls.Add(this.tpNeutre);
            this.tcSortilege.Location = new System.Drawing.Point(729, 12);
            this.tcSortilege.Name = "tcSortilege";
            this.tcSortilege.SelectedIndex = 0;
            this.tcSortilege.Size = new System.Drawing.Size(416, 189);
            this.tcSortilege.TabIndex = 8;
            // 
            // tpAqua
            // 
            this.tpAqua.Controls.Add(this.chkMgieAqua);
            this.tpAqua.Controls.Add(this.lblMgieAqua);
            this.tpAqua.Controls.Add(this.lblNomMAqua);
            this.tpAqua.Location = new System.Drawing.Point(4, 22);
            this.tpAqua.Name = "tpAqua";
            this.tpAqua.Padding = new System.Windows.Forms.Padding(3);
            this.tpAqua.Size = new System.Drawing.Size(408, 163);
            this.tpAqua.TabIndex = 0;
            this.tpAqua.Text = "M. Aquatique";
            this.tpAqua.UseVisualStyleBackColor = true;
            // 
            // chkMgieAqua
            // 
            this.chkMgieAqua.AutoSize = true;
            this.chkMgieAqua.Location = new System.Drawing.Point(13, 27);
            this.chkMgieAqua.Name = "chkMgieAqua";
            this.chkMgieAqua.Size = new System.Drawing.Size(15, 14);
            this.chkMgieAqua.TabIndex = 154;
            this.chkMgieAqua.UseVisualStyleBackColor = true;
            this.chkMgieAqua.Click += new System.EventHandler(this.chkMgieAqua_Click);
            // 
            // lblMgieAqua
            // 
            this.lblMgieAqua.AutoSize = true;
            this.lblMgieAqua.Location = new System.Drawing.Point(34, 27);
            this.lblMgieAqua.Name = "lblMgieAqua";
            this.lblMgieAqua.Size = new System.Drawing.Size(107, 13);
            this.lblMgieAqua.TabIndex = 128;
            this.lblMgieAqua.Text = "Manipulation de l\'eau";
            // 
            // lblNomMAqua
            // 
            this.lblNomMAqua.AutoSize = true;
            this.lblNomMAqua.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomMAqua.Location = new System.Drawing.Point(34, 3);
            this.lblNomMAqua.Name = "lblNomMAqua";
            this.lblNomMAqua.Size = new System.Drawing.Size(29, 13);
            this.lblNomMAqua.TabIndex = 124;
            this.lblNomMAqua.Text = "Nom";
            // 
            // tpIgnis
            // 
            this.tpIgnis.Controls.Add(this.chkMgieIgnis);
            this.tpIgnis.Controls.Add(this.lblMgieIgnis);
            this.tpIgnis.Controls.Add(this.lblNomMIgnis);
            this.tpIgnis.Location = new System.Drawing.Point(4, 22);
            this.tpIgnis.Name = "tpIgnis";
            this.tpIgnis.Padding = new System.Windows.Forms.Padding(3);
            this.tpIgnis.Size = new System.Drawing.Size(408, 163);
            this.tpIgnis.TabIndex = 1;
            this.tpIgnis.Text = "M.Ignis";
            this.tpIgnis.UseVisualStyleBackColor = true;
            // 
            // chkMgieIgnis
            // 
            this.chkMgieIgnis.AutoSize = true;
            this.chkMgieIgnis.Location = new System.Drawing.Point(13, 27);
            this.chkMgieIgnis.Name = "chkMgieIgnis";
            this.chkMgieIgnis.Size = new System.Drawing.Size(15, 14);
            this.chkMgieIgnis.TabIndex = 157;
            this.chkMgieIgnis.UseVisualStyleBackColor = true;
            this.chkMgieIgnis.Click += new System.EventHandler(this.chkMgieIgnis_Click);
            // 
            // lblMgieIgnis
            // 
            this.lblMgieIgnis.AutoSize = true;
            this.lblMgieIgnis.Location = new System.Drawing.Point(34, 27);
            this.lblMgieIgnis.Name = "lblMgieIgnis";
            this.lblMgieIgnis.Size = new System.Drawing.Size(128, 13);
            this.lblMgieIgnis.TabIndex = 156;
            this.lblMgieIgnis.Text = "Manipulation des flammes";
            // 
            // lblNomMIgnis
            // 
            this.lblNomMIgnis.AutoSize = true;
            this.lblNomMIgnis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomMIgnis.Location = new System.Drawing.Point(34, 3);
            this.lblNomMIgnis.Name = "lblNomMIgnis";
            this.lblNomMIgnis.Size = new System.Drawing.Size(29, 13);
            this.lblNomMIgnis.TabIndex = 155;
            this.lblNomMIgnis.Text = "Nom";
            // 
            // tpCeleste
            // 
            this.tpCeleste.Controls.Add(this.chkMgieCeleste);
            this.tpCeleste.Controls.Add(this.lblMgieCeleste);
            this.tpCeleste.Controls.Add(this.lblNomMCeleste);
            this.tpCeleste.Location = new System.Drawing.Point(4, 22);
            this.tpCeleste.Name = "tpCeleste";
            this.tpCeleste.Size = new System.Drawing.Size(408, 163);
            this.tpCeleste.TabIndex = 2;
            this.tpCeleste.Text = "M.Céleste";
            this.tpCeleste.UseVisualStyleBackColor = true;
            // 
            // chkMgieCeleste
            // 
            this.chkMgieCeleste.AutoSize = true;
            this.chkMgieCeleste.Location = new System.Drawing.Point(13, 27);
            this.chkMgieCeleste.Name = "chkMgieCeleste";
            this.chkMgieCeleste.Size = new System.Drawing.Size(15, 14);
            this.chkMgieCeleste.TabIndex = 160;
            this.chkMgieCeleste.UseVisualStyleBackColor = true;
            this.chkMgieCeleste.Click += new System.EventHandler(this.chkMgieCeleste_Click);
            // 
            // lblMgieCeleste
            // 
            this.lblMgieCeleste.AutoSize = true;
            this.lblMgieCeleste.Location = new System.Drawing.Point(34, 27);
            this.lblMgieCeleste.Name = "lblMgieCeleste";
            this.lblMgieCeleste.Size = new System.Drawing.Size(180, 13);
            this.lblMgieCeleste.TabIndex = 159;
            this.lblMgieCeleste.Text = "Manipulation des éléments des cieux";
            // 
            // lblNomMCeleste
            // 
            this.lblNomMCeleste.AutoSize = true;
            this.lblNomMCeleste.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomMCeleste.Location = new System.Drawing.Point(34, 3);
            this.lblNomMCeleste.Name = "lblNomMCeleste";
            this.lblNomMCeleste.Size = new System.Drawing.Size(29, 13);
            this.lblNomMCeleste.TabIndex = 158;
            this.lblNomMCeleste.Text = "Nom";
            // 
            // tpTerrestre
            // 
            this.tpTerrestre.Controls.Add(this.chkMgieTerrestre);
            this.tpTerrestre.Controls.Add(this.lblMgieTerrestre);
            this.tpTerrestre.Controls.Add(this.lblNomMTerrestre);
            this.tpTerrestre.Location = new System.Drawing.Point(4, 22);
            this.tpTerrestre.Name = "tpTerrestre";
            this.tpTerrestre.Size = new System.Drawing.Size(408, 163);
            this.tpTerrestre.TabIndex = 3;
            this.tpTerrestre.Text = "M.Terrestre";
            this.tpTerrestre.UseVisualStyleBackColor = true;
            // 
            // chkMgieTerrestre
            // 
            this.chkMgieTerrestre.AutoSize = true;
            this.chkMgieTerrestre.Location = new System.Drawing.Point(13, 27);
            this.chkMgieTerrestre.Name = "chkMgieTerrestre";
            this.chkMgieTerrestre.Size = new System.Drawing.Size(15, 14);
            this.chkMgieTerrestre.TabIndex = 163;
            this.chkMgieTerrestre.UseVisualStyleBackColor = true;
            this.chkMgieTerrestre.Click += new System.EventHandler(this.chkMgieTerrestre_Click);
            // 
            // lblMgieTerrestre
            // 
            this.lblMgieTerrestre.AutoSize = true;
            this.lblMgieTerrestre.Location = new System.Drawing.Point(34, 27);
            this.lblMgieTerrestre.Name = "lblMgieTerrestre";
            this.lblMgieTerrestre.Size = new System.Drawing.Size(117, 13);
            this.lblMgieTerrestre.TabIndex = 162;
            this.lblMgieTerrestre.Text = "Manipulation de la terre";
            // 
            // lblNomMTerrestre
            // 
            this.lblNomMTerrestre.AutoSize = true;
            this.lblNomMTerrestre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomMTerrestre.Location = new System.Drawing.Point(34, 3);
            this.lblNomMTerrestre.Name = "lblNomMTerrestre";
            this.lblNomMTerrestre.Size = new System.Drawing.Size(29, 13);
            this.lblNomMTerrestre.TabIndex = 161;
            this.lblNomMTerrestre.Text = "Nom";
            // 
            // tpNature
            // 
            this.tpNature.Controls.Add(this.chkMgieNatureMetamphse);
            this.tpNature.Controls.Add(this.lblMgieNatureMetamphse);
            this.tpNature.Controls.Add(this.chkMgieNatureVsionNoir);
            this.tpNature.Controls.Add(this.lblMgieNatureVsionNoir);
            this.tpNature.Controls.Add(this.chkMgieNatureChgmTemp);
            this.tpNature.Controls.Add(this.lblMgieNatureChgmTemp);
            this.tpNature.Controls.Add(this.chkMgieNatureInvoc);
            this.tpNature.Controls.Add(this.lblMgieNatureInvoc);
            this.tpNature.Controls.Add(this.chkMgieNatureComm);
            this.tpNature.Controls.Add(this.lblMgieNatureComm);
            this.tpNature.Controls.Add(this.lblNomMNature);
            this.tpNature.Location = new System.Drawing.Point(4, 22);
            this.tpNature.Name = "tpNature";
            this.tpNature.Size = new System.Drawing.Size(408, 163);
            this.tpNature.TabIndex = 4;
            this.tpNature.Text = "M.Nature";
            this.tpNature.UseVisualStyleBackColor = true;
            // 
            // chkMgieNatureMetamphse
            // 
            this.chkMgieNatureMetamphse.AutoSize = true;
            this.chkMgieNatureMetamphse.Location = new System.Drawing.Point(13, 127);
            this.chkMgieNatureMetamphse.Name = "chkMgieNatureMetamphse";
            this.chkMgieNatureMetamphse.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNatureMetamphse.TabIndex = 174;
            this.chkMgieNatureMetamphse.UseVisualStyleBackColor = true;
            this.chkMgieNatureMetamphse.Click += new System.EventHandler(this.chkMgieNatureMetamphse_Click);
            // 
            // lblMgieNatureMetamphse
            // 
            this.lblMgieNatureMetamphse.AutoSize = true;
            this.lblMgieNatureMetamphse.Location = new System.Drawing.Point(34, 127);
            this.lblMgieNatureMetamphse.Name = "lblMgieNatureMetamphse";
            this.lblMgieNatureMetamphse.Size = new System.Drawing.Size(291, 13);
            this.lblMgieNatureMetamphse.TabIndex = 173;
            this.lblMgieNatureMetamphse.Text = "Métamorphose : créatures qui existent et vues par le lanceur";
            // 
            // chkMgieNatureVsionNoir
            // 
            this.chkMgieNatureVsionNoir.AutoSize = true;
            this.chkMgieNatureVsionNoir.Location = new System.Drawing.Point(13, 102);
            this.chkMgieNatureVsionNoir.Name = "chkMgieNatureVsionNoir";
            this.chkMgieNatureVsionNoir.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNatureVsionNoir.TabIndex = 172;
            this.chkMgieNatureVsionNoir.UseVisualStyleBackColor = true;
            this.chkMgieNatureVsionNoir.Click += new System.EventHandler(this.chkMgieNatureVsionNoir_Click);
            // 
            // lblMgieNatureVsionNoir
            // 
            this.lblMgieNatureVsionNoir.AutoSize = true;
            this.lblMgieNatureVsionNoir.Location = new System.Drawing.Point(34, 102);
            this.lblMgieNatureVsionNoir.Name = "lblMgieNatureVsionNoir";
            this.lblMgieNatureVsionNoir.Size = new System.Drawing.Size(92, 13);
            this.lblMgieNatureVsionNoir.TabIndex = 171;
            this.lblMgieNatureVsionNoir.Text = "Vision dans le noir";
            // 
            // chkMgieNatureChgmTemp
            // 
            this.chkMgieNatureChgmTemp.AutoSize = true;
            this.chkMgieNatureChgmTemp.Location = new System.Drawing.Point(13, 77);
            this.chkMgieNatureChgmTemp.Name = "chkMgieNatureChgmTemp";
            this.chkMgieNatureChgmTemp.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNatureChgmTemp.TabIndex = 170;
            this.chkMgieNatureChgmTemp.UseVisualStyleBackColor = true;
            this.chkMgieNatureChgmTemp.Click += new System.EventHandler(this.chkMgieNatureChgmTemp_Click);
            // 
            // lblMgieNatureChgmTemp
            // 
            this.lblMgieNatureChgmTemp.AutoSize = true;
            this.lblMgieNatureChgmTemp.Location = new System.Drawing.Point(34, 77);
            this.lblMgieNatureChgmTemp.Name = "lblMgieNatureChgmTemp";
            this.lblMgieNatureChgmTemp.Size = new System.Drawing.Size(152, 13);
            this.lblMgieNatureChgmTemp.TabIndex = 169;
            this.lblMgieNatureChgmTemp.Text = "Changement de la température";
            // 
            // chkMgieNatureInvoc
            // 
            this.chkMgieNatureInvoc.AutoSize = true;
            this.chkMgieNatureInvoc.Location = new System.Drawing.Point(13, 52);
            this.chkMgieNatureInvoc.Name = "chkMgieNatureInvoc";
            this.chkMgieNatureInvoc.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNatureInvoc.TabIndex = 168;
            this.chkMgieNatureInvoc.UseVisualStyleBackColor = true;
            this.chkMgieNatureInvoc.Click += new System.EventHandler(this.chkMgieNatureInvoc_Click);
            // 
            // lblMgieNatureInvoc
            // 
            this.lblMgieNatureInvoc.AutoSize = true;
            this.lblMgieNatureInvoc.Location = new System.Drawing.Point(34, 52);
            this.lblMgieNatureInvoc.Name = "lblMgieNatureInvoc";
            this.lblMgieNatureInvoc.Size = new System.Drawing.Size(269, 13);
            this.lblMgieNatureInvoc.TabIndex = 167;
            this.lblMgieNatureInvoc.Text = "Invocation d\'un familier (créature connue par le lanceur)";
            // 
            // chkMgieNatureComm
            // 
            this.chkMgieNatureComm.AutoSize = true;
            this.chkMgieNatureComm.Location = new System.Drawing.Point(13, 27);
            this.chkMgieNatureComm.Name = "chkMgieNatureComm";
            this.chkMgieNatureComm.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNatureComm.TabIndex = 166;
            this.chkMgieNatureComm.UseVisualStyleBackColor = true;
            this.chkMgieNatureComm.Click += new System.EventHandler(this.chkMgieNatureComm_Click);
            // 
            // lblMgieNatureComm
            // 
            this.lblMgieNatureComm.AutoSize = true;
            this.lblMgieNatureComm.Location = new System.Drawing.Point(34, 27);
            this.lblMgieNatureComm.Name = "lblMgieNatureComm";
            this.lblMgieNatureComm.Size = new System.Drawing.Size(295, 13);
            this.lblMgieNatureComm.TabIndex = 165;
            this.lblMgieNatureComm.Text = "Communication avec l\'environnement (plantes, animaux, etc.)";
            // 
            // lblNomMNature
            // 
            this.lblNomMNature.AutoSize = true;
            this.lblNomMNature.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomMNature.Location = new System.Drawing.Point(34, 3);
            this.lblNomMNature.Name = "lblNomMNature";
            this.lblNomMNature.Size = new System.Drawing.Size(29, 13);
            this.lblNomMNature.TabIndex = 164;
            this.lblNomMNature.Text = "Nom";
            // 
            // tpDivine
            // 
            this.tpDivine.Controls.Add(this.chkMgieDivineDvnation);
            this.tpDivine.Controls.Add(this.lblMgieDivineDvnation);
            this.tpDivine.Controls.Add(this.chkMgieDivineBene);
            this.tpDivine.Controls.Add(this.lblMgieDivineBene);
            this.tpDivine.Controls.Add(this.chkMgieDivineGueri);
            this.tpDivine.Controls.Add(this.lblMgieDivineGueri);
            this.tpDivine.Controls.Add(this.chkMgieDivineRestauration);
            this.tpDivine.Controls.Add(this.lblMgieDivineRestauration);
            this.tpDivine.Controls.Add(this.chkMgieDivineBclrPrtc);
            this.tpDivine.Controls.Add(this.lblMgieDivineBclrPrtc);
            this.tpDivine.Controls.Add(this.lblNomMDivine);
            this.tpDivine.Location = new System.Drawing.Point(4, 22);
            this.tpDivine.Name = "tpDivine";
            this.tpDivine.Size = new System.Drawing.Size(408, 163);
            this.tpDivine.TabIndex = 5;
            this.tpDivine.Text = "M.Divine";
            this.tpDivine.UseVisualStyleBackColor = true;
            // 
            // chkMgieDivineDvnation
            // 
            this.chkMgieDivineDvnation.AutoSize = true;
            this.chkMgieDivineDvnation.Location = new System.Drawing.Point(13, 127);
            this.chkMgieDivineDvnation.Name = "chkMgieDivineDvnation";
            this.chkMgieDivineDvnation.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDivineDvnation.TabIndex = 177;
            this.chkMgieDivineDvnation.UseVisualStyleBackColor = true;
            this.chkMgieDivineDvnation.Click += new System.EventHandler(this.chkMgieDivineDvnation_Click);
            // 
            // lblMgieDivineDvnation
            // 
            this.lblMgieDivineDvnation.AutoSize = true;
            this.lblMgieDivineDvnation.Location = new System.Drawing.Point(34, 127);
            this.lblMgieDivineDvnation.Name = "lblMgieDivineDvnation";
            this.lblMgieDivineDvnation.Size = new System.Drawing.Size(250, 13);
            this.lblMgieDivineDvnation.TabIndex = 176;
            this.lblMgieDivineDvnation.Text = "Divination: Vision du passé, vision d\'un futur proche";
            // 
            // chkMgieDivineBene
            // 
            this.chkMgieDivineBene.AutoSize = true;
            this.chkMgieDivineBene.Location = new System.Drawing.Point(13, 102);
            this.chkMgieDivineBene.Name = "chkMgieDivineBene";
            this.chkMgieDivineBene.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDivineBene.TabIndex = 175;
            this.chkMgieDivineBene.UseVisualStyleBackColor = true;
            this.chkMgieDivineBene.Click += new System.EventHandler(this.chkMgieDivineBene_Click);
            // 
            // lblMgieDivineBene
            // 
            this.lblMgieDivineBene.AutoSize = true;
            this.lblMgieDivineBene.Location = new System.Drawing.Point(34, 102);
            this.lblMgieDivineBene.Name = "lblMgieDivineBene";
            this.lblMgieDivineBene.Size = new System.Drawing.Size(152, 13);
            this.lblMgieDivineBene.TabIndex = 174;
            this.lblMgieDivineBene.Text = "Bénédiction: béni une créature";
            // 
            // chkMgieDivineGueri
            // 
            this.chkMgieDivineGueri.AutoSize = true;
            this.chkMgieDivineGueri.Location = new System.Drawing.Point(13, 77);
            this.chkMgieDivineGueri.Name = "chkMgieDivineGueri";
            this.chkMgieDivineGueri.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDivineGueri.TabIndex = 173;
            this.chkMgieDivineGueri.UseVisualStyleBackColor = true;
            this.chkMgieDivineGueri.Click += new System.EventHandler(this.chkMgieDivineGueri_Click);
            // 
            // lblMgieDivineGueri
            // 
            this.lblMgieDivineGueri.AutoSize = true;
            this.lblMgieDivineGueri.Location = new System.Drawing.Point(34, 77);
            this.lblMgieDivineGueri.Name = "lblMgieDivineGueri";
            this.lblMgieDivineGueri.Size = new System.Drawing.Size(233, 13);
            this.lblMgieDivineGueri.TabIndex = 172;
            this.lblMgieDivineGueri.Text = "Guérison: soigne maladie, poison, paralysie, etc.";
            // 
            // chkMgieDivineRestauration
            // 
            this.chkMgieDivineRestauration.AutoSize = true;
            this.chkMgieDivineRestauration.Location = new System.Drawing.Point(13, 52);
            this.chkMgieDivineRestauration.Name = "chkMgieDivineRestauration";
            this.chkMgieDivineRestauration.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDivineRestauration.TabIndex = 171;
            this.chkMgieDivineRestauration.UseVisualStyleBackColor = true;
            this.chkMgieDivineRestauration.Click += new System.EventHandler(this.chkMgieDivineRestauration_Click);
            // 
            // lblMgieDivineRestauration
            // 
            this.lblMgieDivineRestauration.AutoSize = true;
            this.lblMgieDivineRestauration.Location = new System.Drawing.Point(34, 52);
            this.lblMgieDivineRestauration.Name = "lblMgieDivineRestauration";
            this.lblMgieDivineRestauration.Size = new System.Drawing.Size(359, 13);
            this.lblMgieDivineRestauration.TabIndex = 170;
            this.lblMgieDivineRestauration.Text = "Restauration : soigne les blessures, mais ne fait pas repousser les membres";
            // 
            // chkMgieDivineBclrPrtc
            // 
            this.chkMgieDivineBclrPrtc.AutoSize = true;
            this.chkMgieDivineBclrPrtc.Location = new System.Drawing.Point(13, 27);
            this.chkMgieDivineBclrPrtc.Name = "chkMgieDivineBclrPrtc";
            this.chkMgieDivineBclrPrtc.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDivineBclrPrtc.TabIndex = 169;
            this.chkMgieDivineBclrPrtc.UseVisualStyleBackColor = true;
            this.chkMgieDivineBclrPrtc.Click += new System.EventHandler(this.chkMgieDivineBclrPrtc_Click);
            // 
            // lblMgieDivineBclrPrtc
            // 
            this.lblMgieDivineBclrPrtc.AutoSize = true;
            this.lblMgieDivineBclrPrtc.Location = new System.Drawing.Point(34, 27);
            this.lblMgieDivineBclrPrtc.Name = "lblMgieDivineBclrPrtc";
            this.lblMgieDivineBclrPrtc.Size = new System.Drawing.Size(297, 13);
            this.lblMgieDivineBclrPrtc.TabIndex = 168;
            this.lblMgieDivineBclrPrtc.Text = "Bouclier de protection: champ protecteur dans un rayon défini";
            // 
            // lblNomMDivine
            // 
            this.lblNomMDivine.AutoSize = true;
            this.lblNomMDivine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomMDivine.Location = new System.Drawing.Point(34, 3);
            this.lblNomMDivine.Name = "lblNomMDivine";
            this.lblNomMDivine.Size = new System.Drawing.Size(29, 13);
            this.lblNomMDivine.TabIndex = 167;
            this.lblNomMDivine.Text = "Nom";
            // 
            // tpDemoniaque
            // 
            this.tpDemoniaque.Controls.Add(this.chkMgieDemoniaqueIllusions);
            this.tpDemoniaque.Controls.Add(this.lblMgieDemoniaqueIllusion);
            this.tpDemoniaque.Controls.Add(this.chkMgieDemoniaqueCntrole);
            this.tpDemoniaque.Controls.Add(this.lblMgieDemoniaqueCntrole);
            this.tpDemoniaque.Controls.Add(this.chkMgieDemoniaqueMldction);
            this.tpDemoniaque.Controls.Add(this.lblMgieDemoniaqueMldction);
            this.tpDemoniaque.Controls.Add(this.chkMgieDemoniaqueNecro);
            this.tpDemoniaque.Controls.Add(this.lblMgieDemoniaqueNecro);
            this.tpDemoniaque.Controls.Add(this.chkMgieDemoniaqueAbspton);
            this.tpDemoniaque.Controls.Add(this.lblMgieDemoniaqueAbspton);
            this.tpDemoniaque.Controls.Add(this.lblNomMDemoniaque);
            this.tpDemoniaque.Location = new System.Drawing.Point(4, 22);
            this.tpDemoniaque.Name = "tpDemoniaque";
            this.tpDemoniaque.Size = new System.Drawing.Size(408, 163);
            this.tpDemoniaque.TabIndex = 6;
            this.tpDemoniaque.Text = "M.Démoniaque";
            this.tpDemoniaque.UseVisualStyleBackColor = true;
            // 
            // chkMgieDemoniaqueIllusions
            // 
            this.chkMgieDemoniaqueIllusions.AutoSize = true;
            this.chkMgieDemoniaqueIllusions.Location = new System.Drawing.Point(13, 127);
            this.chkMgieDemoniaqueIllusions.Name = "chkMgieDemoniaqueIllusions";
            this.chkMgieDemoniaqueIllusions.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDemoniaqueIllusions.TabIndex = 180;
            this.chkMgieDemoniaqueIllusions.UseVisualStyleBackColor = true;
            this.chkMgieDemoniaqueIllusions.Click += new System.EventHandler(this.chkMgieDemoniaqueIllusions_Click);
            // 
            // lblMgieDemoniaqueIllusion
            // 
            this.lblMgieDemoniaqueIllusion.AutoSize = true;
            this.lblMgieDemoniaqueIllusion.Location = new System.Drawing.Point(34, 127);
            this.lblMgieDemoniaqueIllusion.Name = "lblMgieDemoniaqueIllusion";
            this.lblMgieDemoniaqueIllusion.Size = new System.Drawing.Size(273, 13);
            this.lblMgieDemoniaqueIllusion.TabIndex = 179;
            this.lblMgieDemoniaqueIllusion.Text = "Illusion : la cible a des hallucinations du choix du lanceur";
            // 
            // chkMgieDemoniaqueCntrole
            // 
            this.chkMgieDemoniaqueCntrole.AutoSize = true;
            this.chkMgieDemoniaqueCntrole.Location = new System.Drawing.Point(13, 102);
            this.chkMgieDemoniaqueCntrole.Name = "chkMgieDemoniaqueCntrole";
            this.chkMgieDemoniaqueCntrole.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDemoniaqueCntrole.TabIndex = 178;
            this.chkMgieDemoniaqueCntrole.UseVisualStyleBackColor = true;
            this.chkMgieDemoniaqueCntrole.Click += new System.EventHandler(this.chkMgieDemoniaqueCntrole_Click);
            // 
            // lblMgieDemoniaqueCntrole
            // 
            this.lblMgieDemoniaqueCntrole.AutoSize = true;
            this.lblMgieDemoniaqueCntrole.Location = new System.Drawing.Point(34, 102);
            this.lblMgieDemoniaqueCntrole.Name = "lblMgieDemoniaqueCntrole";
            this.lblMgieDemoniaqueCntrole.Size = new System.Drawing.Size(300, 13);
            this.lblMgieDemoniaqueCntrole.TabIndex = 177;
            this.lblMgieDemoniaqueCntrole.Text = "Contrôle: possession, forcer une créature à agir contre son gré";
            // 
            // chkMgieDemoniaqueMldction
            // 
            this.chkMgieDemoniaqueMldction.AutoSize = true;
            this.chkMgieDemoniaqueMldction.Location = new System.Drawing.Point(13, 77);
            this.chkMgieDemoniaqueMldction.Name = "chkMgieDemoniaqueMldction";
            this.chkMgieDemoniaqueMldction.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDemoniaqueMldction.TabIndex = 176;
            this.chkMgieDemoniaqueMldction.UseVisualStyleBackColor = true;
            this.chkMgieDemoniaqueMldction.Click += new System.EventHandler(this.chkMgieDemoniaqueMldction_Click);
            // 
            // lblMgieDemoniaqueMldction
            // 
            this.lblMgieDemoniaqueMldction.AutoSize = true;
            this.lblMgieDemoniaqueMldction.Location = new System.Drawing.Point(34, 77);
            this.lblMgieDemoniaqueMldction.Name = "lblMgieDemoniaqueMldction";
            this.lblMgieDemoniaqueMldction.Size = new System.Drawing.Size(271, 13);
            this.lblMgieDemoniaqueMldction.TabIndex = 175;
            this.lblMgieDemoniaqueMldction.Text = "Malédiction: maudire une personne, jeter le mauvais sort";
            // 
            // chkMgieDemoniaqueNecro
            // 
            this.chkMgieDemoniaqueNecro.AutoSize = true;
            this.chkMgieDemoniaqueNecro.Location = new System.Drawing.Point(13, 52);
            this.chkMgieDemoniaqueNecro.Name = "chkMgieDemoniaqueNecro";
            this.chkMgieDemoniaqueNecro.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDemoniaqueNecro.TabIndex = 174;
            this.chkMgieDemoniaqueNecro.UseVisualStyleBackColor = true;
            this.chkMgieDemoniaqueNecro.Click += new System.EventHandler(this.chkMgieDemoniaqueNecro_Click);
            // 
            // lblMgieDemoniaqueNecro
            // 
            this.lblMgieDemoniaqueNecro.AutoSize = true;
            this.lblMgieDemoniaqueNecro.Location = new System.Drawing.Point(34, 52);
            this.lblMgieDemoniaqueNecro.Name = "lblMgieDemoniaqueNecro";
            this.lblMgieDemoniaqueNecro.Size = new System.Drawing.Size(367, 13);
            this.lblMgieDemoniaqueNecro.TabIndex = 173;
            this.lblMgieDemoniaqueNecro.Text = "Nécromancie: ramener des cadavres sous son joug, parler avec les spectres";
            // 
            // chkMgieDemoniaqueAbspton
            // 
            this.chkMgieDemoniaqueAbspton.AutoSize = true;
            this.chkMgieDemoniaqueAbspton.Location = new System.Drawing.Point(13, 27);
            this.chkMgieDemoniaqueAbspton.Name = "chkMgieDemoniaqueAbspton";
            this.chkMgieDemoniaqueAbspton.Size = new System.Drawing.Size(15, 14);
            this.chkMgieDemoniaqueAbspton.TabIndex = 172;
            this.chkMgieDemoniaqueAbspton.UseVisualStyleBackColor = true;
            this.chkMgieDemoniaqueAbspton.Click += new System.EventHandler(this.chkMgieDemoniaqueAbspton_Click);
            // 
            // lblMgieDemoniaqueAbspton
            // 
            this.lblMgieDemoniaqueAbspton.AutoSize = true;
            this.lblMgieDemoniaqueAbspton.Location = new System.Drawing.Point(34, 27);
            this.lblMgieDemoniaqueAbspton.Name = "lblMgieDemoniaqueAbspton";
            this.lblMgieDemoniaqueAbspton.Size = new System.Drawing.Size(307, 13);
            this.lblMgieDemoniaqueAbspton.TabIndex = 171;
            this.lblMgieDemoniaqueAbspton.Text = "Absorption: points de vie, énergie (uniquement les êtres vivants)";
            // 
            // lblNomMDemoniaque
            // 
            this.lblNomMDemoniaque.AutoSize = true;
            this.lblNomMDemoniaque.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomMDemoniaque.Location = new System.Drawing.Point(34, 3);
            this.lblNomMDemoniaque.Name = "lblNomMDemoniaque";
            this.lblNomMDemoniaque.Size = new System.Drawing.Size(29, 13);
            this.lblNomMDemoniaque.TabIndex = 170;
            this.lblNomMDemoniaque.Text = "Nom";
            // 
            // tpNeutre
            // 
            this.tpNeutre.Controls.Add(this.chkMgieNeutreTelkinesie);
            this.tpNeutre.Controls.Add(this.lblMgieNeutreTelkinesie);
            this.tpNeutre.Controls.Add(this.chkMgieNeutreMsg);
            this.tpNeutre.Controls.Add(this.lblMgieNeutreMsg);
            this.tpNeutre.Controls.Add(this.chkMgieNeutreSsie);
            this.tpNeutre.Controls.Add(this.lblMgieNeutreSsie);
            this.tpNeutre.Controls.Add(this.chkMgieNeutreInvsbilté);
            this.tpNeutre.Controls.Add(this.lblMgieNeutreInvsbilté);
            this.tpNeutre.Controls.Add(this.chkMgieNeutreAltration);
            this.tpNeutre.Controls.Add(this.lblMgieNeutreAltration);
            this.tpNeutre.Controls.Add(this.lblNomMNeutre);
            this.tpNeutre.Location = new System.Drawing.Point(4, 22);
            this.tpNeutre.Name = "tpNeutre";
            this.tpNeutre.Size = new System.Drawing.Size(408, 163);
            this.tpNeutre.TabIndex = 7;
            this.tpNeutre.Text = "M.Neutre";
            this.tpNeutre.UseVisualStyleBackColor = true;
            // 
            // chkMgieNeutreTelkinesie
            // 
            this.chkMgieNeutreTelkinesie.AutoSize = true;
            this.chkMgieNeutreTelkinesie.Location = new System.Drawing.Point(13, 127);
            this.chkMgieNeutreTelkinesie.Name = "chkMgieNeutreTelkinesie";
            this.chkMgieNeutreTelkinesie.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNeutreTelkinesie.TabIndex = 183;
            this.chkMgieNeutreTelkinesie.UseVisualStyleBackColor = true;
            this.chkMgieNeutreTelkinesie.Click += new System.EventHandler(this.chkMgieNeutreTelkinesie_Click);
            // 
            // lblMgieNeutreTelkinesie
            // 
            this.lblMgieNeutreTelkinesie.AutoSize = true;
            this.lblMgieNeutreTelkinesie.Location = new System.Drawing.Point(34, 127);
            this.lblMgieNeutreTelkinesie.Name = "lblMgieNeutreTelkinesie";
            this.lblMgieNeutreTelkinesie.Size = new System.Drawing.Size(61, 13);
            this.lblMgieNeutreTelkinesie.TabIndex = 182;
            this.lblMgieNeutreTelkinesie.Text = "Télékinésie";
            // 
            // chkMgieNeutreMsg
            // 
            this.chkMgieNeutreMsg.AutoSize = true;
            this.chkMgieNeutreMsg.Location = new System.Drawing.Point(13, 102);
            this.chkMgieNeutreMsg.Name = "chkMgieNeutreMsg";
            this.chkMgieNeutreMsg.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNeutreMsg.TabIndex = 181;
            this.chkMgieNeutreMsg.UseVisualStyleBackColor = true;
            this.chkMgieNeutreMsg.Click += new System.EventHandler(this.chkMgieNeutreMsg_Click);
            // 
            // lblMgieNeutreMsg
            // 
            this.lblMgieNeutreMsg.AutoSize = true;
            this.lblMgieNeutreMsg.Location = new System.Drawing.Point(34, 102);
            this.lblMgieNeutreMsg.Name = "lblMgieNeutreMsg";
            this.lblMgieNeutreMsg.Size = new System.Drawing.Size(253, 13);
            this.lblMgieNeutreMsg.TabIndex = 180;
            this.lblMgieNeutreMsg.Text = "Message: connexion mentale, images mentales, etc.";
            // 
            // chkMgieNeutreSsie
            // 
            this.chkMgieNeutreSsie.AutoSize = true;
            this.chkMgieNeutreSsie.Location = new System.Drawing.Point(13, 77);
            this.chkMgieNeutreSsie.Name = "chkMgieNeutreSsie";
            this.chkMgieNeutreSsie.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNeutreSsie.TabIndex = 179;
            this.chkMgieNeutreSsie.UseVisualStyleBackColor = true;
            this.chkMgieNeutreSsie.Click += new System.EventHandler(this.chkMgieNeutreSsie_Click);
            // 
            // lblMgieNeutreSsie
            // 
            this.lblMgieNeutreSsie.AutoSize = true;
            this.lblMgieNeutreSsie.Location = new System.Drawing.Point(34, 77);
            this.lblMgieNeutreSsie.Name = "lblMgieNeutreSsie";
            this.lblMgieNeutreSsie.Size = new System.Drawing.Size(194, 13);
            this.lblMgieNeutreSsie.TabIndex = 178;
            this.lblMgieNeutreSsie.Text = "Sosie (clones, images rémanentes, etc.)";
            // 
            // chkMgieNeutreInvsbilté
            // 
            this.chkMgieNeutreInvsbilté.AutoSize = true;
            this.chkMgieNeutreInvsbilté.Location = new System.Drawing.Point(13, 52);
            this.chkMgieNeutreInvsbilté.Name = "chkMgieNeutreInvsbilté";
            this.chkMgieNeutreInvsbilté.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNeutreInvsbilté.TabIndex = 177;
            this.chkMgieNeutreInvsbilté.UseVisualStyleBackColor = true;
            this.chkMgieNeutreInvsbilté.Click += new System.EventHandler(this.chkMgieNeutreInvsbilté_Click);
            // 
            // lblMgieNeutreInvsbilté
            // 
            this.lblMgieNeutreInvsbilté.AutoSize = true;
            this.lblMgieNeutreInvsbilté.Location = new System.Drawing.Point(34, 52);
            this.lblMgieNeutreInvsbilté.Name = "lblMgieNeutreInvsbilté";
            this.lblMgieNeutreInvsbilté.Size = new System.Drawing.Size(328, 13);
            this.lblMgieNeutreInvsbilté.TabIndex = 176;
            this.lblMgieNeutreInvsbilté.Text = "Invisibilé: peut devenir un invisible, détection des créatures cachées";
            // 
            // chkMgieNeutreAltration
            // 
            this.chkMgieNeutreAltration.AutoSize = true;
            this.chkMgieNeutreAltration.Location = new System.Drawing.Point(13, 27);
            this.chkMgieNeutreAltration.Name = "chkMgieNeutreAltration";
            this.chkMgieNeutreAltration.Size = new System.Drawing.Size(15, 14);
            this.chkMgieNeutreAltration.TabIndex = 175;
            this.chkMgieNeutreAltration.UseVisualStyleBackColor = true;
            this.chkMgieNeutreAltration.Click += new System.EventHandler(this.chkMgieNeutreAltration_Click);
            // 
            // lblMgieNeutreAltration
            // 
            this.lblMgieNeutreAltration.AutoSize = true;
            this.lblMgieNeutreAltration.Location = new System.Drawing.Point(34, 27);
            this.lblMgieNeutreAltration.Name = "lblMgieNeutreAltration";
            this.lblMgieNeutreAltration.Size = new System.Drawing.Size(316, 13);
            this.lblMgieNeutreAltration.TabIndex = 174;
            this.lblMgieNeutreAltration.Text = "Altération corporelle (supersaut, super force, un bras en plus, etc.)";
            // 
            // lblNomMNeutre
            // 
            this.lblNomMNeutre.AutoSize = true;
            this.lblNomMNeutre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomMNeutre.Location = new System.Drawing.Point(34, 3);
            this.lblNomMNeutre.Name = "lblNomMNeutre";
            this.lblNomMNeutre.Size = new System.Drawing.Size(29, 13);
            this.lblNomMNeutre.TabIndex = 173;
            this.lblNomMNeutre.Text = "Nom";
            // 
            // rchTbSorts
            // 
            this.rchTbSorts.Location = new System.Drawing.Point(729, 209);
            this.rchTbSorts.Name = "rchTbSorts";
            this.rchTbSorts.Size = new System.Drawing.Size(412, 39);
            this.rchTbSorts.TabIndex = 9;
            this.rchTbSorts.Text = "";
            this.rchTbSorts.TextChanged += new System.EventHandler(this.rchTbSorts_TextChanged);
            // 
            // btnViderRchTbInventaires
            // 
            this.btnViderRchTbInventaires.Location = new System.Drawing.Point(245, 428);
            this.btnViderRchTbInventaires.Name = "btnViderRchTbInventaires";
            this.btnViderRchTbInventaires.Size = new System.Drawing.Size(220, 23);
            this.btnViderRchTbInventaires.TabIndex = 10;
            this.btnViderRchTbInventaires.Text = "Vider inventaires";
            this.btnViderRchTbInventaires.UseVisualStyleBackColor = true;
            this.btnViderRchTbInventaires.Click += new System.EventHandler(this.btnViderRchTbInventaires_Click);
            // 
            // btnViderRchTbSortileges
            // 
            this.btnViderRchTbSortileges.Location = new System.Drawing.Point(880, 254);
            this.btnViderRchTbSortileges.Name = "btnViderRchTbSortileges";
            this.btnViderRchTbSortileges.Size = new System.Drawing.Size(116, 23);
            this.btnViderRchTbSortileges.TabIndex = 11;
            this.btnViderRchTbSortileges.Text = "Vider sortilèges";
            this.btnViderRchTbSortileges.UseVisualStyleBackColor = true;
            this.btnViderRchTbSortileges.Click += new System.EventHandler(this.btnViderRchTbSortileges_Click);
            // 
            // lblChargeRestanteProgressBar
            // 
            this.lblChargeRestanteProgressBar.AutoSize = true;
            this.lblChargeRestanteProgressBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChargeRestanteProgressBar.Location = new System.Drawing.Point(34, 453);
            this.lblChargeRestanteProgressBar.Name = "lblChargeRestanteProgressBar";
            this.lblChargeRestanteProgressBar.Size = new System.Drawing.Size(88, 13);
            this.lblChargeRestanteProgressBar.TabIndex = 13;
            this.lblChargeRestanteProgressBar.Text = "Charge restante :";
            // 
            // lblSeparationRestanteMax
            // 
            this.lblSeparationRestanteMax.AutoSize = true;
            this.lblSeparationRestanteMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeparationRestanteMax.Location = new System.Drawing.Point(118, 472);
            this.lblSeparationRestanteMax.Name = "lblSeparationRestanteMax";
            this.lblSeparationRestanteMax.Size = new System.Drawing.Size(12, 16);
            this.lblSeparationRestanteMax.TabIndex = 15;
            this.lblSeparationRestanteMax.Text = "/";
            // 
            // lblChargeMaximale
            // 
            this.lblChargeMaximale.AutoSize = true;
            this.lblChargeMaximale.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChargeMaximale.Location = new System.Drawing.Point(132, 453);
            this.lblChargeMaximale.Name = "lblChargeMaximale";
            this.lblChargeMaximale.Size = new System.Drawing.Size(93, 13);
            this.lblChargeMaximale.TabIndex = 16;
            this.lblChargeMaximale.Text = "Charge maximale :";
            // 
            // txtChargeMaximale
            // 
            this.txtChargeMaximale.Enabled = false;
            this.txtChargeMaximale.Location = new System.Drawing.Point(153, 468);
            this.txtChargeMaximale.Name = "txtChargeMaximale";
            this.txtChargeMaximale.Size = new System.Drawing.Size(37, 20);
            this.txtChargeMaximale.TabIndex = 17;
            // 
            // txtChargeRestante
            // 
            this.txtChargeRestante.Enabled = false;
            this.txtChargeRestante.Location = new System.Drawing.Point(52, 468);
            this.txtChargeRestante.Name = "txtChargeRestante";
            this.txtChargeRestante.Size = new System.Drawing.Size(46, 20);
            this.txtChargeRestante.TabIndex = 18;
            // 
            // lblCuivre
            // 
            this.lblCuivre.AutoSize = true;
            this.lblCuivre.Location = new System.Drawing.Point(620, 453);
            this.lblCuivre.Name = "lblCuivre";
            this.lblCuivre.Size = new System.Drawing.Size(37, 13);
            this.lblCuivre.TabIndex = 43;
            this.lblCuivre.Text = "Cuivre";
            // 
            // lblArgent
            // 
            this.lblArgent.AutoSize = true;
            this.lblArgent.Location = new System.Drawing.Point(560, 453);
            this.lblArgent.Name = "lblArgent";
            this.lblArgent.Size = new System.Drawing.Size(38, 13);
            this.lblArgent.TabIndex = 42;
            this.lblArgent.Text = "Argent";
            // 
            // lblOr
            // 
            this.lblOr.AutoSize = true;
            this.lblOr.Location = new System.Drawing.Point(507, 453);
            this.lblOr.Name = "lblOr";
            this.lblOr.Size = new System.Drawing.Size(18, 13);
            this.lblOr.TabIndex = 41;
            this.lblOr.Text = "Or";
            // 
            // txtOr
            // 
            this.txtOr.Location = new System.Drawing.Point(496, 468);
            this.txtOr.Name = "txtOr";
            this.txtOr.Size = new System.Drawing.Size(37, 20);
            this.txtOr.TabIndex = 44;
            // 
            // txtArgent
            // 
            this.txtArgent.Location = new System.Drawing.Point(558, 468);
            this.txtArgent.Name = "txtArgent";
            this.txtArgent.Size = new System.Drawing.Size(37, 20);
            this.txtArgent.TabIndex = 45;
            // 
            // txtCuivre
            // 
            this.txtCuivre.Location = new System.Drawing.Point(620, 468);
            this.txtCuivre.Name = "txtCuivre";
            this.txtCuivre.Size = new System.Drawing.Size(37, 20);
            this.txtCuivre.TabIndex = 46;
            // 
            // FormulaireTalentsEtObjets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1171, 501);
            this.Controls.Add(this.txtCuivre);
            this.Controls.Add(this.txtArgent);
            this.Controls.Add(this.txtOr);
            this.Controls.Add(this.lblCuivre);
            this.Controls.Add(this.lblArgent);
            this.Controls.Add(this.lblOr);
            this.Controls.Add(this.txtChargeRestante);
            this.Controls.Add(this.txtChargeMaximale);
            this.Controls.Add(this.lblChargeMaximale);
            this.Controls.Add(this.lblSeparationRestanteMax);
            this.Controls.Add(this.lblChargeRestanteProgressBar);
            this.Controls.Add(this.btnViderRchTbSortileges);
            this.Controls.Add(this.btnViderRchTbInventaires);
            this.Controls.Add(this.rchTbSorts);
            this.Controls.Add(this.tcSortilege);
            this.Controls.Add(this.rchTxtIvtaires);
            this.Controls.Add(this.tcInventaires);
            this.Controls.Add(this.btnSauvegarder);
            this.Name = "FormulaireTalentsEtObjets";
            this.Text = "FormulaireDonsEtObjets";
            this.Load += new System.EventHandler(this.FormulaireTalentsEtObjets_Load);
            this.tcInventaires.ResumeLayout(false);
            this.tpArmes.ResumeLayout(false);
            this.tcArmes.ResumeLayout(false);
            this.tpEpee.ResumeLayout(false);
            this.tpEpee.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudEpBtrde)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEpBois)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSbreCrbe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGlve)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEpLge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEpCrte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudScrmx)).EndInit();
            this.tpLances.ResumeLayout(false);
            this.tpLances.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudTrdnt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSrse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFrche)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudJvlot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCntus)).EndInit();
            this.tpPoignards.ResumeLayout(false);
            this.tpPoignards.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDgeAssin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFclGure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCtau)).EndInit();
            this.tpHaches.ResumeLayout(false);
            this.tpHaches.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudHcheBhron)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFrncsque)).EndInit();
            this.tpMasse.ResumeLayout(false);
            this.tpMasse.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMrteauFgron)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMsueChne)).EndInit();
            this.tpArc.ResumeLayout(false);
            this.tpArc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFnde)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAblte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudArc)).EndInit();
            this.tpChaînes.ResumeLayout(false);
            this.tpChaînes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFaC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFouet)).EndInit();
            this.tpBatons.ResumeLayout(false);
            this.tpBatons.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSptreNeutre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBgteInfernale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCneLmiere)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBtonNture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudScptreTerre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBtonCelste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBgteFeu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCneAqua)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSctre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBtonChne)).EndInit();
            this.tpArmures.ResumeLayout(false);
            this.tcArmure.ResumeLayout(false);
            this.tbCasque.ResumeLayout(false);
            this.tbCasque.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCsqueBrbre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChplFr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrvlre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMrn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCfeMle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSpghlm)).EndInit();
            this.tpBuste.ResumeLayout(false);
            this.tpBuste.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrsBze)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRbeCuir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrsFr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCtphrcte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBrgne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVtments)).EndInit();
            this.tpGants.ResumeLayout(false);
            this.tpGants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMitne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGntlet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGntMles)).EndInit();
            this.tpGenouillere.ResumeLayout(false);
            this.tpGenouillere.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCmide)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPntlonTle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCuissrd)).EndInit();
            this.tpChaussures.ResumeLayout(false);
            this.tpChaussures.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSbton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudChssuresCuir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSndles)).EndInit();
            this.tpBouclier.ResumeLayout(false);
            this.tpBouclier.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCpeElfique)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPlta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBclrBze)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBclrAmde)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPvois)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEcu)).EndInit();
            this.tpObjets.ResumeLayout(false);
            this.tpObjets.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrauFr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrauBois)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlcheArgent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlcheFr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlcheBois)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCntrePson)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPlnteMcnale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCvture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMhoir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTnte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrde)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTrche)).EndInit();
            this.tcSortilege.ResumeLayout(false);
            this.tpAqua.ResumeLayout(false);
            this.tpAqua.PerformLayout();
            this.tpIgnis.ResumeLayout(false);
            this.tpIgnis.PerformLayout();
            this.tpCeleste.ResumeLayout(false);
            this.tpCeleste.PerformLayout();
            this.tpTerrestre.ResumeLayout(false);
            this.tpTerrestre.PerformLayout();
            this.tpNature.ResumeLayout(false);
            this.tpNature.PerformLayout();
            this.tpDivine.ResumeLayout(false);
            this.tpDivine.PerformLayout();
            this.tpDemoniaque.ResumeLayout(false);
            this.tpDemoniaque.PerformLayout();
            this.tpNeutre.ResumeLayout(false);
            this.tpNeutre.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSauvegarder;
        private System.Windows.Forms.Label lblPrtEpee;
        private System.Windows.Forms.Label lblNomEpee;
        private System.Windows.Forms.Label lblNbEpee;
        private System.Windows.Forms.Label lblPdsEpee;
        private System.Windows.Forms.Label lblDgtsEpee;
        private System.Windows.Forms.Label lblTpeEpee;
        private System.Windows.Forms.TabControl tcInventaires;
        private System.Windows.Forms.TabPage tpArmes;
        private System.Windows.Forms.TabControl tcArmes;
        private System.Windows.Forms.TabPage tpEpee;
        private System.Windows.Forms.TabPage tpLances;
        private System.Windows.Forms.Label lblNomLances;
        private System.Windows.Forms.Label lblPrtLances;
        private System.Windows.Forms.Label lblPdsLances;
        private System.Windows.Forms.Label lblNbLances;
        private System.Windows.Forms.Label lblTpeLances;
        private System.Windows.Forms.Label lblDgtsLances;
        private System.Windows.Forms.TabPage tpPoignards;
        private System.Windows.Forms.Label lblNomDagues;
        private System.Windows.Forms.Label lblPrteDagues;
        private System.Windows.Forms.Label lblPdsDagues;
        private System.Windows.Forms.Label lblNbDagues;
        private System.Windows.Forms.Label lblTypeDagues;
        private System.Windows.Forms.Label lblDgtsDagues;
        private System.Windows.Forms.Label lblNomCtau;
        private System.Windows.Forms.Label lblPdsCtau;
        private System.Windows.Forms.Label lblPrteCtau;
        private System.Windows.Forms.NumericUpDown nudCtau;
        private System.Windows.Forms.Label lblTpeCtau;
        private System.Windows.Forms.Label lblDgtsCtau;
        private System.Windows.Forms.Label lblNomDge;
        private System.Windows.Forms.Label lblPdsDge;
        private System.Windows.Forms.Label lblPrteDge;
        private System.Windows.Forms.NumericUpDown nudDge;
        private System.Windows.Forms.Label lblTpeDge;
        private System.Windows.Forms.Label lblDgtsDge;
        private System.Windows.Forms.TabPage tpHaches;
        private System.Windows.Forms.Label lblNomHache;
        private System.Windows.Forms.Label lblPrteHache;
        private System.Windows.Forms.Label lblPdsHache;
        private System.Windows.Forms.Label lblNbHache;
        private System.Windows.Forms.Label lblTpeHache;
        private System.Windows.Forms.Label lblDgtsHache;
        private System.Windows.Forms.TabPage tpMasse;
        private System.Windows.Forms.TabPage tpArc;
        private System.Windows.Forms.Label lblNomArcs;
        private System.Windows.Forms.Label lblPrteArcs;
        private System.Windows.Forms.Label lblPdsArcs;
        private System.Windows.Forms.Label lblNbArcs;
        private System.Windows.Forms.Label lblTpeArcs;
        private System.Windows.Forms.Label lblDgtsArcs;
        private System.Windows.Forms.Label lblNomArc;
        private System.Windows.Forms.Label lblPdsArc;
        private System.Windows.Forms.Label lblPrteArc;
        private System.Windows.Forms.NumericUpDown nudArc;
        private System.Windows.Forms.Label lblTpeArc;
        private System.Windows.Forms.Label lblDgtsArc;
        private System.Windows.Forms.Label lblNomAblte;
        private System.Windows.Forms.Label lblPdsAblte;
        private System.Windows.Forms.Label lblPrteAblte;
        private System.Windows.Forms.NumericUpDown nudAblte;
        private System.Windows.Forms.Label lblTpeAblte;
        private System.Windows.Forms.Label lblDgtsAblte;
        private System.Windows.Forms.TabPage tpChaînes;
        private System.Windows.Forms.Label lblNomChaines;
        private System.Windows.Forms.Label lblPdsChaines;
        private System.Windows.Forms.Label lblNbChaines;
        private System.Windows.Forms.Label lblTpeChaines;
        private System.Windows.Forms.Label lblDgtsChaines;
        private System.Windows.Forms.Label lblNomFouet;
        private System.Windows.Forms.NumericUpDown nudFouet;
        private System.Windows.Forms.Label lblTpeFouet;
        private System.Windows.Forms.Label lblDgtsFouet;
        private System.Windows.Forms.Label lblNomFaC;
        private System.Windows.Forms.Label lblPdsFaC;
        private System.Windows.Forms.NumericUpDown nudFaC;
        private System.Windows.Forms.Label lblTpeFaC;
        private System.Windows.Forms.Label lblDgtsFaC;
        private System.Windows.Forms.TabPage tpArmures;
        private System.Windows.Forms.TabControl tcArmure;
        private System.Windows.Forms.TabPage tbCasque;
        private System.Windows.Forms.TabPage tpBuste;
        private System.Windows.Forms.Label lblNomCasques;
        private System.Windows.Forms.Label lblPdsCasques;
        private System.Windows.Forms.Label lblNbCasques;
        private System.Windows.Forms.Label lblEftCasques;
        private System.Windows.Forms.TabPage tpGants;
        private System.Windows.Forms.TabPage tpGenouillere;
        private System.Windows.Forms.TabPage tpChaussures;
        private System.Windows.Forms.TabPage tpBouclier;
        private System.Windows.Forms.Label lblNomBuste;
        private System.Windows.Forms.Label lblPdsBuste;
        private System.Windows.Forms.Label lblNbBuste;
        private System.Windows.Forms.Label lblEftBuste;
        private System.Windows.Forms.Label lblNomVtments;
        private System.Windows.Forms.Label lblPdsVtments;
        private System.Windows.Forms.NumericUpDown nudVtments;
        private System.Windows.Forms.Label lblEftsVtments;
        private System.Windows.Forms.Label lblNomBrgne;
        private System.Windows.Forms.Label lblPdsBrgne;
        private System.Windows.Forms.NumericUpDown nudBrgne;
        private System.Windows.Forms.Label lblEftsBrgne;
        private System.Windows.Forms.Label lblNomGants;
        private System.Windows.Forms.Label lblPdsGants;
        private System.Windows.Forms.Label lblNbGants;
        private System.Windows.Forms.Label lblEftGants;
        private System.Windows.Forms.Label lblNomGntMles;
        private System.Windows.Forms.Label lblPdsGntMles;
        private System.Windows.Forms.NumericUpDown nudGntMles;
        private System.Windows.Forms.Label lblEftsGntMles;
        private System.Windows.Forms.Label lblNomGntlet;
        private System.Windows.Forms.Label lblPdsGntlet;
        private System.Windows.Forms.NumericUpDown nudGntlet;
        private System.Windows.Forms.Label lblEftsGntlet;
        private System.Windows.Forms.Label lblNomMitne;
        private System.Windows.Forms.Label lblPdsMitne;
        private System.Windows.Forms.NumericUpDown nudMitne;
        private System.Windows.Forms.Label lblEftsMitne;
        private System.Windows.Forms.Label lblNomCuissrd;
        private System.Windows.Forms.Label lblPdsCuissrd;
        private System.Windows.Forms.NumericUpDown nudCuissrd;
        private System.Windows.Forms.Label lblEftsCuissrd;
        private System.Windows.Forms.Label lblNomGenouilleres;
        private System.Windows.Forms.Label lblPdsGenouilleres;
        private System.Windows.Forms.Label lblNbGenouilleres;
        private System.Windows.Forms.Label lblEftGenouilleres;
        private System.Windows.Forms.Label lblNomMton;
        private System.Windows.Forms.Label lblPdsMton;
        private System.Windows.Forms.NumericUpDown nudMton;
        private System.Windows.Forms.Label lblEftsMton;
        private System.Windows.Forms.Label lblNomScrmx;
        private System.Windows.Forms.Label lblPdsScrmx;
        private System.Windows.Forms.Label lblPrteScrmx;
        private System.Windows.Forms.NumericUpDown nudScrmx;
        private System.Windows.Forms.Label lblTpeScrmx;
        private System.Windows.Forms.Label lblDgtsScrmx;
        private System.Windows.Forms.Label lblNomCtphrcte;
        private System.Windows.Forms.Label lblPdsCtphrcte;
        private System.Windows.Forms.NumericUpDown nudCtphrcte;
        private System.Windows.Forms.Label lblEftsCtphrcte;
        private System.Windows.Forms.Label lblNomCntus;
        private System.Windows.Forms.Label lblPdsCntus;
        private System.Windows.Forms.Label lblPrteCntus;
        private System.Windows.Forms.NumericUpDown nudCntus;
        private System.Windows.Forms.Label lblTpeCntus;
        private System.Windows.Forms.Label lblDgtsCntus;
        private System.Windows.Forms.Label lblNomFrncsque;
        private System.Windows.Forms.Label lblPdsFrncsque;
        private System.Windows.Forms.Label lblPrteFrncsque;
        private System.Windows.Forms.NumericUpDown nudFrncsque;
        private System.Windows.Forms.Label lblTpeFrncsque;
        private System.Windows.Forms.Label lblDgtsFrncsque;
        private System.Windows.Forms.Label lblNomEpCrte;
        private System.Windows.Forms.Label lblPdsEpCrte;
        private System.Windows.Forms.Label lblPrteEpCrte;
        private System.Windows.Forms.NumericUpDown nudEpCrte;
        private System.Windows.Forms.Label lblTpeEpCrte;
        private System.Windows.Forms.Label lblDgtsEpCrte;
        private System.Windows.Forms.Label lblNomEpLge;
        private System.Windows.Forms.Label lblPdsEpLge;
        private System.Windows.Forms.Label lblPrteEpLge;
        private System.Windows.Forms.NumericUpDown nudEpLge;
        private System.Windows.Forms.Label lblTpeEpLge;
        private System.Windows.Forms.Label lblDgtsEpLge;
        private System.Windows.Forms.Label lblNomGlve;
        private System.Windows.Forms.Label lblPdsGlve;
        private System.Windows.Forms.Label lblPrteGlve;
        private System.Windows.Forms.NumericUpDown nudGlve;
        private System.Windows.Forms.Label lblTpeGlve;
        private System.Windows.Forms.Label lblDgtsGlve;
        private System.Windows.Forms.Label lblNomJvlot;
        private System.Windows.Forms.Label lblPdsJvlot;
        private System.Windows.Forms.Label lblPrteJvlot;
        private System.Windows.Forms.NumericUpDown nudJvlot;
        private System.Windows.Forms.Label lblTpeJvlot;
        private System.Windows.Forms.Label lblDgtsJvlot;
        private System.Windows.Forms.Label lblNomLte;
        private System.Windows.Forms.Label lblPdsLte;
        private System.Windows.Forms.Label lblPrteLte;
        private System.Windows.Forms.Label lblTpeLte;
        private System.Windows.Forms.Label lblDgtsLte;
        private System.Windows.Forms.Label lblNomBoucliers;
        private System.Windows.Forms.Label lblPdsBoucliers;
        private System.Windows.Forms.Label lblNbBoucliers;
        private System.Windows.Forms.Label lblEftsBoucliers;
        private System.Windows.Forms.Label lblNomEcu;
        private System.Windows.Forms.Label lblPdsEcu;
        private System.Windows.Forms.NumericUpDown nudEcu;
        private System.Windows.Forms.Label lblEftsEcu;
        private System.Windows.Forms.Label lblNomSbreCrbe;
        private System.Windows.Forms.Label lblPdsSbreCrbe;
        private System.Windows.Forms.Label lblPrteSbreCrbe;
        private System.Windows.Forms.Label lblTpeSbreCrbe;
        private System.Windows.Forms.Label lblDgtsSbreCrbe;
        private System.Windows.Forms.Label lblNomSpghlm;
        private System.Windows.Forms.Label lblPdsSpghlm;
        private System.Windows.Forms.NumericUpDown nudSpghlm;
        private System.Windows.Forms.Label lblEftsSpghlm;
        private System.Windows.Forms.Label lblNomCfeMle;
        private System.Windows.Forms.Label lblPdsCfeMle;
        private System.Windows.Forms.NumericUpDown nudCfeMle;
        private System.Windows.Forms.Label lblEftsCfeMle;
        private System.Windows.Forms.Label lblNomCrsFr;
        private System.Windows.Forms.Label lblPdsCrsFr;
        private System.Windows.Forms.NumericUpDown nudCrsFr;
        private System.Windows.Forms.Label lblEftsCrsFr;
        private System.Windows.Forms.Label lblNomMrn;
        private System.Windows.Forms.Label lblPdsMrn;
        private System.Windows.Forms.NumericUpDown nudMrn;
        private System.Windows.Forms.Label lblEftsMrn;
        private System.Windows.Forms.Label lblNomCrvlre;
        private System.Windows.Forms.Label lblPdsCrvlre;
        private System.Windows.Forms.NumericUpDown nudCrvlre;
        private System.Windows.Forms.Label lblEftsCrvlre;
        private System.Windows.Forms.Label lblNomPvois;
        private System.Windows.Forms.Label lblPdsPvois;
        private System.Windows.Forms.NumericUpDown nudPvois;
        private System.Windows.Forms.Label lblEftsPvois;
        private System.Windows.Forms.Label lblNomBclrAmde;
        private System.Windows.Forms.Label lblPdsBclrAmde;
        private System.Windows.Forms.NumericUpDown nudBclrAmde;
        private System.Windows.Forms.Label lblEftsBclrAmde;
        private System.Windows.Forms.Label lblNomChplFr;
        private System.Windows.Forms.Label lblPdsChplFr;
        private System.Windows.Forms.NumericUpDown nudChplFr;
        private System.Windows.Forms.Label lblEftsChplFr;
        private System.Windows.Forms.TabPage tpObjets;
        private System.Windows.Forms.TabPage tpBatons;
        private System.Windows.Forms.Label lblNomBton;
        private System.Windows.Forms.Label lblPdsBton;
        private System.Windows.Forms.Label lblNbBton;
        private System.Windows.Forms.Label lblTpeBton;
        private System.Windows.Forms.Label lblDgtsBton;
        private System.Windows.Forms.Label lblNomBtonChne;
        private System.Windows.Forms.Label lblPdsBtonChne;
        private System.Windows.Forms.NumericUpDown nudBtonChne;
        private System.Windows.Forms.Label lblTpeBtonChne;
        private System.Windows.Forms.Label lblDgtsBtonChne;
        private System.Windows.Forms.Label lblEftsBtonChne;
        private System.Windows.Forms.Label lblEftsBton;
        private System.Windows.Forms.Label lblEftsSctre;
        private System.Windows.Forms.Label lblNomSctre;
        private System.Windows.Forms.Label lblPdsSctre;
        private System.Windows.Forms.NumericUpDown nudSctre;
        private System.Windows.Forms.Label lblTpeSctre;
        private System.Windows.Forms.Label lblDgtsSctre;
        private System.Windows.Forms.Label lblNomRbeCuir;
        private System.Windows.Forms.Label lblPdsRbeCuir;
        private System.Windows.Forms.NumericUpDown nudRbeCuir;
        private System.Windows.Forms.Label lblEftsRbeCuir;
        private System.Windows.Forms.Label lblNomFrche;
        private System.Windows.Forms.Label lblPdsFrche;
        private System.Windows.Forms.Label lblPrteFrche;
        private System.Windows.Forms.NumericUpDown nudFrche;
        private System.Windows.Forms.Label lblTpeFrche;
        private System.Windows.Forms.Label lblDgtsFrche;
        private System.Windows.Forms.Label lblNomSndles;
        private System.Windows.Forms.Label lblPdsSndles;
        private System.Windows.Forms.NumericUpDown nudSndles;
        private System.Windows.Forms.Label lblEftsSndles;
        private System.Windows.Forms.Label lblNomChssures;
        private System.Windows.Forms.Label lblPdsChssures;
        private System.Windows.Forms.Label lblNbChssures;
        private System.Windows.Forms.Label lblEftsChssures;
        private System.Windows.Forms.Label lblNomChssuresCuir;
        private System.Windows.Forms.Label lblPdsChssuresCuir;
        private System.Windows.Forms.NumericUpDown nudChssuresCuir;
        private System.Windows.Forms.Label lblEftsChssuresCuir;
        private System.Windows.Forms.Label lblNomPntlonTle;
        private System.Windows.Forms.Label lblPdsPntlonTle;
        private System.Windows.Forms.NumericUpDown nudPntlonTle;
        private System.Windows.Forms.Label lblEftsPntlonTle;
        private System.Windows.Forms.Label lblNomCrde;
        private System.Windows.Forms.Label lblPdsCrde;
        private System.Windows.Forms.NumericUpDown nudCrde;
        private System.Windows.Forms.Label lblEftsCrde;
        private System.Windows.Forms.Label lblNomTrche;
        private System.Windows.Forms.Label lblPdsTrche;
        private System.Windows.Forms.NumericUpDown nudTrche;
        private System.Windows.Forms.Label lblEftsTrche;
        private System.Windows.Forms.Label lblNomObjts;
        private System.Windows.Forms.Label lblPdsObjts;
        private System.Windows.Forms.Label lblNbObjts;
        private System.Windows.Forms.Label lblEftsObjts;
        private System.Windows.Forms.Label lblNomSrse;
        private System.Windows.Forms.Label lblPdsSrse;
        private System.Windows.Forms.Label lblPrteSrse;
        private System.Windows.Forms.NumericUpDown nudSrse;
        private System.Windows.Forms.Label lblTpeSrse;
        private System.Windows.Forms.Label lblDgtsSrse;
        private System.Windows.Forms.Label lblNomCmide;
        private System.Windows.Forms.Label lblPdsCmide;
        private System.Windows.Forms.NumericUpDown nudCmide;
        private System.Windows.Forms.Label lblEftsCmide;
        private System.Windows.Forms.Label lblNomCsqueBrbre;
        private System.Windows.Forms.Label lblPdsCsqueBrbre;
        private System.Windows.Forms.NumericUpDown nudCsqueBrbre;
        private System.Windows.Forms.Label lblEftsCsqueBrbre;
        private System.Windows.Forms.Label lblNomCrsBze;
        private System.Windows.Forms.Label lblPdsCrsBze;
        private System.Windows.Forms.NumericUpDown nudCrsBze;
        private System.Windows.Forms.Label lblEftsCrsBze;
        private System.Windows.Forms.Label lblNomBclrBze;
        private System.Windows.Forms.Label lblPdsBclrBze;
        private System.Windows.Forms.NumericUpDown nudBclrBze;
        private System.Windows.Forms.Label lblEftsBclrBze;
        private System.Windows.Forms.Label lblNomPlta;
        private System.Windows.Forms.Label lblPdsPlta;
        private System.Windows.Forms.NumericUpDown nudPlta;
        private System.Windows.Forms.Label lblEftsPlta;
        private System.Windows.Forms.Label lblNomFclGure;
        private System.Windows.Forms.Label lblPdsFclGure;
        private System.Windows.Forms.Label lblPrteFclGure;
        private System.Windows.Forms.NumericUpDown nudFclGure;
        private System.Windows.Forms.Label lblTpeFclGure;
        private System.Windows.Forms.Label lblDgtsFclGure;
        private System.Windows.Forms.Label lblNomFnde;
        private System.Windows.Forms.Label lblPrteFnde;
        private System.Windows.Forms.NumericUpDown nudFnde;
        private System.Windows.Forms.Label lblTpeFnde;
        private System.Windows.Forms.Label lblDgtsFnde;
        private System.Windows.Forms.Label lblTlleCrde;
        private System.Windows.Forms.Label lblTlleTrche;
        private System.Windows.Forms.Label lblTlleObjets;
        private System.Windows.Forms.Label lblTlleOte;
        private System.Windows.Forms.Label lblNomOte;
        private System.Windows.Forms.Label lblPdsOte;
        private System.Windows.Forms.NumericUpDown nudOte;
        private System.Windows.Forms.Label lblEftsOte;
        private System.Windows.Forms.Label lblTlleSc;
        private System.Windows.Forms.Label lblNomSc;
        private System.Windows.Forms.Label lblPdsSc;
        private System.Windows.Forms.NumericUpDown nudSc;
        private System.Windows.Forms.Label lblEftsSc;
        private System.Windows.Forms.Label lblTlleTnte;
        private System.Windows.Forms.Label lblNomTnte;
        private System.Windows.Forms.Label lblPdsTnte;
        private System.Windows.Forms.NumericUpDown nudTnte;
        private System.Windows.Forms.Label lblEftsTnte;
        private System.Windows.Forms.RichTextBox rchTxtIvtaires;
        private System.Windows.Forms.CheckBox chkArc;
        private System.Windows.Forms.CheckBox chkAblte;
        private System.Windows.Forms.CheckBox chkFnde;
        private System.Windows.Forms.CheckBox chkScrmx;
        private System.Windows.Forms.CheckBox chkEpCrte;
        private System.Windows.Forms.CheckBox chkEpLge;
        private System.Windows.Forms.CheckBox chkGlve;
        private System.Windows.Forms.CheckBox chkSbreCrbe;
        private System.Windows.Forms.CheckBox chkLte;
        private System.Windows.Forms.CheckBox chkCntus;
        private System.Windows.Forms.CheckBox chkJvlot;
        private System.Windows.Forms.CheckBox chkFrche;
        private System.Windows.Forms.CheckBox chkSrse;
        private System.Windows.Forms.CheckBox chkCtau;
        private System.Windows.Forms.CheckBox chkFclGure;
        private System.Windows.Forms.CheckBox chkDge;
        private System.Windows.Forms.CheckBox chkFrncsque;
        private System.Windows.Forms.CheckBox chkFouet;
        private System.Windows.Forms.CheckBox chkFaC;
        private System.Windows.Forms.CheckBox chkBtonChne;
        private System.Windows.Forms.Label lblPrteFaC;
        private System.Windows.Forms.Label lblPrteFouet;
        private System.Windows.Forms.Label lblPrteChaines;
        private System.Windows.Forms.Label lblPrteSctre;
        private System.Windows.Forms.Label lblPrteBtonChne;
        private System.Windows.Forms.Label lblPrteBton;
        private System.Windows.Forms.CheckBox chkSctre;
        private System.Windows.Forms.CheckBox chkCsqueBrbre;
        private System.Windows.Forms.CheckBox chkChplFr;
        private System.Windows.Forms.CheckBox chkCrvlre;
        private System.Windows.Forms.CheckBox chkMrn;
        private System.Windows.Forms.CheckBox chkCfeMle;
        private System.Windows.Forms.CheckBox chkSpghlm;
        private System.Windows.Forms.CheckBox chkVtments;
        private System.Windows.Forms.CheckBox chkBrgne;
        private System.Windows.Forms.CheckBox chkCrsFr;
        private System.Windows.Forms.CheckBox chkCtphrcte;
        private System.Windows.Forms.CheckBox chkRbeCuir;
        private System.Windows.Forms.CheckBox chkCrsBze;
        private System.Windows.Forms.CheckBox chkGntMles;
        private System.Windows.Forms.CheckBox chkGntlet;
        private System.Windows.Forms.CheckBox chkMton;
        private System.Windows.Forms.CheckBox chkMitne;
        private System.Windows.Forms.CheckBox chkCuissrd;
        private System.Windows.Forms.CheckBox chkPntlonTle;
        private System.Windows.Forms.CheckBox chkCmide;
        private System.Windows.Forms.CheckBox chkSndles;
        private System.Windows.Forms.CheckBox chkChssuresCuir;
        private System.Windows.Forms.CheckBox chkEcu;
        private System.Windows.Forms.CheckBox chkPvois;
        private System.Windows.Forms.CheckBox chkBclrAmde;
        private System.Windows.Forms.CheckBox chkBclrBze;
        private System.Windows.Forms.CheckBox chkPlta;
        private System.Windows.Forms.CheckBox chkTrche;
        private System.Windows.Forms.CheckBox chkCrde;
        private System.Windows.Forms.CheckBox chkOte;
        private System.Windows.Forms.CheckBox chkSc;
        private System.Windows.Forms.CheckBox chkTnte;
        private System.Windows.Forms.TabControl tcSortilege;
        private System.Windows.Forms.TabPage tpAqua;
        private System.Windows.Forms.TabPage tpIgnis;
        private System.Windows.Forms.TabPage tpCeleste;
        private System.Windows.Forms.TabPage tpTerrestre;
        private System.Windows.Forms.TabPage tpNature;
        private System.Windows.Forms.TabPage tpDivine;
        private System.Windows.Forms.TabPage tpDemoniaque;
        private System.Windows.Forms.TabPage tpNeutre;
        private System.Windows.Forms.CheckBox chkMgieAqua;
        private System.Windows.Forms.Label lblMgieAqua;
        private System.Windows.Forms.Label lblNomMAqua;
        private System.Windows.Forms.CheckBox chkMgieIgnis;
        private System.Windows.Forms.Label lblMgieIgnis;
        private System.Windows.Forms.Label lblNomMIgnis;
        private System.Windows.Forms.CheckBox chkMgieCeleste;
        private System.Windows.Forms.Label lblMgieCeleste;
        private System.Windows.Forms.Label lblNomMCeleste;
        private System.Windows.Forms.CheckBox chkMgieTerrestre;
        private System.Windows.Forms.Label lblMgieTerrestre;
        private System.Windows.Forms.Label lblNomMTerrestre;
        private System.Windows.Forms.CheckBox chkMgieNatureComm;
        private System.Windows.Forms.Label lblMgieNatureComm;
        private System.Windows.Forms.Label lblNomMNature;
        private System.Windows.Forms.CheckBox chkMgieNatureInvoc;
        private System.Windows.Forms.Label lblMgieNatureInvoc;
        private System.Windows.Forms.CheckBox chkMgieNatureChgmTemp;
        private System.Windows.Forms.Label lblMgieNatureChgmTemp;
        private System.Windows.Forms.CheckBox chkMgieNatureVsionNoir;
        private System.Windows.Forms.Label lblMgieNatureVsionNoir;
        private System.Windows.Forms.CheckBox chkMgieDivineBclrPrtc;
        private System.Windows.Forms.Label lblMgieDivineBclrPrtc;
        private System.Windows.Forms.Label lblNomMDivine;
        private System.Windows.Forms.CheckBox chkMgieDivineRestauration;
        private System.Windows.Forms.Label lblMgieDivineRestauration;
        private System.Windows.Forms.CheckBox chkMgieDivineGueri;
        private System.Windows.Forms.Label lblMgieDivineGueri;
        private System.Windows.Forms.CheckBox chkMgieDivineBene;
        private System.Windows.Forms.Label lblMgieDivineBene;
        private System.Windows.Forms.CheckBox chkMgieDivineDvnation;
        private System.Windows.Forms.Label lblMgieDivineDvnation;
        private System.Windows.Forms.CheckBox chkMgieDemoniaqueAbspton;
        private System.Windows.Forms.Label lblMgieDemoniaqueAbspton;
        private System.Windows.Forms.Label lblNomMDemoniaque;
        private System.Windows.Forms.CheckBox chkMgieDemoniaqueNecro;
        private System.Windows.Forms.Label lblMgieDemoniaqueNecro;
        private System.Windows.Forms.CheckBox chkMgieDemoniaqueMldction;
        private System.Windows.Forms.Label lblMgieDemoniaqueMldction;
        private System.Windows.Forms.CheckBox chkMgieDemoniaqueCntrole;
        private System.Windows.Forms.Label lblMgieDemoniaqueCntrole;
        private System.Windows.Forms.CheckBox chkMgieNeutreAltration;
        private System.Windows.Forms.Label lblMgieNeutreAltration;
        private System.Windows.Forms.Label lblNomMNeutre;
        private System.Windows.Forms.CheckBox chkMgieNeutreInvsbilté;
        private System.Windows.Forms.Label lblMgieNeutreInvsbilté;
        private System.Windows.Forms.CheckBox chkMgieNeutreSsie;
        private System.Windows.Forms.Label lblMgieNeutreSsie;
        private System.Windows.Forms.CheckBox chkMgieNeutreMsg;
        private System.Windows.Forms.Label lblMgieNeutreMsg;
        private System.Windows.Forms.RichTextBox rchTbSorts;
        private System.Windows.Forms.CheckBox chkMgieNeutreTelkinesie;
        private System.Windows.Forms.Label lblMgieNeutreTelkinesie;
        private System.Windows.Forms.Button btnViderRchTbInventaires;
        private System.Windows.Forms.Button btnViderRchTbSortileges;
        private System.Windows.Forms.CheckBox chkMgieNatureMetamphse;
        private System.Windows.Forms.Label lblMgieNatureMetamphse;
        private System.Windows.Forms.CheckBox chkMgieDemoniaqueIllusions;
        private System.Windows.Forms.Label lblMgieDemoniaqueIllusion;
        private System.Windows.Forms.NumericUpDown nudSbreCrbe;
        private System.Windows.Forms.NumericUpDown nudLte;
        private System.Windows.Forms.CheckBox chkTrdnt;
        private System.Windows.Forms.Label lblNomTrdnt;
        private System.Windows.Forms.Label lblPdsTrdnt;
        private System.Windows.Forms.Label lblPrteTrdnt;
        private System.Windows.Forms.NumericUpDown nudTrdnt;
        private System.Windows.Forms.Label lblTpeTrdnt;
        private System.Windows.Forms.Label lblDgtsTrdnt;
        private System.Windows.Forms.Label lblPdsFnde;
        private System.Windows.Forms.Label lblPdsFouet;
        private System.Windows.Forms.Label lblVleurEpee;
        private System.Windows.Forms.Label lblPrpieteEpees;
        private System.Windows.Forms.Label lblVleurScrmx;
        private System.Windows.Forms.Label lblVleurEpCrte;
        private System.Windows.Forms.Label lblVleurEpLge;
        private System.Windows.Forms.Label lblVleurGlve;
        private System.Windows.Forms.Label lblVleurLte;
        private System.Windows.Forms.Label lblVleurSbreCrbe;
        private System.Windows.Forms.Label lblVleurTrdnt;
        private System.Windows.Forms.Label lblVleurSrse;
        private System.Windows.Forms.Label lblVleurFrche;
        private System.Windows.Forms.Label lblVleurJvlot;
        private System.Windows.Forms.Label lblVleurCntus;
        private System.Windows.Forms.Label lblVleurLance;
        private System.Windows.Forms.Label lblVleurFclGure;
        private System.Windows.Forms.Label lblVleurDge;
        private System.Windows.Forms.Label lblVleurCtau;
        private System.Windows.Forms.Label lblVleurDagues;
        private System.Windows.Forms.Label lblVleurFrncsque;
        private System.Windows.Forms.Label lblVleurHache;
        private System.Windows.Forms.Label lblVleurArc;
        private System.Windows.Forms.Label lblVleurArcs;
        private System.Windows.Forms.Label lblVleurAblte;
        private System.Windows.Forms.Label lblVleurFnde;
        private System.Windows.Forms.Label lblVleurFaC;
        private System.Windows.Forms.Label lblVleurFouet;
        private System.Windows.Forms.Label lblVleurChaines;
        private System.Windows.Forms.Label lblVleurSctre;
        private System.Windows.Forms.Label lblVleurBtonChne;
        private System.Windows.Forms.Label lblVleurBatons;
        private System.Windows.Forms.Label lblVleurCfeMle;
        private System.Windows.Forms.Label lblVleurSpghlm;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblVleurMrn;
        private System.Windows.Forms.Label lblVleurCrvlre;
        private System.Windows.Forms.Label lblVleurChplFr;
        private System.Windows.Forms.Label lblVleurCsqueBrbre;
        private System.Windows.Forms.Label lblVleurVtments;
        private System.Windows.Forms.Label lblVleurBuste;
        private System.Windows.Forms.Label lblVleurBrgne;
        private System.Windows.Forms.Label lblVleurCtphrcte;
        private System.Windows.Forms.Label lblVleurCrsFr;
        private System.Windows.Forms.Label lblDescCasques;
        private System.Windows.Forms.Label lblDescDeuxCasques;
        private System.Windows.Forms.Label lblDescDeuxBuste;
        private System.Windows.Forms.Label lblDescBuste;
        private System.Windows.Forms.Label lblVleurRbeCuir;
        private System.Windows.Forms.Label lblVleurCrsBze;
        private System.Windows.Forms.Label lblVleurlblDescDeuxGants;
        private System.Windows.Forms.Label lblVleurlblDescGants;
        private System.Windows.Forms.Label lblVleurGntMles;
        private System.Windows.Forms.Label lblVleurGants;
        private System.Windows.Forms.Label lblVleurGntlet;
        private System.Windows.Forms.Label lblVleurMitne;
        private System.Windows.Forms.Label lblVleurMton;
        private System.Windows.Forms.Label lblDescDeuxGenouilleres;
        private System.Windows.Forms.Label lblDescGenouilleres;
        private System.Windows.Forms.Label lblVleurCmide;
        private System.Windows.Forms.Label lblVleurPntlonTle;
        private System.Windows.Forms.Label lblVleurCuissrd;
        private System.Windows.Forms.Label lblVleurGenouilleres;
        private System.Windows.Forms.Label lblVleurSndles;
        private System.Windows.Forms.Label lblVleurChaussures;
        private System.Windows.Forms.Label lblVleurChssuresCuir;
        private System.Windows.Forms.Label lblDescDeuxChaussures;
        private System.Windows.Forms.Label lblDescChaussures;
        private System.Windows.Forms.Label lblDescDeuxBoucliers;
        private System.Windows.Forms.Label lblVleurBouclier;
        private System.Windows.Forms.Label lblVleurEcu;
        private System.Windows.Forms.Label lblVleurPvois;
        private System.Windows.Forms.Label lblVleurBclrAmde;
        private System.Windows.Forms.Label lblVleurBclrBze;
        private System.Windows.Forms.Label lblVleurPlta;
        private System.Windows.Forms.Label lblVleurTrche;
        private System.Windows.Forms.Label lblVleurObjets;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblVleurOte;
        private System.Windows.Forms.Label lblVleurSc;
        private System.Windows.Forms.Label lblVleurTnte;
        private System.Windows.Forms.Label lblPrpieteScrmx;
        private System.Windows.Forms.Label lblDescEpees;
        private System.Windows.Forms.Label lblPrpieteEpCrte;
        private System.Windows.Forms.Label lblPrpieteEpLge;
        private System.Windows.Forms.Label lblPrpieteGlve;
        private System.Windows.Forms.Label lblPrpieteLte;
        private System.Windows.Forms.Label lblPrpieteSbreCrbe;
        private System.Windows.Forms.Label lblDescLances;
        private System.Windows.Forms.Label lblPprieteCntus;
        private System.Windows.Forms.Label lblPprieteLances;
        private System.Windows.Forms.Label lblPprieteJvlot;
        private System.Windows.Forms.Label lblPprieteFrche;
        private System.Windows.Forms.Label lblPprieteSrse;
        private System.Windows.Forms.Label lblPprieteTrdnt;
        private System.Windows.Forms.Label lblVleurDgeAssin;
        private System.Windows.Forms.CheckBox chkDgeAssin;
        private System.Windows.Forms.Label lblNomDgeAssin;
        private System.Windows.Forms.Label lblPdsDgeAssin;
        private System.Windows.Forms.Label lblPrteDgeAssin;
        private System.Windows.Forms.NumericUpDown nudDgeAssin;
        private System.Windows.Forms.Label lblTpeDgeAssin;
        private System.Windows.Forms.Label lblDgtsDgeAssin;
        private System.Windows.Forms.Label lblPprieteDagues;
        private System.Windows.Forms.Label lblPrpieteCtau;
        private System.Windows.Forms.Label lblPrpieteDge;
        private System.Windows.Forms.Label lblPrpieteFclGure;
        private System.Windows.Forms.Label lblPrpieteDgeAssin;
        private System.Windows.Forms.Label lblDescPoignards;
        private System.Windows.Forms.Label lblPrpieteHaches;
        private System.Windows.Forms.Label lblPrpieteFrncsque;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblPrpieteArcs;
        private System.Windows.Forms.Label lblPrpieteArc;
        private System.Windows.Forms.Label lblDescArcs;
        private System.Windows.Forms.Label lblPrpieteAblte;
        private System.Windows.Forms.Label lblPrpieteFnde;
        private System.Windows.Forms.Label lblPrpieteFouet;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblPrpieteFaC;
        private System.Windows.Forms.Label lblPrpieteBatons;
        private System.Windows.Forms.Label lblPrpieteBtonChne;
        private System.Windows.Forms.Label lblPrpieteSctre;
        private System.Windows.Forms.Label lblPrpieteCasques;
        private System.Windows.Forms.Label lblPrpieteSpghlm;
        private System.Windows.Forms.Label lblPrpieteCfeMle;
        private System.Windows.Forms.Label lblPrpieteMrn;
        private System.Windows.Forms.Label lblPrpieteCrvlre;
        private System.Windows.Forms.Label lblPrpieteChplFr;
        private System.Windows.Forms.Label lblPrpieteCsqueBrbre;
        private System.Windows.Forms.Label lblPrpieteBuste;
        private System.Windows.Forms.Label lblPrpieteVtments;
        private System.Windows.Forms.Label lblPrpieteBrgne;
        private System.Windows.Forms.Label lblPrpieteCtphrcte;
        private System.Windows.Forms.Label lblPrpieteCrsFr;
        private System.Windows.Forms.Label lblPrpieteRbeCuir;
        private System.Windows.Forms.Label lblPrpieteCrsBze;
        private System.Windows.Forms.Label lblPrpieteGants;
        private System.Windows.Forms.Label lblPrpieteGntMles;
        private System.Windows.Forms.Label lblPrpieteGntlet;
        private System.Windows.Forms.Label lblPrpieteMitne;
        private System.Windows.Forms.Label lblPrpieteMton;
        private System.Windows.Forms.Label lblPrpieteGenouilleres;
        private System.Windows.Forms.Label lblPrpieteCuissrd;
        private System.Windows.Forms.Label lblPrpietePntlonTle;
        private System.Windows.Forms.Label lblPrpieteCmide;
        private System.Windows.Forms.Label lblPrpieteChaussures;
        private System.Windows.Forms.Label lblPrpieteSndles;
        private System.Windows.Forms.Label lblPrpieteChssuresCuir;
        private System.Windows.Forms.Label lblPrpieteBoucliers;
        private System.Windows.Forms.Label lblPrpieteEcu;
        private System.Windows.Forms.Label lblPrpietePvois;
        private System.Windows.Forms.Label lblPrpieteBclrAmde;
        private System.Windows.Forms.Label lblPrpieteBclrBze;
        private System.Windows.Forms.Label lblPrpietePlta;
        private System.Windows.Forms.Label lblChargeRestanteProgressBar;
        private System.Windows.Forms.Label lblSeparationRestanteMax;
        private System.Windows.Forms.Label lblChargeMaximale;
        private System.Windows.Forms.TextBox txtChargeMaximale;
        private System.Windows.Forms.TextBox txtChargeRestante;
        private System.Windows.Forms.Label lblPrpieteEpBois;
        private System.Windows.Forms.Label lblVleurEpBois;
        private System.Windows.Forms.NumericUpDown nudEpBois;
        private System.Windows.Forms.CheckBox chkEpBois;
        private System.Windows.Forms.Label lblNomEpBois;
        private System.Windows.Forms.Label lblPdsEpBois;
        private System.Windows.Forms.Label lblPrteEpBois;
        private System.Windows.Forms.Label lblTpeEpBois;
        private System.Windows.Forms.Label lblDgtsEpBois;
        private System.Windows.Forms.Label lblPrpieteEpBtrde;
        private System.Windows.Forms.Label lblVleurEpBtrde;
        private System.Windows.Forms.NumericUpDown nudEpBtrde;
        private System.Windows.Forms.CheckBox chkEpBtrde;
        private System.Windows.Forms.Label lblNomEpBtrde;
        private System.Windows.Forms.Label lblPdsEpBtrde;
        private System.Windows.Forms.Label lblPrteEpBtrde;
        private System.Windows.Forms.Label lblTpeEpBtrde;
        private System.Windows.Forms.Label lblDgtsEpBtrde;
        private System.Windows.Forms.Label lblPrpieteHcheBhron;
        private System.Windows.Forms.Label lblVleurHcheBhron;
        private System.Windows.Forms.CheckBox chkHcheBhron;
        private System.Windows.Forms.Label lblNomHcheBhron;
        private System.Windows.Forms.Label lblPdsHcheBhron;
        private System.Windows.Forms.Label lblPrteHcheBhron;
        private System.Windows.Forms.NumericUpDown nudHcheBhron;
        private System.Windows.Forms.Label lblTpeHcheBhron;
        private System.Windows.Forms.Label lblDgtsHcheBhron;
        private System.Windows.Forms.Label lblPrpieteMassues;
        private System.Windows.Forms.Label lblVleurMassues;
        private System.Windows.Forms.Label lblNomMassues;
        private System.Windows.Forms.Label lblPrteMassues;
        private System.Windows.Forms.Label lblPdsMassues;
        private System.Windows.Forms.Label lblNbMassues;
        private System.Windows.Forms.Label lblTpeMassues;
        private System.Windows.Forms.Label lblDgtsMassues;
        private System.Windows.Forms.Label lblPrpieteMsueChne;
        private System.Windows.Forms.Label lblVleurMsueChne;
        private System.Windows.Forms.CheckBox chkMsueChne;
        private System.Windows.Forms.Label lblNomMsueChne;
        private System.Windows.Forms.Label lblPdsMsueChne;
        private System.Windows.Forms.Label lblPrteMsueChne;
        private System.Windows.Forms.NumericUpDown nudMsueChne;
        private System.Windows.Forms.Label lblTpeMsueChne;
        private System.Windows.Forms.Label lblDgtsMsueChne;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPrpieteMrteauFgron;
        private System.Windows.Forms.Label lblVleurMrteauFgron;
        private System.Windows.Forms.CheckBox chkMrteauFgron;
        private System.Windows.Forms.Label lblNomMrteauFgron;
        private System.Windows.Forms.Label lblPdsMrteauFgron;
        private System.Windows.Forms.Label lblPrteMrteauFgron;
        private System.Windows.Forms.NumericUpDown nudMrteauFgron;
        private System.Windows.Forms.Label lblTpeMrteauFgron;
        private System.Windows.Forms.Label lblDgtsMrteauFgron;
        private System.Windows.Forms.Label lblPrpieteSbton;
        private System.Windows.Forms.Label lblVleurSbton;
        private System.Windows.Forms.CheckBox chkSbton;
        private System.Windows.Forms.Label lblNomSbton;
        private System.Windows.Forms.Label lblPdsSbton;
        private System.Windows.Forms.NumericUpDown nudSbton;
        private System.Windows.Forms.Label lblEftsSbton;
        private System.Windows.Forms.Label lblPrpieteCpeElfique;
        private System.Windows.Forms.Label lblVleurCpeElfique;
        private System.Windows.Forms.CheckBox chkCpeElfique;
        private System.Windows.Forms.Label lblNomCpeElfique;
        private System.Windows.Forms.Label lblPdsCpeElfique;
        private System.Windows.Forms.NumericUpDown nudCpeElfique;
        private System.Windows.Forms.Label lblEftsCpeElfique;
        private System.Windows.Forms.Label lblPrpieteCneAqua;
        private System.Windows.Forms.Label lblVleurCneAqua;
        private System.Windows.Forms.CheckBox chkCneAqua;
        private System.Windows.Forms.Label lblPrteCneAqua;
        private System.Windows.Forms.Label lblEftsCneAqua;
        private System.Windows.Forms.Label lblNomCneAqua;
        private System.Windows.Forms.Label lblPdsCneAqua;
        private System.Windows.Forms.NumericUpDown nudCneAqua;
        private System.Windows.Forms.Label lblTpeCneAqua;
        private System.Windows.Forms.Label lblDgtsCneAqua;
        private System.Windows.Forms.Label lblPrpieteBgteFeu;
        private System.Windows.Forms.Label lblVleurBgteFeu;
        private System.Windows.Forms.CheckBox chkBgteFeu;
        private System.Windows.Forms.Label lblPrteBgteFeu;
        private System.Windows.Forms.Label lblEftsBgteFeu;
        private System.Windows.Forms.Label lblNomBgteFeu;
        private System.Windows.Forms.Label lblPdsBgteFeu;
        private System.Windows.Forms.NumericUpDown nudBgteFeu;
        private System.Windows.Forms.Label lblTpeBgteFeu;
        private System.Windows.Forms.Label lblDgtsBgteFeu;
        private System.Windows.Forms.Label lblPrpieteBtonCelste;
        private System.Windows.Forms.Label lblVleurBtonCelste;
        private System.Windows.Forms.CheckBox chkBtonCelste;
        private System.Windows.Forms.Label lblPrteBtonCelste;
        private System.Windows.Forms.Label lblEftsBtonCelste;
        private System.Windows.Forms.Label lblNomBtonCelste;
        private System.Windows.Forms.Label lblPdsBtonCelste;
        private System.Windows.Forms.NumericUpDown nudBtonCelste;
        private System.Windows.Forms.Label lblTpeBtonCelste;
        private System.Windows.Forms.Label lblDgtsBtonCelste;
        private System.Windows.Forms.Label lblPrpieteScptreTerre;
        private System.Windows.Forms.Label lblVleurScptreTerre;
        private System.Windows.Forms.CheckBox chkScptreTerre;
        private System.Windows.Forms.Label lblPrteScptreTerre;
        private System.Windows.Forms.Label lblEftsScptreTerre;
        private System.Windows.Forms.Label lblNomScptreTerre;
        private System.Windows.Forms.Label lblPdsScptreTerre;
        private System.Windows.Forms.NumericUpDown nudScptreTerre;
        private System.Windows.Forms.Label lblTpeScptreTerre;
        private System.Windows.Forms.Label lblDgtsScptreTerre;
        private System.Windows.Forms.Label lblPrpieteBtonNture;
        private System.Windows.Forms.Label lblVleurBtonNture;
        private System.Windows.Forms.CheckBox chkBtonNture;
        private System.Windows.Forms.Label lblPrteBtonNture;
        private System.Windows.Forms.Label lblEftsBtonNture;
        private System.Windows.Forms.Label lblNomBtonNture;
        private System.Windows.Forms.Label lblPdsBtonNture;
        private System.Windows.Forms.NumericUpDown nudBtonNture;
        private System.Windows.Forms.Label lblTpeBtonNture;
        private System.Windows.Forms.Label lblDgtsBtonNture;
        private System.Windows.Forms.Label lblPrpieteCneLmiere;
        private System.Windows.Forms.Label lblVleurCneLmiere;
        private System.Windows.Forms.CheckBox chkCneLmiere;
        private System.Windows.Forms.Label lblPrteCneLmiere;
        private System.Windows.Forms.Label lblEftsCneLmiere;
        private System.Windows.Forms.Label lblNomCneLmiere;
        private System.Windows.Forms.Label lblPdsCneLmiere;
        private System.Windows.Forms.NumericUpDown nudCneLmiere;
        private System.Windows.Forms.Label lblTpeCneLmiere;
        private System.Windows.Forms.Label lblDgtsCneLmiere;
        private System.Windows.Forms.Label lblPrpieteBgteInfernale;
        private System.Windows.Forms.Label lblVleurBgteInfernale;
        private System.Windows.Forms.CheckBox chkBgteInfernale;
        private System.Windows.Forms.Label lblPrteBgteInfernale;
        private System.Windows.Forms.Label lblEftsBgteInfernale;
        private System.Windows.Forms.Label lblNomBgteInfernale;
        private System.Windows.Forms.Label lblPdsBgteInfernale;
        private System.Windows.Forms.NumericUpDown nudBgteInfernale;
        private System.Windows.Forms.Label lblTpeBgteInfernale;
        private System.Windows.Forms.Label lblDgtsBgteInfernale;
        private System.Windows.Forms.Label lblPrpieteSptreNeutre;
        private System.Windows.Forms.Label lblVleurSptreNeutre;
        private System.Windows.Forms.CheckBox chkSptreNeutre;
        private System.Windows.Forms.Label lblPrteSptreNeutre;
        private System.Windows.Forms.Label lblEftsSptreNeutre;
        private System.Windows.Forms.Label lblNomSptreNeutre;
        private System.Windows.Forms.Label lblPdsSptreNeutre;
        private System.Windows.Forms.NumericUpDown nudSptreNeutre;
        private System.Windows.Forms.Label lblTpeSptreNeutre;
        private System.Windows.Forms.Label lblDgtsSptreNeutre;
        private System.Windows.Forms.Label lblDescBatons;
        private System.Windows.Forms.Label lblVleurMhoir;
        private System.Windows.Forms.CheckBox chkMhoir;
        private System.Windows.Forms.Label lblTlleMhoir;
        private System.Windows.Forms.Label lblNomMhoir;
        private System.Windows.Forms.Label lblPdsMhoir;
        private System.Windows.Forms.NumericUpDown nudMhoir;
        private System.Windows.Forms.Label lblEftsMhoir;
        private System.Windows.Forms.Label lblVleurCvture;
        private System.Windows.Forms.CheckBox chkCvture;
        private System.Windows.Forms.Label lblTlleCvture;
        private System.Windows.Forms.Label lblNomCvture;
        private System.Windows.Forms.Label lblPdsCvture;
        private System.Windows.Forms.NumericUpDown nudCvture;
        private System.Windows.Forms.Label lblEftsCvture;
        private System.Windows.Forms.Label lblVleurPlnteMcnale;
        private System.Windows.Forms.CheckBox chkPlnteMcnale;
        private System.Windows.Forms.Label lblTllePlnteMcnale;
        private System.Windows.Forms.Label lblNomPlnteMcnale;
        private System.Windows.Forms.Label lblPdsPlnteMcnale;
        private System.Windows.Forms.NumericUpDown nudPlnteMcnale;
        private System.Windows.Forms.Label lblEftsPlnteMcnale;
        private System.Windows.Forms.Label lblVleurCntrePson;
        private System.Windows.Forms.CheckBox chkCntrePson;
        private System.Windows.Forms.Label lblTlleCntrePson;
        private System.Windows.Forms.Label lblNomCntrePson;
        private System.Windows.Forms.Label lblPdsCntrePson;
        private System.Windows.Forms.NumericUpDown nudCntrePson;
        private System.Windows.Forms.Label lblEftsCntrePson;
        private System.Windows.Forms.Label lblVleurFlcheBois;
        private System.Windows.Forms.CheckBox chkFlcheBois;
        private System.Windows.Forms.Label lblTlleFlcheBois;
        private System.Windows.Forms.Label lblNomFlcheBois;
        private System.Windows.Forms.Label lblPdsFlcheBois;
        private System.Windows.Forms.NumericUpDown nudFlcheBois;
        private System.Windows.Forms.Label lblEftsFlcheBois;
        private System.Windows.Forms.Label lblVleurFlcheFr;
        private System.Windows.Forms.CheckBox chkFlcheFr;
        private System.Windows.Forms.Label lblTlleFlcheFr;
        private System.Windows.Forms.Label lblNomFlcheFr;
        private System.Windows.Forms.Label lblPdsFlcheFr;
        private System.Windows.Forms.NumericUpDown nudFlcheFr;
        private System.Windows.Forms.Label lblDgtsFlcheFr;
        private System.Windows.Forms.Label lblVleurFlcheArgent;
        private System.Windows.Forms.CheckBox chkFlcheArgent;
        private System.Windows.Forms.Label lblTlleFlcheArgent;
        private System.Windows.Forms.Label lblnomFlcheArgent;
        private System.Windows.Forms.Label lblPdsFlcheArgent;
        private System.Windows.Forms.NumericUpDown nudFlcheArgent;
        private System.Windows.Forms.Label lblEftsFlcheArgent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkCrauBois;
        private System.Windows.Forms.Label lblTlleCrauBois;
        private System.Windows.Forms.Label lblNomCrauBois;
        private System.Windows.Forms.Label lblPdsCrauBois;
        private System.Windows.Forms.NumericUpDown nudCrauBois;
        private System.Windows.Forms.Label lblEftsCrauBois;
        private System.Windows.Forms.Label lblVleurCrauFr;
        private System.Windows.Forms.CheckBox chkCrauFr;
        private System.Windows.Forms.Label lblTlleCrauFr;
        private System.Windows.Forms.Label lblNomCrauFr;
        private System.Windows.Forms.Label lblPdsCrauFr;
        private System.Windows.Forms.NumericUpDown nudCrauFr;
        private System.Windows.Forms.Label lblEftsCrauFr;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkPrre;
        private System.Windows.Forms.Label lblTllePrre;
        private System.Windows.Forms.Label lblNomPrre;
        private System.Windows.Forms.Label lblPdsPrre;
        private System.Windows.Forms.NumericUpDown nudPrre;
        private System.Windows.Forms.Label lblEftsPrre;
        private System.Windows.Forms.Label lblCuivre;
        private System.Windows.Forms.Label lblArgent;
        private System.Windows.Forms.Label lblOr;
        private System.Windows.Forms.TextBox txtOr;
        private System.Windows.Forms.TextBox txtArgent;
        private System.Windows.Forms.TextBox txtCuivre;
    }
}